sed -i 's/dependencies {/dependencies {\n  implementation("androidx.biometric:biometric:1.2.0-alpha05")\n  implementation("androidx.fragment:fragment-ktx:1.8.6")/g' app/build.gradle.kts
