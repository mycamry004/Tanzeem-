import re

content = open("app/src/main/java/com/example/ui/TatViewModel.kt").read()

cleanup_func = """
    fun cleanupMultipleActiveCustodians(trueActive: Custodian) {
        viewModelScope.launch {
            val list = custodians.value
            val newCustodians = list.map { curr ->
                if (curr.id == trueActive.id || (curr.name == trueActive.name && curr.startDate == trueActive.startDate)) {
                    curr.copy(isCurrent = true)
                } else {
                    curr.copy(isCurrent = false)
                }
            }
            repository.updateCustodiansList(newCustodians)
        }
    }
"""

if "fun cleanupMultipleActiveCustodians" not in content:
    content = content.replace("fun addCustodian(", cleanup_func + "\n    fun addCustodian(")
    open("app/src/main/java/com/example/ui/TatViewModel.kt", "w").write(content)

