import re

with open("app/src/main/java/com/example/ui/TatViewModel.kt", "r") as f:
    content = f.read()

# Add prefs
init_prefs = """    private val prefs = application.getSharedPreferences("TatPrefs", android.content.Context.MODE_PRIVATE)

    // Language state: true = Urdu, false = English
    private val _isUrdu = MutableStateFlow(prefs.getBoolean("isUrdu", true))"""

content = re.sub(r'    // Language state: true = Urdu, false = English\s*private val _isUrdu = MutableStateFlow\(false\)', init_prefs, content)

# Modify toggleLanguage
toggle_lang = """    fun toggleLanguage() {
        _isUrdu.value = !_isUrdu.value
        prefs.edit().putBoolean("isUrdu", _isUrdu.value).apply()
        resetChat() // refresh welcoming message in correct language
    }"""
content = re.sub(r'    fun toggleLanguage\(\) \{\s*_isUrdu\.value = !_isUrdu\.value\s*resetChat\(\) // refresh welcoming message in correct language\s*\}', toggle_lang, content)

# Modify setLanguage
set_lang = """    fun setLanguage(isUrdu: Boolean) {
        if (_isUrdu.value != isUrdu) {
            _isUrdu.value = isUrdu
            prefs.edit().putBoolean("isUrdu", isUrdu).apply()
            resetChat()
        }
    }"""
content = re.sub(r'    fun setLanguage\(isUrdu: Boolean\) \{\s*if \(_isUrdu\.value != isUrdu\) \{\s*_isUrdu\.value = isUrdu\s*resetChat\(\)\s*\}\s*\}', set_lang, content)

# Add toggleTheme and init it in init { ... }
add_theme_toggle = """    fun toggleTheme() {
        val newTheme = !com.example.ui.theme.isSystemInDarkTheme
        com.example.ui.theme.isSystemInDarkTheme = newTheme
        prefs.edit().putBoolean("isDarkTheme", newTheme).apply()
    }"""
content = content.replace("fun toggleLanguage()", add_theme_toggle + "\n\n    fun toggleLanguage()")

init_block = """    init {
        com.example.ui.theme.isSystemInDarkTheme = prefs.getBoolean("isDarkTheme", false)
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {"""
content = content.replace("""    init {
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {""", init_block)


with open("app/src/main/java/com/example/ui/TatViewModel.kt", "w") as f:
    f.write(content)
print("ViewModel Patched")
