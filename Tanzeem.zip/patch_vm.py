import re

content = open("app/src/main/java/com/example/ui/TatViewModel.kt").read()

restore_pattern = r"com\.example\.data\.CloudSyncManager\.syncToCloud\(\s*backup\.members,\s*backup\.claims,\s*backup\.custodians\s*\)"
new_restore = """com.example.data.CloudSyncManager.syncToCloud(
                        backup.members,
                        backup.claims,
                        backup.custodians,
                        backup.notifications,
                        backup.devices
                    )"""

content = re.sub(restore_pattern, new_restore, content)

open("app/src/main/java/com/example/ui/TatViewModel.kt", "w").write(content)
