import re

content = open("app/src/main/java/com/example/ui/TatViewModel.kt").read()

admin_handover = """
    fun adminInitiateHandover(
        targetCustodian: Custodian,
        currentBalance: Double,
        onComplete: (receipt: String, tempPassword: String, nextName: String, nextPhone: String) -> Unit
    ) {
        viewModelScope.launch {
            val list = custodians.value
            val current = list.firstOrNull { it.isCurrent }
            
            // Generate temporary unique password for incoming (random 5-character string)
            val allowedChars = ('a'..'z') + ('0'..'9')
            val generatedTempPassword = (1..5)
                .map { allowedChars.random() }
                .joinToString("")

            // Set tempPassword on the target custodian
            val updatedNext = targetCustodian.copy(
                tempPassword = generatedTempPassword
            )
            repository.updateCustodian(updatedNext)

            // Generate dispatch receipt summary
            val dateFormat = java.text.SimpleDateFormat("dd MMM yyyy, HH:mm", java.util.Locale.getDefault())
            val nowStr = dateFormat.format(java.util.Date())

            val receipt = if (_isUrdu.value) {
                \"\"\"
                سرکاری عارضی چابی منتقلی رسید (ایڈمن)
                -----------------------------
                تاریخ منتقلی: $nowStr
                منجانب (سابقہ امانت دار): ${current?.name ?: "Admin"}
                الیٰ (نیا امانت دار): ${targetCustodian.name}
                منتقل شدہ رقم: ${String.format(java.util.Locale.US, "%,.2f", currentBalance)} ریال (QAR)
                حیثیت: عارضی چابی کامیابی سے تخلیق کر دی گئی ہے۔
                
                انتباہ: نیا نگران لاگ ان کرنے اور عارضی چابی درج کر کے اپنا مستقل پاس ورڈ حاصل کر سکتا ہے۔ تب تک سابقہ نگران کا پاس ورڈ فعال رہے گا۔
                \"\"\".trimIndent()
            } else {
                \"\"\"
                OFFICIAL TEMPORARY HANDOVER RECEIPT (ADMIN)
                ---------------------------------
                Timestamp: $nowStr
                Outbound Custodian (Amanat Holder): ${current?.name ?: "Admin"}
                Inbound Custodian (Incoming Holder): ${targetCustodian.name}
                Transferred Funds: ${String.format(java.util.Locale.US, "%,.2f", currentBalance)} QAR
                Status: Temporary Handover Key Generated successfully.
                
                NOTICE: The new custodian can log in and enter this temporary key to claim their permanent password. The previous custodian's access remains active until claimed.
                \"\"\".trimIndent()
            }

            onComplete(receipt, generatedTempPassword, targetCustodian.name, targetCustodian.phone)
        }
    }
"""

if "fun adminInitiateHandover" not in content:
    content = content.replace("fun performHandover(", admin_handover + "\n    fun performHandover(")
    open("app/src/main/java/com/example/ui/TatViewModel.kt", "w").write(content)

