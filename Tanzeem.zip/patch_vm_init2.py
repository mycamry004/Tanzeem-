import re
content = open("app/src/main/java/com/example/ui/TatViewModel.kt").read()

bad_injection = """
            // Auto-assign first custodian if none is current
            val currentList = repository.allCustodians.value
            if (currentList.isNotEmpty() && currentList.none { it.isCurrent }) {
                val firstCust = currentList.minByOrNull { it.orderIndex }
                if (firstCust != null) {
                    val updated = firstCust.copy(isCurrent = true)
                    repository.updateCustodian(updated)
                }
            }
"""

content = content.replace(bad_injection, "")

good_injection = """
        viewModelScope.launch {
            repository.allCustodians.collect { currentList ->
                if (currentList.isNotEmpty() && currentList.none { it.isCurrent }) {
                    val firstCust = currentList.minByOrNull { it.orderIndex }
                    if (firstCust != null) {
                        val updated = firstCust.copy(isCurrent = true)
                        repository.updateCustodian(updated)
                    }
                }
            }
        }
"""
content = content.replace("resetChat()\n    }", "resetChat()\n" + good_injection + "    }")
open("app/src/main/java/com/example/ui/TatViewModel.kt", "w").write(content)
