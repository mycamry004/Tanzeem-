import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

content = content.replace("border = BorderStroke(1.dp, GoldAccent.copy(alpha = 0.3f)),\n            shape = RoundedCornerShape(16.dp)", "border = BorderStroke(1.dp, EmeraldPrimary.copy(alpha = 0.5f)),\n            shape = RoundedCornerShape(16.dp)")

content = content.replace("border = BorderStroke(1.dp, EmeraldPrimary.copy(alpha = 0.3f)),\n            shape = RoundedCornerShape(16.dp)", "border = BorderStroke(1.dp, EmeraldPrimary.copy(alpha = 0.5f)),\n            shape = RoundedCornerShape(16.dp)")

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
print("Other cards patched")
