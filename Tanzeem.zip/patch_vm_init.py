import re
content = open("app/src/main/java/com/example/ui/TatViewModel.kt").read()

injection = """
            // Auto-assign first custodian if none is current
            val currentList = repository.allCustodians.value
            if (currentList.isNotEmpty() && currentList.none { it.isCurrent }) {
                val firstCust = currentList.minByOrNull { it.orderIndex }
                if (firstCust != null) {
                    val updated = firstCust.copy(isCurrent = true)
                    repository.updateCustodian(updated)
                }
            }
"""
content = content.replace("try {\n                val dao = database.tanzeemDao()", injection + "            try {\n                val dao = database.tanzeemDao()")
open("app/src/main/java/com/example/ui/TatViewModel.kt", "w").write(content)
