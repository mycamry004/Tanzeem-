import re

with open('app/src/main/java/com/example/data/CloudSyncManager.kt', 'r') as f:
    content = f.read()

target = """    // Upload current state to cloud
    suspend fun syncToCloud(
        members: List<Member>,
        claims: List<Claim>,
        custodians: List<Custodian>
    ): Pair<Boolean, String> {
        try {
            val state = CloudBackup(
                timestamp = System.currentTimeMillis(),
                members = members,
                claims = claims,
                custodians = custodians
            )
            // Update current state with timeout
            kotlinx.coroutines.withTimeoutOrNull(8000L) {
                db?.collection(COLLECTION_DATA)?.document(DOC_CURRENT)?.set(state)?.await()
            }
            // Handle Daily Backup (only 1 per day)
            if (db == null) return Pair(false, "Firebase database not initialized")
            val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
            val todayStr = sdf.format(Date())
            
            kotlinx.coroutines.withTimeoutOrNull(8000L) {
                db?.collection(COLLECTION_DATA)
                    ?.document(DOC_CURRENT)
                    ?.collection(COLLECTION_BACKUPS)
                    ?.document(todayStr)
                    ?.set(state, SetOptions.merge())
                    ?.await()
            }
            // Cleanup old backups (keep only last 180 (6 months))
            cleanupOldBackups()
            return Pair(true, "Success")
        } catch (e: Exception) {
            Log.d("CloudSync", "Error syncing to cloud: ${e.message}")
            return Pair(false, e.message ?: "Unknown error")
        }
    }"""

replacement = """    // Upload current state to cloud
    suspend fun syncToCloud(
        members: List<Member>,
        claims: List<Claim>,
        custodians: List<Custodian>
    ): Pair<Boolean, String> {
        try {
            if (db == null) return Pair(false, "Firebase database not initialized")
            
            val state = CloudBackup(
                timestamp = System.currentTimeMillis(),
                members = members,
                claims = claims,
                custodians = custodians
            )
            
            // Update current state with timeout
            val result1 = kotlinx.coroutines.withTimeoutOrNull(8000L) {
                db?.collection(COLLECTION_DATA)?.document(DOC_CURRENT)?.set(state)?.await()
                true
            }
            if (result1 == null) {
                return Pair(false, "Network connection timed out (Firebase App Check or Offline). Please ensure SHA-1 is added.")
            }
            
            val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
            val todayStr = sdf.format(Date())
            
            val result2 = kotlinx.coroutines.withTimeoutOrNull(8000L) {
                db?.collection(COLLECTION_DATA)
                    ?.document(DOC_CURRENT)
                    ?.collection(COLLECTION_BACKUPS)
                    ?.document(todayStr)
                    ?.set(state, SetOptions.merge())
                    ?.await()
                true
            }
            if (result2 == null) {
                return Pair(false, "Network connection timed out during backup.")
            }
            
            // Cleanup old backups (keep only last 180 (6 months))
            cleanupOldBackups()
            return Pair(true, "Success")
        } catch (e: Exception) {
            Log.d("CloudSync", "Error syncing to cloud: ${e.message}")
            return Pair(false, e.message ?: "Unknown error")
        }
    }"""

if "suspend fun syncToCloud" in content:
    pattern = re.compile(r'    // Upload current state to cloud\n    suspend fun syncToCloud\(.*?return Pair\(false, e\.message \?: "Unknown error"\)\n    \}', re.DOTALL)
    content = pattern.sub(replacement.strip(), content)
    with open('app/src/main/java/com/example/data/CloudSyncManager.kt', 'w') as f:
        f.write(content)
    print("Patched syncToCloud successfully")
else:
    print("syncToCloud not found")
