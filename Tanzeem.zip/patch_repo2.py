import re

content = open("app/src/main/java/com/example/data/TanzeemRepository.kt").read()

force_pattern = r"val matches = if \(newActive\.id != 0L\) it\.id == newActive\.id else \(it\.name == newActive\.name && it\.phone == newActive\.phone\)"
new_force = "val matches = (newActive.id != 0L && it.id == newActive.id) || (it.name == newActive.name && it.phone == newActive.phone)"

content = content.replace(force_pattern, new_force)

open("app/src/main/java/com/example/data/TanzeemRepository.kt", "w").write(content)
