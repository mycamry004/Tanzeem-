import re
with open('app/src/main/java/com/example/MainActivity.kt', 'r') as f:
    content = f.read()

updater_code = """    var updateInfo by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf<com.example.updater.AutoUpdater.UpdateInfo?>(null) }
    
    androidx.compose.runtime.LaunchedEffect(Unit) {
        val info = com.example.updater.AutoUpdater.checkForUpdates()
        if (info?.isUpdateAvailable == true) {
            updateInfo = info
        }
    }

    updateInfo?.let { info ->
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { updateInfo = null },
            title = { androidx.compose.material3.Text("Update Available", fontWeight = androidx.compose.ui.text.font.FontWeight.Bold) },
            text = { 
                androidx.compose.foundation.layout.Column {
                    androidx.compose.material3.Text("Version ${info.latestVersionName} is available.")
                    androidx.compose.foundation.layout.Spacer(modifier = androidx.compose.ui.Modifier.height(8.dp))
                    androidx.compose.material3.Text(info.releaseNotes, fontSize = 14.sp)
                }
            },
            confirmButton = {
                androidx.compose.material3.Button(
                    onClick = {
                        com.example.updater.AutoUpdater.downloadAndInstallUpdate(context, info.downloadUrl, info.latestVersionName)
                        updateInfo = null
                        android.widget.Toast.makeText(context, "Downloading update...", android.widget.Toast.LENGTH_SHORT).show()
                    },
                    colors = androidx.compose.material3.ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
                ) {
                    androidx.compose.material3.Text("Update Now")
                }
            },
            dismissButton = {
                androidx.compose.material3.TextButton(onClick = { updateInfo = null }) {
                    androidx.compose.material3.Text("Later", color = TextMuted)
                }
            },
            containerColor = DarkSlateSurface,
            titleContentColor = TextOffWhite,
            textContentColor = TextOffWhite
        )
    }
"""

if "updateInfo" not in content:
    content = content.replace('    val context = androidx.compose.ui.platform.LocalContext.current\n', 
                              '    val context = androidx.compose.ui.platform.LocalContext.current\n' + updater_code)

with open('app/src/main/java/com/example/MainActivity.kt', 'w') as f:
    f.write(content)
