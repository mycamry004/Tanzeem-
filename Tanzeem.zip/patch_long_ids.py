import re

def replace_in_file(filepath, target, replacement):
    with open(filepath, 'r') as f:
        content = f.read()
    content = content.replace(target, replacement)
    with open(filepath, 'w') as f:
        f.write(content)

replace_in_file('app/src/main/java/com/example/data/Claim.kt', 'val id: Int = 0', 'val id: Long = 0L')
replace_in_file('app/src/main/java/com/example/data/Custodian.kt', 'val id: Int = 0', 'val id: Long = 0L')
replace_in_file('app/src/main/java/com/example/data/Member.kt', 'val id: Int = 0', 'val id: Long = 0L')
replace_in_file('app/src/main/java/com/example/data/TanzeemDao.kt', 'getMemberById(id: Int)', 'getMemberById(id: Long)')
replace_in_file('app/src/main/java/com/example/data/AppDatabase.kt', 'version = 1', 'version = 2')

