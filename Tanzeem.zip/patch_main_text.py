import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

content = content.replace('text = if (isUrdu) "رپورٹ ممبران" else "Member Ledger",', 'text = Translations.getString("exportMembersBtn", isUrdu),')
content = content.replace('text = if (isUrdu) "رپورٹ نگران" else "Custodian Hist",', 'text = Translations.getString("exportCustodiansBtn", isUrdu),')

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
print("Updated main texts")
