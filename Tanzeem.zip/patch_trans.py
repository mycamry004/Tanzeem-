import re

with open("app/src/main/java/com/example/ui/Translations.kt", "r") as f:
    content = f.read()

content = content.replace('"exportTitle" to "Data Portability & Backups"', '"exportTitle" to "Member and Custodian list"')
content = content.replace('"exportDesc" to "Export cryptographically secure community reports in standard PDF format."', '"exportDesc" to "Download members and custodian list in standard PDF format."')
content = content.replace('"exportMembersBtn" to "Export Member Ledger (PDF)"', '"exportMembersBtn" to "Download Members list"')
content = content.replace('"exportCustodiansBtn" to "Export Custodian History (PDF)"', '"exportCustodiansBtn" to "Download Custodian list"')

content = content.replace('"exportTitle" to "ڈیٹا کی منتقلی اور بیک اپ"', '"exportTitle" to "ممبر اور نگران کی فہرست"')
content = content.replace('"exportDesc" to "کمیونٹی کی آڈٹ اور بیک اپ کے لیے باضابطہ PDF رپورٹیں ڈاؤن لوڈ کریں۔"', '"exportDesc" to "ممبران کی فہرست اور نگران کی فہرست PDF فارمیٹ میں ڈاؤن لوڈ کریں۔"')
content = content.replace('"exportMembersBtn" to "ممبران کی ادائیگی ایکسپورٹ کریں (PDF)"', '"exportMembersBtn" to "ممبران کی فہرست ڈاؤن لوڈ کریں"')
content = content.replace('"exportCustodiansBtn" to "نگرانوں کی تاریخ ایکسپورٹ کریں (PDF)"', '"exportCustodiansBtn" to "نگران کی فہرست ڈاؤن لوڈ کریں"')

with open("app/src/main/java/com/example/ui/Translations.kt", "w") as f:
    f.write(content)
print("Updated Translations.kt")
