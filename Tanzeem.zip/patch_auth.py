import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

replacement = """        setContent {
            MyApplicationTheme {
                val currentDensity = androidx.compose.ui.platform.LocalDensity.current
                val customDensity = androidx.compose.ui.unit.Density(
                    density = currentDensity.density,
                    fontScale = currentDensity.fontScale * 0.8f
                )
                androidx.compose.runtime.CompositionLocalProvider(
                    androidx.compose.ui.platform.LocalDensity provides customDensity
                ) {
                    var isAuthenticated by remember { mutableStateOf(false) }
                    
                    if (isAuthenticated) {
                        val viewModel: TatViewModel = viewModel()
                        MainContent(viewModel)
                    } else {
                        PasswordScreen(onAuthenticated = { isAuthenticated = true })
                    }
                }
            }
        }"""

content = re.sub(r'setContent \{.*?MainContent\(viewModel\)\s*\}\s*\}\s*\}', replacement, content, flags=re.DOTALL)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
print("Auth patched")
