import re

# 1. Remove demo passwords from MainActivity
content = open("app/src/main/java/com/example/MainActivity.kt").read()
content = re.sub(r'val activePassHint = currentCustodian\?\.password \?: "TAT@2026"', '', content)
content = re.sub(r'Text\(\"Demo Password: \$\{activeCustodian\.password\}\"[^\)]+\)', '', content)
content = re.sub(r'if \(isSuperAdmin && custodian\.password\.isNotEmpty\(\)\) \{\s*Text\(\s*text = \"Permanent Password: \$\{custodian\.password\}\"[^\}]+\}\s*\}', '', content)

# 2. Fix Login Logic to be more resilient
# Sometimes firstOrNull picks the wrong one if there's a data glitch. Let's pick the one with highest orderIndex that isCurrent, or just the one whose password matches.
# Actually, if the login fails because of multiple isCurrent, let's just find ANY custodian that matches the password and isCurrent.
login_logic_old = """                                    val currentActive = custodians.firstOrNull { it.isCurrent }
                                    
                                    // Security strictness: ONLY the currently active custodian can log in. 
                                     // Past or future custodians with valid passwords cannot enter.
                                    val isCust = trimmedPass.isNotEmpty() && currentActive != null && currentActive.password == trimmedPass
                                    val isDefaultCust = trimmedPass.isNotEmpty() && currentActive == null && trimmedPass == "TAT@2026"
                                    
                                    val match = isSuper || isCust || isDefaultCust"""

login_logic_new = """                                    val activeCustodians = custodians.filter { it.isCurrent }
                                    val currentActive = activeCustodians.maxByOrNull { it.startDate } // If multiple, pick the newest
                                    
                                    // Security strictness: ONLY the currently active custodian can log in. 
                                    // Past or future custodians with valid passwords cannot enter.
                                    val isCust = trimmedPass.isNotEmpty() && currentActive != null && currentActive.password.trim() == trimmedPass
                                    val isDefaultCust = trimmedPass.isNotEmpty() && currentActive == null && trimmedPass == "TAT@2026"
                                    
                                    val match = isSuper || isCust || isDefaultCust
                                    
                                    // Cleanup rogue isCurrent flags if we successfully log in as the newest active
                                    if (isCust && activeCustodians.size > 1) {
                                        viewModel.cleanupMultipleActiveCustodians(currentActive!!)
                                    }"""
content = content.replace(login_logic_old, login_logic_new)

# Update the display of Current Custodian in Login Dialog
current_cust_display_old = """        val currentCustodian = custodians.firstOrNull { it.isCurrent }
        val activeCustodianName = currentCustodian?.name ?: "No Custodian" """

current_cust_display_new = """        val currentCustodian = custodians.filter { it.isCurrent }.maxByOrNull { it.startDate }
        val activeCustodianName = currentCustodian?.name ?: "No Custodian" """
content = content.replace(current_cust_display_old, current_cust_display_new)

open("app/src/main/java/com/example/MainActivity.kt", "w").write(content)

