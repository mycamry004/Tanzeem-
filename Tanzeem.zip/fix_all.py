import re

# Fix MainActivity.kt
with open('app/src/main/java/com/example/MainActivity.kt', 'r') as f:
    content = f.read()

if 'import com.example.data.AppDevice' not in content:
    content = content.replace('import com.example.data.AppNotification', 'import com.example.data.AppNotification\nimport com.example.data.AppDevice')

target = """    val claims by viewModel.claims.collectAsStateWithLifecycle()
    val poolBalance by viewModel.poolBalance.collectAsStateWithLifecycle()"""

replacement = """    val claims by viewModel.claims.collectAsStateWithLifecycle()
    val poolBalance by viewModel.poolBalance.collectAsStateWithLifecycle()
    val devices by viewModel.devices.collectAsStateWithLifecycle()
    
    val myDevice = devices.find { it.deviceId == viewModel.currentDeviceId }
    if (myDevice?.isBlocked == true) {
        Box(modifier = Modifier.fillMaxSize().background(Color.Black), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(32.dp)) {
                Icon(Icons.Default.Block, contentDescription = "Blocked", tint = Color.Red, modifier = Modifier.size(64.dp))
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = if (isUrdu) "سیکیورٹی وجوہات کی بنا پر اس ڈیوائس کو بلاک کر دیا گیا ہے۔ ایڈمن سے رابطہ کریں۔" else "This device has been blocked for security reasons. Contact admin.",
                    color = Color.White,
                    fontSize = 16.sp,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                )
            }
        }
        return
    }"""

if 'val myDevice = devices.find' not in content:
    content = content.replace(target, replacement)

with open('app/src/main/java/com/example/MainActivity.kt', 'w') as f:
    f.write(content)

# Fix TatViewModel.kt
with open('app/src/main/java/com/example/ui/TatViewModel.kt', 'r') as f:
    content = f.read()

# Fix ambiguity
content = content.replace("import java.util.Locale\n", "")

# Move toggleDeviceBlock inside class
if 'fun toggleDeviceBlock' in content:
    # Find the block and remove it
    block_start = content.find('fun toggleDeviceBlock')
    if block_start != -1:
        # Assuming the function is at the very end
        content = content[:block_start]
        # Insert it before the last closing brace
        last_brace = content.rfind('}')
        if last_brace != -1:
            new_func = """    fun toggleDeviceBlock(deviceId: String, block: Boolean) {
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            repository.toggleDeviceBlock(deviceId, block)
            val actionEng = if (block) "Blocked device: $deviceId" else "Unblocked device: $deviceId"
            val actionUrdu = if (block) "ڈیوائس بلاک کی گئی: $deviceId" else "ڈیوائس ان بلاک کی گئی: $deviceId"
            logAction(actionEng, actionUrdu)
        }
    }
"""
            content = content[:last_brace] + new_func + content[last_brace:]

with open('app/src/main/java/com/example/ui/TatViewModel.kt', 'w') as f:
    f.write(content)
