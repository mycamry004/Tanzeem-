import sys

file_path = "app/src/main/java/com/example/MainActivity.kt"

with open(file_path, "r") as f:
    content = f.read()

target = """                    if (!isAdminMode) {
                        // Locked message for Members
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(RedForfeited.copy(alpha = 0.15f), RoundedCornerShape(8.dp))
                                .border(1.dp, RedForfeited, RoundedCornerShape(8.dp))
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(imageVector = Icons.Default.Lock, contentDescription = "Locked", tint = RedForfeited)
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = if (isUrdu) {
                                    "نیا دعویٰ درج کرنے کے لیے کسٹوڈین لاگ ان درکار ہے۔ آپ ذیل میں تاریخی دعوے دیکھ سکتے ہیں۔"
                                } else {
                                    "Custodian login required to log a new claim. You can review historical claims below."
                                },
                                fontSize = 11.sp,
                                color = TextOffWhite
                            )
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                    }"""

if target in content:
    content = content.replace(target, "", 1)
    with open(file_path, "w") as f:
        f.write(content)
    print("Cleaned successfully!")
else:
    print("Target not found!")
