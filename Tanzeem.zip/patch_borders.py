import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

# Card 1: Community Size Box
target1 = """            // Community Size Box
            Card(
                modifier = Modifier
                    .weight(1f)
                    .height(76.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSlateSurface),
                shape = RoundedCornerShape(8.dp)
            )"""
replacement1 = """            // Community Size Box
            Card(
                modifier = Modifier
                    .weight(1f)
                    .height(76.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSlateSurface),
                border = BorderStroke(1.dp, EmeraldPrimary.copy(alpha = 0.5f)),
                shape = RoundedCornerShape(8.dp)
            )"""
content = content.replace(target1, replacement1)

# Card 2: Claims Settle Box
target2 = """            // Claims processed
            Card(
                modifier = Modifier
                    .weight(1f)
                    .height(76.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSlateSurface),
                shape = RoundedCornerShape(8.dp)
            )"""
replacement2 = """            // Claims processed
            Card(
                modifier = Modifier
                    .weight(1f)
                    .height(76.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSlateSurface),
                border = BorderStroke(1.dp, EmeraldPrimary.copy(alpha = 0.5f)),
                shape = RoundedCornerShape(8.dp)
            )"""
content = content.replace(target2, replacement2)

# Card 3: Collection Progress Chart
target3 = """        // 4. Collection Progress Chart (Circular + Legend)
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .testTag("collection_chart_card"),
            colors = CardDefaults.cardColors(containerColor = DarkSlateSurface),
            shape = RoundedCornerShape(16.dp)
        )"""
replacement3 = """        // 4. Collection Progress Chart (Circular + Legend)
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .testTag("collection_chart_card"),
            colors = CardDefaults.cardColors(containerColor = DarkSlateSurface),
            border = BorderStroke(1.dp, EmeraldPrimary.copy(alpha = 0.5f)),
            shape = RoundedCornerShape(16.dp)
        )"""
content = content.replace(target3, replacement3)

# Card 4: Resident Status Distribution Chart
target4 = """        // 5. Resident Status Distribution Chart
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .testTag("residence_chart_card"),
            colors = CardDefaults.cardColors(containerColor = DarkSlateSurface),
            shape = RoundedCornerShape(16.dp)
        )"""
replacement4 = """        // 5. Resident Status Distribution Chart
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .testTag("residence_chart_card"),
            colors = CardDefaults.cardColors(containerColor = DarkSlateSurface),
            border = BorderStroke(1.dp, EmeraldPrimary.copy(alpha = 0.5f)),
            shape = RoundedCornerShape(16.dp)
        )"""
content = content.replace(target4, replacement4)

# Card 5: Export PDFs Card
target5 = """        // 6. Export PDFs Card
        Card(
            modifier = Modifier
                .fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = DarkSlateSurface),
            shape = RoundedCornerShape(16.dp)
        )"""
replacement5 = """        // 6. Export PDFs Card
        Card(
            modifier = Modifier
                .fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = DarkSlateSurface),
            border = BorderStroke(1.dp, EmeraldPrimary.copy(alpha = 0.5f)),
            shape = RoundedCornerShape(16.dp)
        )"""
content = content.replace(target5, replacement5)

# Card 6: Chronological Payment Ledger
target6 = """        // 7. Chronological Payment Ledger
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .testTag("payment_ledger_card"),
            colors = CardDefaults.cardColors(containerColor = DarkSlateSurface),
            shape = RoundedCornerShape(16.dp)
        )"""
replacement6 = """        // 7. Chronological Payment Ledger
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .testTag("payment_ledger_card"),
            colors = CardDefaults.cardColors(containerColor = DarkSlateSurface),
            border = BorderStroke(1.dp, EmeraldPrimary.copy(alpha = 0.5f)),
            shape = RoundedCornerShape(16.dp)
        )"""
content = content.replace(target6, replacement6)


with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
print("Borders patched successfully")
