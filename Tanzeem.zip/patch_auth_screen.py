import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

password_screen = """
@Composable
fun PasswordScreen(onAuthenticated: () -> Unit) {
    var password by remember { mutableStateOf("") }
    var isError by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkSlateBackground)
    ) {
        // Abstract Background Elements
        androidx.compose.foundation.Canvas(modifier = Modifier.fillMaxSize()) {
            val canvasWidth = size.width
            val canvasHeight = size.height

            // Top abstract shape
            val path1 = androidx.compose.ui.graphics.Path().apply {
                moveTo(canvasWidth, 0f)
                lineTo(canvasWidth - 300f, 0f)
                quadraticBezierTo(canvasWidth - 100f, 150f, canvasWidth, 300f)
                close()
            }
            drawPath(path1, EmeraldPrimary.copy(alpha = 0.2f))
            
            val path2 = androidx.compose.ui.graphics.Path().apply {
                moveTo(canvasWidth, 0f)
                lineTo(canvasWidth - 150f, 0f)
                quadraticBezierTo(canvasWidth - 50f, 80f, canvasWidth, 150f)
                close()
            }
            drawPath(path2, GoldAccent.copy(alpha = 0.3f))

            // Bottom abstract shape
            val path3 = androidx.compose.ui.graphics.Path().apply {
                moveTo(0f, canvasHeight)
                lineTo(300f, canvasHeight)
                quadraticBezierTo(100f, canvasHeight - 150f, 0f, canvasHeight - 300f)
                close()
            }
            drawPath(path3, EmeraldPrimary.copy(alpha = 0.15f))
            
            val path4 = androidx.compose.ui.graphics.Path().apply {
                moveTo(0f, canvasHeight)
                lineTo(150f, canvasHeight)
                quadraticBezierTo(50f, canvasHeight - 80f, 0f, canvasHeight - 150f)
                close()
            }
            drawPath(path4, GoldAccent.copy(alpha = 0.25f))
        }

        // Main Content
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // Logo
            Surface(
                shape = CircleShape,
                color = DarkSlateSurface,
                border = BorderStroke(2.dp, GoldAccent.copy(alpha = 0.5f)),
                shadowElevation = 8.dp,
                modifier = Modifier.size(120.dp)
            ) {
                Image(
                    painter = painterResource(id = R.drawable.tat_emblem),
                    contentDescription = "Logo",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize().clip(CircleShape)
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            Text(
                text = "Tanzeem Amanat Taqseem",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                color = EmeraldPrimary,
                textAlign = TextAlign.Center
            )
            Text(
                text = "تنظیم امانت تقسیم",
                fontSize = 20.sp,
                color = TextMuted,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(48.dp))

            OutlinedTextField(
                value = password,
                onValueChange = { 
                    password = it
                    isError = false
                },
                label = { Text("Enter Password", color = TextMuted) },
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                singleLine = true,
                isError = isError,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = EmeraldPrimary,
                    unfocusedBorderColor = TextMuted.copy(alpha = 0.5f),
                    focusedTextColor = TextOffWhite,
                    unfocusedTextColor = TextOffWhite,
                    errorBorderColor = RedForfeited,
                    errorTextColor = RedForfeited
                ),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth(),
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = "Lock",
                        tint = if (isError) RedForfeited else EmeraldPrimary
                    )
                }
            )

            if (isError) {
                Text(
                    text = "Incorrect password. Please try again.",
                    color = RedForfeited,
                    fontSize = 12.sp,
                    modifier = Modifier
                        .align(Alignment.Start)
                        .padding(start = 16.dp, top = 4.dp)
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            Button(
                onClick = { 
                    if (password == "TAT@2026") {
                        onAuthenticated()
                    } else {
                        isError = true
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
            ) {
                Text(
                    text = "Unlock",
                    color = Color.White,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}
"""

content = content.replace("@Composable\nfun MainContent(viewModel: TatViewModel) {", password_screen + "\n@Composable\nfun MainContent(viewModel: TatViewModel) {")

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
print("Screen Added")
