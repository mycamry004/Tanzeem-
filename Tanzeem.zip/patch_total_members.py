import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

target = """            // Total Registered Members
            Card(
                modifier = Modifier
                    .weight(1f)
                    .height(76.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSlateSurface),
                shape = RoundedCornerShape(8.dp)
            )"""

replacement = """            // Total Registered Members
            Card(
                modifier = Modifier
                    .weight(1f)
                    .height(76.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSlateSurface),
                border = BorderStroke(1.dp, EmeraldPrimary.copy(alpha = 0.5f)),
                shape = RoundedCornerShape(8.dp)
            )"""

if target in content:
    content = content.replace(target, replacement)
    with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
        f.write(content)
    print("Replaced Total Registered Members borders")
else:
    print("Not found! Fallback to regex or manual")
