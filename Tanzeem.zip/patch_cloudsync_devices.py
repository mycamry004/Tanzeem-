import re

with open('app/src/main/java/com/example/data/CloudSyncManager.kt', 'r') as f:
    content = f.read()

target = """data class CloudBackup(
    val timestamp: Long = 0L,
    val members: List<Member> = emptyList(),
    val claims: List<Claim> = emptyList(),
    val custodians: List<Custodian> = emptyList(),
    val notifications: List<AppNotification> = emptyList()
)"""

replacement = """data class CloudBackup(
    val timestamp: Long = 0L,
    val members: List<Member> = emptyList(),
    val claims: List<Claim> = emptyList(),
    val custodians: List<Custodian> = emptyList(),
    val notifications: List<AppNotification> = emptyList(),
    val devices: List<AppDevice> = emptyList()
)"""

content = content.replace(target, replacement)

target2 = """    suspend fun syncToCloud(
        members: List<Member>,
        claims: List<Claim>,
        custodians: List<Custodian>,
        notifications: List<AppNotification> = emptyList()
    ): Pair<Boolean, String> {"""

replacement2 = """    suspend fun syncToCloud(
        members: List<Member>,
        claims: List<Claim>,
        custodians: List<Custodian>,
        notifications: List<AppNotification> = emptyList(),
        devices: List<AppDevice> = emptyList()
    ): Pair<Boolean, String> {"""

content = content.replace(target2, replacement2)

target3 = """            val state = CloudBackup(
                timestamp = System.currentTimeMillis(),
                members = members,
                claims = claims,
                custodians = custodians,
                notifications = notifications
            )"""

replacement3 = """            val state = CloudBackup(
                timestamp = System.currentTimeMillis(),
                members = members,
                claims = claims,
                custodians = custodians,
                notifications = notifications,
                devices = devices
            )"""

content = content.replace(target3, replacement3)

with open('app/src/main/java/com/example/data/CloudSyncManager.kt', 'w') as f:
    f.write(content)
