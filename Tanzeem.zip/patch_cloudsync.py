import re

with open('app/src/main/java/com/example/data/CloudSyncManager.kt', 'r') as f:
    content = f.read()

target = """            val snapshot = db?.collection(COLLECTION_DATA)?.document(DOC_CURRENT)?.get()?.await()
            if (snapshot != null && snapshot.exists()) {
                snapshot.toObject(CloudBackup::class.java)
            } else {
                null
            }"""

replacement = """            val snapshot = db?.collection(COLLECTION_DATA)?.document(DOC_CURRENT)?.get()?.await()
            if (snapshot != null && snapshot.exists()) {
                snapshot.toObject(CloudBackup::class.java)
            } else {
                // Fallback to latest backup if DOC_CURRENT is missing
                val backups = db?.collection(COLLECTION_DATA)?.document(DOC_CURRENT)
                    ?.collection(COLLECTION_BACKUPS)
                    ?.orderBy("timestamp", Query.Direction.DESCENDING)
                    ?.limit(1)
                    ?.get()?.await()
                if (backups != null && !backups.isEmpty) {
                    backups.documents[0].toObject(CloudBackup::class.java)
                } else {
                    null
                }
            }"""

if target in content:
    content = content.replace(target, replacement)
    with open('app/src/main/java/com/example/data/CloudSyncManager.kt', 'w') as f:
        f.write(content)
    print("Patched successfully")
else:
    print("Target not found")
