import re

with open('app/src/main/java/com/example/MainActivity.kt', 'r') as f:
    content = f.read()

target = """                if (measured > maxTextWidth) {
                    val charsToKeep = (maxTextWidth / (measured / if (text.isEmpty()) 1 else text.length)).toInt()
                    if (charsToKeep > 0 && charsToKeep < text.length) {
                        text = text.substring(0, charsToKeep - 2) + ".."
                    }
                }"""

replacement = """                if (measured > maxTextWidth) {
                    val charsToKeep = (maxTextWidth / (measured / if (text.isEmpty()) 1 else text.length)).toInt()
                    if (charsToKeep > 0 && charsToKeep < text.length) {
                        val limit = maxOf(0, charsToKeep - 2)
                        text = text.substring(0, limit) + ".."
                    }
                }"""

content = content.replace(target, replacement)

with open('app/src/main/java/com/example/MainActivity.kt', 'w') as f:
    f.write(content)

