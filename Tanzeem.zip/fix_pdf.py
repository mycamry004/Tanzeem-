with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

content = content.replace('return generatePdf(context, "TAT_Custodian_Rotation_History.pdf", title, headers, data)', 'return generatePdf(context, "TAT_Custodian_Rotation_History.pdf", title, headers, data, "blue")')

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
print("Fixed missing theme argument")
