import re

with open('app/src/main/java/com/example/ui/TatViewModel.kt', 'r') as f:
    content = f.read()

# Add AppNotification import
if 'import com.example.data.AppNotification' not in content:
    content = content.replace('import com.example.data.Member', 'import com.example.data.Member\nimport com.example.data.AppNotification')

# Add allNotifications flow
target_claims = """    val claims: StateFlow<List<Claim>> = repository.allClaims
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())"""

replacement_claims = """    val claims: StateFlow<List<Claim>> = repository.allClaims
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val notifications: StateFlow<List<AppNotification>> = repository.allNotifications
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private fun logAction(msgEng: String, msgUrdu: String) {
        if (!_isSuperAdmin.value) {
            viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
                repository.insertNotification(
                    AppNotification(
                        messageEng = msgEng,
                        messageUrdu = msgUrdu
                    )
                )
            }
        }
    }"""

if "val notifications: StateFlow" not in content:
    content = content.replace(target_claims, replacement_claims)

# Patch addMember
target_add = """            repository.insertMember(
                Member(
                    name = name,
                    qid = qid,
                    phone = phone,
                    status = status,
                    year1Paid = y1,
                    year2Paid = y2,
                    year3Paid = y3,
                    year1PaymentDate = if (y1) today else null,
                    year2PaymentDate = if (y2) today else null,
                    year3PaymentDate = if (y3) today else null
                )
            )"""

replacement_add = """            repository.insertMember(
                Member(
                    name = name,
                    qid = qid,
                    phone = phone,
                    status = status,
                    year1Paid = y1,
                    year2Paid = y2,
                    year3Paid = y3,
                    year1PaymentDate = if (y1) today else null,
                    year2PaymentDate = if (y2) today else null,
                    year3PaymentDate = if (y3) today else null
                )
            )
            logAction(
                "Added new member: $name",
                "نیا ممبر شامل کیا گیا: $name"
            )"""
content = content.replace(target_add, replacement_add)

# Patch deleteMember
target_del = """    fun deleteMember(member: Member) {
        viewModelScope.launch {
            repository.deleteMember(member)
        }
    }"""

replacement_del = """    fun deleteMember(member: Member) {
        viewModelScope.launch {
            repository.deleteMember(member)
            logAction(
                "Deleted member: ${member.name}",
                "ممبر کو حذف کر دیا گیا: ${member.name}"
            )
        }
    }"""
content = content.replace(target_del, replacement_del)

# Patch updateMember (just basic edits or payments)
target_upd = """    fun updateMember(member: Member) {
        viewModelScope.launch {
            repository.updateMember(member)
        }
    }"""

replacement_upd = """    fun updateMember(member: Member) {
        viewModelScope.launch {
            repository.updateMember(member)
            // More granular notification could be added for payments vs edits
            logAction(
                "Updated member: ${member.name}",
                "ممبر کی معلومات اپ ڈیٹ کی گئیں: ${member.name}"
            )
        }
    }"""
content = content.replace(target_upd, replacement_upd)

# Patch addClaim
target_addclaim = """    fun addClaim(claim: Claim) {
        viewModelScope.launch {
            repository.insertClaim(claim)
        }
    }"""

replacement_addclaim = """    fun addClaim(claim: Claim) {
        viewModelScope.launch {
            repository.insertClaim(claim)
            logAction(
                "Processed claim for: ${claim.deceasedName} Amount: ${claim.actualExpenses} QAR",
                "کلیم پر کارروائی کی گئی: ${claim.deceasedName} رقم: ${claim.actualExpenses} QAR"
            )
        }
    }"""
content = content.replace(target_addclaim, replacement_addclaim)

# Patch performHandover
target_handover = """            repository.updateCustodian(updatedNext)
            if (curr != null) {
                val demotedCurr = curr.copy(isCurrent = false)
                repository.updateCustodian(demotedCurr)
            }
        }
    }"""

replacement_handover = """            repository.updateCustodian(updatedNext)
            if (curr != null) {
                val demotedCurr = curr.copy(isCurrent = false)
                repository.updateCustodian(demotedCurr)
            }
            logAction(
                "Custodian handover to: ${next.name} Amount transferred: $currentBalance QAR",
                "نگران کی تبدیلی: ${next.name} کو رقم منتقل کی گئی: $currentBalance QAR"
            )
        }
    }"""
content = content.replace(target_handover, replacement_handover)

with open('app/src/main/java/com/example/ui/TatViewModel.kt', 'w') as f:
    f.write(content)
