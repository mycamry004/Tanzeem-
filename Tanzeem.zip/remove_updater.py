import re
with open('app/src/main/java/com/example/MainActivity.kt', 'r') as f:
    content = f.read()

# Pattern to remove the update check and dialog
pattern = r"    var updateInfo by androidx\.compose\.runtime\.remember \{ androidx\.compose\.runtime\.mutableStateOf<com\.example\.updater\.AutoUpdater\.UpdateInfo\?>\(null\) \}\n\s+androidx\.compose\.runtime\.LaunchedEffect\(Unit\) \{\n\s+val info = com\.example\.updater\.AutoUpdater\.checkForUpdates\(\)\n\s+if \(info\?\.isUpdateAvailable == true\) \{\n\s+updateInfo = info\n\s+\}\n\s+\}\n\s+updateInfo\?\.let \{ info ->[\s\S]*?updateInfo = null \}\n\s+\)\n\s+\}"

content = re.sub(pattern, "", content)

with open('app/src/main/java/com/example/MainActivity.kt', 'w') as f:
    f.write(content)
