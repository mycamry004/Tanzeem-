import re

with open('app/src/main/java/com/example/data/CloudSyncManager.kt', 'r') as f:
    content = f.read()

target_fetch_checkpoints = """    // Fetch available checkpoints (backups)
    suspend fun fetchCheckpoints(): List<String> {
        return try {
            val snapshot = db?.collection(COLLECTION_DATA)
                ?.document(DOC_CURRENT)
                ?.collection(COLLECTION_BACKUPS)
                ?.orderBy("timestamp", Query.Direction.DESCENDING)
                ?.get()
                ?.await()
            snapshot?.documents?.map { it.id } ?: emptyList()
        } catch (e: Exception) {
            Log.d("CloudSync", "Error fetching checkpoints: ${e.message}")
            emptyList()
        }
    }"""

replacement_fetch_checkpoints = """    // Fetch available checkpoints (backups)
    suspend fun fetchCheckpoints(): List<String> {
        return try {
            val snapshot = kotlinx.coroutines.withTimeoutOrNull(5000L) {
                db?.collection(COLLECTION_DATA)
                    ?.document(DOC_CURRENT)
                    ?.collection(COLLECTION_BACKUPS)
                    ?.orderBy("timestamp", Query.Direction.DESCENDING)
                    ?.get()
                    ?.await()
            }
            snapshot?.documents?.map { it.id } ?: emptyList()
        } catch (e: Exception) {
            Log.d("CloudSync", "Error fetching checkpoints: ${e.message}")
            emptyList()
        }
    }"""

if target_fetch_checkpoints in content:
    content = content.replace(target_fetch_checkpoints, replacement_fetch_checkpoints)
    print("Patched fetchCheckpoints")

target_restore = """    // Restore a specific checkpoint
    suspend fun restoreCheckpoint(dateStr: String): CloudBackup? {
        return try {
            val snapshot = db?.collection(COLLECTION_DATA)
                ?.document(DOC_CURRENT)
                ?.collection(COLLECTION_BACKUPS)
                ?.document(dateStr)
                ?.get()
                ?.await()
            if (snapshot != null && snapshot.exists()) {
                snapshot.toObject(CloudBackup::class.java)
            } else {
                null
            }
        } catch (e: Exception) {
            Log.d("CloudSync", "Error restoring checkpoint: ${e.message}")
            null
        }
    }"""

replacement_restore = """    // Restore a specific checkpoint
    suspend fun restoreCheckpoint(dateStr: String): CloudBackup? {
        return try {
            val snapshot = kotlinx.coroutines.withTimeoutOrNull(8000L) {
                db?.collection(COLLECTION_DATA)
                    ?.document(DOC_CURRENT)
                    ?.collection(COLLECTION_BACKUPS)
                    ?.document(dateStr)
                    ?.get()
                    ?.await()
            }
            if (snapshot != null && snapshot.exists()) {
                snapshot.toObject(CloudBackup::class.java)
            } else {
                null
            }
        } catch (e: Exception) {
            Log.d("CloudSync", "Error restoring checkpoint: ${e.message}")
            null
        }
    }"""

if target_restore in content:
    content = content.replace(target_restore, replacement_restore)
    print("Patched restoreCheckpoint")

with open('app/src/main/java/com/example/data/CloudSyncManager.kt', 'w') as f:
    f.write(content)

