import re
with open('app/src/main/java/com/example/MainActivity.kt', 'r') as f:
    content = f.read()

content = content.replace(
    'val params = hashMapOf(android.speech.tts.TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID to "UtteranceId_$i")',
    'val params = java.util.HashMap<String, String>()\n                        params[android.speech.tts.TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID] = "UtteranceId_$i"'
)

with open('app/src/main/java/com/example/MainActivity.kt', 'w') as f:
    f.write(content)
