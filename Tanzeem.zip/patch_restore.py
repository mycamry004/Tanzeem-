import re

with open('app/src/main/java/com/example/ui/TatViewModel.kt', 'r') as f:
    content = f.read()

target = """    fun restoreCheckpoint(dateStr: String) {
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            try {
                val backup = com.example.data.CloudSyncManager.restoreCheckpoint(dateStr)
                if (backup != null) {
                    val dao = database.tanzeemDao()
                    dao.deleteAllMembers()
                    dao.deleteAllClaims()
                    dao.deleteAllCustodians()
                    backup.members.forEach { repository.insertMember(it) }
                    backup.claims.forEach { repository.insertClaim(it) }
                    backup.custodians.forEach { repository.insertCustodian(it) }
                    // Trigger UI update natively via offline-first setup
                    restoreFromCloud()
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }"""

replacement = """    fun restoreCheckpoint(dateStr: String) {
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            try {
                val backup = com.example.data.CloudSyncManager.restoreCheckpoint(dateStr)
                if (backup != null) {
                    // In Cloud-Native, we just overwrite the current_state document in Firebase.
                    // The SnapshotListener in TanzeemRepository will instantly update the UI.
                    com.example.data.CloudSyncManager.syncToCloud(
                        backup.members,
                        backup.claims,
                        backup.custodians
                    )
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }"""

if "fun restoreCheckpoint" in content:
    # Just replace it entirely with regex because there might be slight variations
    pattern = re.compile(r'    fun restoreCheckpoint\(dateStr: String\) \{.*?\n    \}', re.DOTALL)
    content = pattern.sub(replacement.strip(), content)
    with open('app/src/main/java/com/example/ui/TatViewModel.kt', 'w') as f:
        f.write(content)
    print("Patched restoreCheckpoint successfully")
else:
    print("restoreCheckpoint not found")
