import re
content = open("app/src/main/java/com/example/MainActivity.kt").read()

imports = """
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.detectTapGestures
"""
content = content.replace("import androidx.compose.ui.Modifier", "import androidx.compose.ui.Modifier" + imports)
open("app/src/main/java/com/example/MainActivity.kt", "w").write(content)
