import re

with open("app/src/main/java/com/example/data/Custodian.kt", "r") as f:
    content = f.read()
content = content.replace("val name: String,", "val name: String = \"\",")
content = content.replace("val phone: String,", "val phone: String = \"\",")
content = content.replace("val startDate: Long,", "val startDate: Long = 0L,")
content = content.replace("val endDate: Long,", "val endDate: Long = 0L,")
with open("app/src/main/java/com/example/data/Custodian.kt", "w") as f:
    f.write(content)

with open("app/src/main/java/com/example/data/Member.kt", "r") as f:
    content = f.read()
content = content.replace("val name: String,", "val name: String = \"\",")
content = content.replace("val qid: String,", "val qid: String = \"\",")
content = content.replace("val phone: String,", "val phone: String = \"\",")
content = content.replace("val status: String,", "val status: String = \"\",")
with open("app/src/main/java/com/example/data/Member.kt", "w") as f:
    f.write(content)

with open("app/src/main/java/com/example/data/Claim.kt", "r") as f:
    content = f.read()
content = content.replace("val deceasedName: String,", "val deceasedName: String = \"\",")
content = content.replace("val deceasedQid: String,", "val deceasedQid: String = \"\",")
content = content.replace("val residencyStatus: String,", "val residencyStatus: String = \"\",")
content = content.replace("val scenario: String,", "val scenario: String = \"\",")
content = content.replace("val allocatedCap: Double,", "val allocatedCap: Double = 0.0,")
content = content.replace("val actualExpenses: Double,", "val actualExpenses: Double = 0.0,")
with open("app/src/main/java/com/example/data/Claim.kt", "w") as f:
    f.write(content)

