import re
content = open("app/src/main/java/com/example/MainActivity.kt").read()

checkbox_pattern = r"if\s*\(isSuperAdmin\)\s*\{\s*IconButton\(\s*onClick\s*=\s*\{\s*if\s*\(!isCurrent\)\s*\{\s*viewModel\.forceActiveCustodian\(custodian\)\s*android\.widget\.Toast\.makeText\(context,\s*\"[^"]+\",\s*android\.widget\.Toast\.LENGTH_SHORT\)\.show\(\)\s*\}\s*\},\s*modifier\s*=\s*Modifier\.size\(24\.dp\)\.testTag\(\"make_active_custodian_button\"\)\s*\)\s*\{\s*Icon\(\s*imageVector\s*=\s*if\s*\(isCurrent\)\s*Icons\.Default\.CheckBox\s*else\s*Icons\.Default\.CheckBoxOutlineBlank,\s*contentDescription\s*=\s*\"Make Active\",\s*tint\s*=\s*if\s*\(isCurrent\)\s*EmeraldPrimary\s*else\s*TextMuted,\s*modifier\s*=\s*Modifier\.size\(20\.dp\)\s*\)\s*\}\s*Spacer\(modifier\s*=\s*Modifier\.width\(4\.dp\)\)"

content = re.sub(checkbox_pattern, "if (isSuperAdmin) {", content, flags=re.DOTALL)

open("app/src/main/java/com/example/MainActivity.kt", "w").write(content)
