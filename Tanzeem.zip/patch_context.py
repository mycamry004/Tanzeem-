import re

with open('app/src/main/java/com/example/MainActivity.kt', 'r') as f:
    content = f.read()

target = """    val df = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())
    LazyColumn("""
    
replacement = """    val df = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())
    val context = LocalContext.current
    LazyColumn("""

content = content.replace(target, replacement)

with open('app/src/main/java/com/example/MainActivity.kt', 'w') as f:
    f.write(content)
