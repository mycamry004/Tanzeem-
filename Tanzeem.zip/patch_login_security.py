import re
content = open("app/src/main/java/com/example/MainActivity.kt").read()

pattern = r"onClick = \{\s*val trimmedPass = enteredPassword\.trim\(\)\s*val isSuper = trimmedPass\.isNotEmpty\(\) && trimmedPass == \"Tanzeem004\"\s*val currentActive = custodians\.firstOrNull \{ it\.isCurrent \}\s*val matchedCustodian = if \(trimmedPass\.isNotEmpty\(\)\) custodians\.firstOrNull \{ it\.password == trimmedPass \} else null\s*val isCust = matchedCustodian != null\s*val isDefaultCust = trimmedPass\.isNotEmpty\(\) && currentActive == null && trimmedPass == \"TAT@2026\"\s*val match = isSuper \|\| isCust \|\| isDefaultCust\s*if \(match\) \{\s*if \(matchedCustodian != null && !matchedCustodian\.isCurrent\) \{\s*// Failsafe: if they logged in with a valid custodian password but the system didn't mark them active yet, self-heal\.\s*viewModel\.forceActiveCustodian\(matchedCustodian\)\s*\}\s*viewModel\.setAdminMode\(true\)"

replacement = """onClick = {
                                    val trimmedPass = enteredPassword.trim()
                                    val isSuper = trimmedPass.isNotEmpty() && trimmedPass == "Tanzeem004"
                                    val currentActive = custodians.firstOrNull { it.isCurrent }
                                    
                                    // Security strictness: ONLY the currently active custodian can log in. 
                                    // Past or future custodians with valid passwords cannot enter.
                                    val isCust = trimmedPass.isNotEmpty() && currentActive != null && currentActive.password == trimmedPass
                                    val isDefaultCust = trimmedPass.isNotEmpty() && currentActive == null && trimmedPass == "TAT@2026"
                                    
                                    val match = isSuper || isCust || isDefaultCust
                                    if (match) {
                                        viewModel.setAdminMode(true)"""

content = re.sub(pattern, replacement, content, flags=re.DOTALL)
open("app/src/main/java/com/example/MainActivity.kt", "w").write(content)
