import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

# First replace the exportMembersPdf function
export_members_target = """fun exportMembersPdf(context: android.content.Context, members: List<Member>, isUrdu: Boolean): java.io.File {
    val title = if (isUrdu) "رپورٹ ممبران" else "Member Ledger"
    val headers = listOf("ID", "Name", "QID", "Phone", "Status", "Y1", "Y2", "Y3")
    val data = members.map { m ->
        listOf(
            m.id.toString(),
            m.name,
            m.qid,
            m.phone,
            when(m.status) {
                "Active Qatar" -> "Active"
                "On Vacation" -> "Vacation"
                else -> "Left"
            },
            if (m.year1Paid) "Yes" else "No",
            if (m.year2Paid) "Yes" else "No",
            if (m.year3Paid) "Yes" else "No"
        )
    }
    return generatePdf(context, "TAT_Members_Payment_Summary.pdf", title, headers, data, "orange")
}"""

export_members_new = """fun exportMembersPdf(context: android.content.Context, members: List<Member>, isUrdu: Boolean): java.io.File {
    val title = if (isUrdu) "رپورٹ ممبران" else "Member Ledger"
    val headers = listOf("ID", "Name", "QID", "Phone", "Status", "Year 1", "Year 2", "Year 3")
    val colWeights = listOf(0.05f, 0.2f, 0.15f, 0.2f, 0.1f, 0.1f, 0.1f, 0.1f)
    val df = java.text.SimpleDateFormat("dd MMM yy", java.util.Locale.US)
    val data = members.map { m ->
        val y1Date = if (m.year1Paid && m.year1PaymentDate != null) m.year1PaymentDate else ""
        val y2Date = if (m.year2Paid && m.year2PaymentDate != null) m.year2PaymentDate else ""
        val y3Date = if (m.year3Paid && m.year3PaymentDate != null) m.year3PaymentDate else ""
        
        listOf(
            m.id.toString(),
            m.name,
            m.qid,
            m.phone,
            when(m.status) {
                "Active Qatar" -> "Active"
                "On Vacation" -> "Vacation"
                else -> "Left"
            },
            if (m.year1Paid) "Yes${if (y1Date.isNotEmpty()) "\\n$y1Date" else ""}" else "No",
            if (m.year2Paid) "Yes${if (y2Date.isNotEmpty()) "\\n$y2Date" else ""}" else "No",
            if (m.year3Paid) "Yes${if (y3Date.isNotEmpty()) "\\n$y3Date" else ""}" else "No"
        )
    }
    return generatePdf(context, "TAT_Members_Payment_Summary.pdf", title, headers, data, "orange", colWeights)
}"""

content = content.replace(export_members_target, export_members_new)

export_cust_target = """fun exportCustodiansPdf(context: android.content.Context, custodians: List<Custodian>, isUrdu: Boolean): java.io.File {
    val title = if (isUrdu) "رپورٹ نگران" else "Custodian History"
    val headers = listOf("Index", "Name", "Phone", "Start Date", "End Date", "Status")
    val df = java.text.SimpleDateFormat("dd MMM yy", java.util.Locale.US)
    val data = custodians.map { c ->
        listOf(
            c.orderIndex.toString(),
            c.name,
            c.phone,
            df.format(java.util.Date(c.startDate)),
            df.format(java.util.Date(c.endDate)),
            if (c.isCurrent) "Active" else "Past/Sch"
        )
    }
    return generatePdf(context, "TAT_Custodian_Rotation_History.pdf", title, headers, data, "blue")
}"""

export_cust_new = """fun exportCustodiansPdf(context: android.content.Context, custodians: List<Custodian>, isUrdu: Boolean): java.io.File {
    val title = if (isUrdu) "رپورٹ نگران" else "Custodian History"
    val headers = listOf("Index", "Name", "Phone", "Start Date", "End Date", "Status")
    val colWeights = listOf(0.1f, 0.25f, 0.2f, 0.15f, 0.15f, 0.15f)
    val df = java.text.SimpleDateFormat("dd MMM yy", java.util.Locale.US)
    val data = custodians.map { c ->
        val statusStr = when {
            c.isCurrent -> "Active"
            c.startDate > System.currentTimeMillis() -> "Next in line"
            else -> "Past"
        }
        listOf(
            c.orderIndex.toString(),
            c.name,
            c.phone,
            df.format(java.util.Date(c.startDate)),
            df.format(java.util.Date(c.endDate)),
            statusStr
        )
    }
    return generatePdf(context, "TAT_Custodian_Rotation_History.pdf", title, headers, data, "blue", colWeights)
}"""

content = content.replace(export_cust_target, export_cust_new)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
print("Replaced export functions")

