import sys
import re

file_path = "app/src/main/java/com/example/MainActivity.kt"

with open(file_path, "r") as f:
    content = f.read()

# We want to replace everything from fun generatePdf up to the end of sharePdfFile.
# So we'll use a regex to match both functions.

pattern = re.compile(r"fun generatePdf.*?fun sharePdfFile.*?\}\s*\}", re.DOTALL)
match = pattern.search(content)

if not match:
    print("Could not find the target functions.")
    sys.exit(1)

replacement = """fun generatePdf(context: android.content.Context, filename: String, title: String, headers: List<String>, data: List<List<String>>): java.io.File {
    val pdfDocument = android.graphics.pdf.PdfDocument()
    // Make the page landscape for better table viewing
    val pageWidth = 842
    val pageHeight = 595
    
    val pageInfo = android.graphics.pdf.PdfDocument.PageInfo.Builder(pageWidth, pageHeight, 1).create()
    var page = pdfDocument.startPage(pageInfo)
    var canvas = page.canvas
    
    // Paints
    val paintPrimary = android.graphics.Paint().apply {
        color = android.graphics.Color.parseColor("#059669") // EmeraldPrimary
    }
    val paintWhiteText = android.graphics.Paint().apply {
        color = android.graphics.Color.WHITE
        textSize = 18f
        typeface = android.graphics.Typeface.create(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD)
        isAntiAlias = true
    }
    val paintHeaderText = android.graphics.Paint().apply {
        color = android.graphics.Color.WHITE
        textSize = 12f
        typeface = android.graphics.Typeface.create(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD)
        isAntiAlias = true
    }
    val paintCellText = android.graphics.Paint().apply {
        color = android.graphics.Color.parseColor("#1E293B") // Dark text
        textSize = 11f
        typeface = android.graphics.Typeface.create(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.NORMAL)
        isAntiAlias = true
    }
    val paintRowBg = android.graphics.Paint().apply {
        color = android.graphics.Color.parseColor("#F8FAFC") // Light gray for striped rows
    }
    val paintRowBgAlt = android.graphics.Paint().apply {
        color = android.graphics.Color.parseColor("#F1F5F9") // Slightly darker
    }
    val paintBorder = android.graphics.Paint().apply {
        color = android.graphics.Color.parseColor("#CBD5E1")
        style = android.graphics.Paint.Style.STROKE
        strokeWidth = 1f
    }
    
    val marginLeft = 40f
    val marginRight = 40f
    val marginTop = 40f
    val marginBottom = 40f
    val contentWidth = pageWidth - marginLeft - marginRight
    
    // Helper function to draw header
    fun drawPageHeader(c: android.graphics.Canvas): Float {
        val headerHeight = 60f
        c.drawRect(marginLeft, marginTop, pageWidth - marginRight, marginTop + headerHeight, paintPrimary)
        
        val titleWidth = paintWhiteText.measureText(title)
        c.drawText(title, marginLeft + 20f, marginTop + (headerHeight / 1.5f), paintWhiteText)
        
        val dateText = "Generated: ${java.text.SimpleDateFormat("MMM dd, yyyy - HH:mm", java.util.Locale.getDefault()).format(java.util.Date())}"
        val dateWidth = paintHeaderText.measureText(dateText)
        c.drawText(dateText, pageWidth - marginRight - dateWidth - 20f, marginTop + (headerHeight / 1.6f), paintHeaderText)
        
        return marginTop + headerHeight + 20f
    }
    
    var currentY = drawPageHeader(canvas)
    
    // Draw table headers
    val colWidths = FloatArray(headers.size)
    var totalHeaderWeight = 0f
    // Simple logic: if fewer columns, distribute evenly. 
    val columnWidth = contentWidth / headers.size.toFloat()
    for (i in headers.indices) colWidths[i] = columnWidth
    
    val headerRowHeight = 30f
    canvas.drawRect(marginLeft, currentY, pageWidth - marginRight, currentY + headerRowHeight, paintPrimary)
    for ((index, header) in headers.withIndex()) {
        val cellX = marginLeft + (index * columnWidth)
        canvas.drawText(header, cellX + 10f, currentY + 20f, paintHeaderText)
        // Vertical dividers
        if (index > 0) {
            canvas.drawLine(cellX, currentY, cellX, currentY + headerRowHeight, paintBorder)
        }
    }
    canvas.drawRect(marginLeft, currentY, pageWidth - marginRight, currentY + headerRowHeight, paintBorder)
    
    currentY += headerRowHeight
    
    // Draw rows
    val rowHeight = 25f
    for ((rowIndex, row) in data.withIndex()) {
        // Pagination
        if (currentY + rowHeight > pageHeight - marginBottom) {
            // Draw page footer before closing
            pdfDocument.finishPage(page)
            page = pdfDocument.startPage(pageInfo)
            canvas = page.canvas
            currentY = drawPageHeader(canvas)
            
            // Re-draw table headers on new page
            canvas.drawRect(marginLeft, currentY, pageWidth - marginRight, currentY + headerRowHeight, paintPrimary)
            for ((index, header) in headers.withIndex()) {
                val cellX = marginLeft + (index * columnWidth)
                canvas.drawText(header, cellX + 10f, currentY + 20f, paintHeaderText)
                if (index > 0) canvas.drawLine(cellX, currentY, cellX, currentY + headerRowHeight, paintBorder)
            }
            canvas.drawRect(marginLeft, currentY, pageWidth - marginRight, currentY + headerRowHeight, paintBorder)
            currentY += headerRowHeight
        }
        
        // Row background
        val bgPaint = if (rowIndex % 2 == 0) paintRowBg else paintRowBgAlt
        canvas.drawRect(marginLeft, currentY, pageWidth - marginRight, currentY + rowHeight, bgPaint)
        
        for ((colIndex, cell) in row.withIndex()) {
            var text = cell
            val maxTextWidth = columnWidth - 20f
            val measured = paintCellText.measureText(text)
            if (measured > maxTextWidth) {
                val charsToKeep = (maxTextWidth / (measured / text.length)).toInt()
                if (charsToKeep > 0 && charsToKeep < text.length) {
                    text = text.substring(0, charsToKeep - 2) + ".."
                }
            }
            
            val cellX = marginLeft + (colIndex * columnWidth)
            canvas.drawText(text, cellX + 10f, currentY + 17f, paintCellText)
            
            // Vertical dividers
            if (colIndex > 0) {
                canvas.drawLine(cellX, currentY, cellX, currentY + rowHeight, paintBorder)
            }
        }
        canvas.drawRect(marginLeft, currentY, pageWidth - marginRight, currentY + rowHeight, paintBorder)
        currentY += rowHeight
    }
    
    pdfDocument.finishPage(page)
    val file = java.io.File(context.externalCacheDir, filename)
    pdfDocument.writeTo(java.io.FileOutputStream(file))
    pdfDocument.close()
    
    return file
}

fun sharePdfFile(context: android.content.Context, file: java.io.File) {
    try {
        val uri = androidx.core.content.FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )
        val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(android.content.Intent.EXTRA_SUBJECT, file.name.replace(".pdf", " Report"))
            putExtra(android.content.Intent.EXTRA_STREAM, uri)
            addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(android.content.Intent.createChooser(intent, "Export PDF Report"))
    } catch (e: Exception) {
        e.printStackTrace()
        android.widget.Toast.makeText(context, "Export failed. Please check permissions.", android.widget.Toast.LENGTH_LONG).show()
    }
}"""

new_content = content[:match.start()] + replacement + content[match.end():]

with open(file_path, "w") as f:
    f.write(new_content)
print("Patched successfully!")
