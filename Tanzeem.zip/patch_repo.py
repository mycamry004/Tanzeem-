import re
content = open("app/src/main/java/com/example/data/TanzeemRepository.kt").read()
if "fun updateCustodiansList" not in content:
    func = """
    suspend fun updateCustodiansList(newCustodians: List<Custodian>) {
        try {
            waitUntilLoaded()
            updateStateAndSync(currentBackup.copy(custodians = newCustodians))
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
    """
    content = content.replace("suspend fun updateCustodian", func + "\n    suspend fun updateCustodian")
    open("app/src/main/java/com/example/data/TanzeemRepository.kt", "w").write(content)
