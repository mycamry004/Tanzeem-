import re

content = open("app/src/main/java/com/example/data/TanzeemRepository.kt").read()

force_pattern = r"suspend fun forceActiveCustodian\(newActive: Custodian\) \{\s*try\s*\{\s*waitUntilLoaded\(\)\s*val newCustodians = currentBackup\.custodians\.map \{\s*val matches = if \(newActive\.id != 0L\) it\.id == newActive\.id else \(it\.name == newActive\.name && it\.phone == newActive\.phone\)\s*if \(matches\) it\.copy\(isCurrent = true, tempPassword = \"\"\)\s*else it\.copy\(isCurrent = false\)\s*\}\s*updateStateAndSync\(currentBackup\.copy\(custodians = newCustodians\)\)\s*\} catch \(e: Exception\) \{\s*e\.printStackTrace\(\)\s*\}\s*\}"

new_force = """suspend fun forceActiveCustodian(newActive: Custodian) {
        try {
            waitUntilLoaded()
            android.util.Log.d("TanzeemRepo", "forceActiveCustodian called for ${newActive.name}, id=${newActive.id}")
            val newCustodians = currentBackup.custodians.map {
                val matches = if (newActive.id != 0L) it.id == newActive.id else (it.name == newActive.name && it.phone == newActive.phone)
                android.util.Log.d("TanzeemRepo", "Checking ${it.name} id=${it.id}. Matches: $matches")
                if (matches) it.copy(isCurrent = true, tempPassword = "")
                else it.copy(isCurrent = false)
            }
            updateStateAndSync(currentBackup.copy(custodians = newCustodians))
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }"""

if "forceActiveCustodian called for" not in content:
    content = re.sub(force_pattern, new_force, content)
    open("app/src/main/java/com/example/data/TanzeemRepository.kt", "w").write(content)
