import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

target = """                                                Text(
                                                    text = if (isUrdu) "ایپل ڈیوائسز کے لیے (iPhone/iPad):" else "For Apple Devices (iPhone/iPad):",
                                                    color = GoldAccent,
                                                    fontSize = 12.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    modifier = Modifier.padding(bottom = 4.dp)
                                                )
                                                Text(
                                                    text = if (isUrdu) {
                                                        "چونکہ اینڈرائیڈ ایپس آئی فون پر نہیں چلتیں، ہم نے اس کے لیے ایک خصوصی ویب ایپ (PWA) تیار کی ہے۔ یہ ویب ورژن اس اینڈرائیڈ ایپ کے ساتھ مکمل طور پر مطابقت پذیر (fully synced) ہے اور اس میں تمام خصوصیات موجود ہیں۔\n\nصارفین اسے اپنے آئی فون کے Safari براؤزر میں کھول کر 'Add to Home Screen' کر سکتے ہیں تاکہ یہ بالکل عام ایپ کی طرح کام کرے۔"
                                                    } else {
                                                        "Since Android apps don't run on iPhones natively, we have built a beautiful synced Web App (PWA) with the exact same features. Any data changes are instantly synchronized between Android and Apple devices.\n\nApple users can open this link in Safari on their iPhone, click the Share button, and select 'Add to Home Screen' to save it as a native-feeling app."
                                                    },
                                                    color = TextOffWhite,
                                                    fontSize = 11.sp,
                                                    lineHeight = 16.sp,
                                                    modifier = Modifier.padding(bottom = 16.dp)
                                                )"""

replacement = """                                                com.example.ui.ApplePwaTutorial(
                                                    isUrdu = isUrdu,
                                                    primaryColor = GoldAccent,
                                                    surfaceColor = DarkSlateSurfaceVariant,
                                                    textColor = TextOffWhite,
                                                    mutedColor = TextMuted
                                                )
                                                Spacer(modifier = Modifier.height(16.dp))"""

if target in content:
    content = content.replace(target, replacement)
    with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
        f.write(content)
    print("Patched Apple Dialog successfully")
else:
    print("Target not found")
