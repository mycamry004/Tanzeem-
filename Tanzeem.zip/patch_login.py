import re
content = open("app/src/main/java/com/example/MainActivity.kt").read()

pattern = r"onClick = \{\s*val isSuper = enteredPassword\.isNotBlank\(\) && enteredPassword == \"Tanzeem004\"\s*val currentActive = custodians\.firstOrNull \{ it\.isCurrent \}\s*val isCust = enteredPassword\.isNotBlank\(\) && currentActive != null && currentActive\.password == enteredPassword\s*val isDefaultCust = enteredPassword\.isNotBlank\(\) && currentActive == null && enteredPassword == \"TAT@2026\"\s*val match = isSuper \|\| isCust \|\| isDefaultCust\s*if \(match\) \{"

replacement = """onClick = {
                                    val trimmedPass = enteredPassword.trim()
                                    val isSuper = trimmedPass.isNotEmpty() && trimmedPass == "Tanzeem004"
                                    val currentActive = custodians.firstOrNull { it.isCurrent }
                                    val matchedCustodian = if (trimmedPass.isNotEmpty()) custodians.firstOrNull { it.password == trimmedPass } else null
                                    
                                    val isCust = matchedCustodian != null
                                    val isDefaultCust = trimmedPass.isNotEmpty() && currentActive == null && trimmedPass == "TAT@2026"
                                    val match = isSuper || isCust || isDefaultCust
                                    if (match) {
                                        if (matchedCustodian != null && !matchedCustodian.isCurrent) {
                                            // Failsafe: if they logged in with a valid custodian password but the system didn't mark them active yet, self-heal.
                                            viewModel.forceActiveCustodian(matchedCustodian)
                                        }"""

content = re.sub(pattern, replacement, content, flags=re.DOTALL)
open("app/src/main/java/com/example/MainActivity.kt", "w").write(content)
