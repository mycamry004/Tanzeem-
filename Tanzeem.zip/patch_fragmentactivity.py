import re
with open('app/src/main/java/com/example/MainActivity.kt', 'r') as f:
    content = f.read()

content = content.replace("class MainActivity : ComponentActivity()", "class MainActivity : androidx.fragment.app.FragmentActivity()")
with open('app/src/main/java/com/example/MainActivity.kt', 'w') as f:
    f.write(content)
