import re

content = open("app/src/main/java/com/example/MainActivity.kt").read()

# Replace the simple AlertDialog for notifications with a beautifully designed ModalBottomSheet or a better dialog

notif_dialog_old = """    if (showNotifications) {
        val notifications by viewModel.notifications.collectAsState()
        AlertDialog(
            onDismissRequest = { showNotifications = false },
            containerColor = DarkSlateSurface,
            title = {
                Text(
                    text = if (isUrdu) "نوٹیفیکیشنز" else "Notifications",
                    color = Color.White,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                if (notifications.isEmpty()) {
                    Text(
                        text = if (isUrdu) "کوئی نوٹیفکیشن نہیں ہے" else "No recent notifications",
                        color = TextOffWhite
                    )
                } else {
                    LazyColumn(modifier = Modifier.fillMaxWidth().heightIn(max = 400.dp)) {
                        // Synthetic periodic status
                        item {
                            val totalMembers = members.size
                            val currentBal = poolBalance
                            Column(modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
                                Text(
                                    text = if (isUrdu) "موجودہ فنڈ اسٹیٹس" else "Current Fund Status",
                                    color = GoldAccent,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = if (isUrdu) "کل ممبران: $totalMembers | کل کیش: ${String.format(java.util.Locale.US, "%,.2f", currentBal)} QAR" else "Total Members: $totalMembers | Total Cash: ${String.format(java.util.Locale.US, "%,.2f", currentBal)} QAR",
                                    color = Color.White,
                                    fontSize = 14.sp
                                )
                                HorizontalDivider(color = Color.White.copy(alpha = 0.1f), modifier = Modifier.padding(top = 8.dp))
                            }
                        }
                        
                        items(notifications.sortedByDescending { it.timestamp }) { notif ->
                            val sdf = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault())
                            val timeStr = sdf.format(Date(notif.timestamp))
                            Column(modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
                                Text(
                                    text = timeStr,
                                    color = GoldAccent,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = if (isUrdu) notif.messageUrdu else notif.messageEng,
                                    color = Color.White,
                                    fontSize = 14.sp
                                )
                                HorizontalDivider(color = Color.White.copy(alpha = 0.1f), modifier = Modifier.padding(top = 8.dp))
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showNotifications = false }) {
                    Text(text = if (isUrdu) "بند کریں" else "Close", color = TextOffWhite)
                }
            }
        )
    }"""

notif_dialog_new = """    if (showNotifications) {
        val notifications by viewModel.notifications.collectAsState()
        var selectedNotification by remember { mutableStateOf<com.example.data.AppNotification?>(null) }
        
        Dialog(onDismissRequest = { showNotifications = false }) {
            Card(
                colors = CardDefaults.cardColors(containerColor = DarkSlateSurface),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, GoldAccent.copy(alpha = 0.5f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 600.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = if (isUrdu) "نوٹیفیکیشنز" else "Notifications",
                        color = Color.White,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(bottom = 12.dp)
                    )
                    
                    if (notifications.isEmpty()) {
                        Text(
                            text = if (isUrdu) "کوئی نوٹیفکیشن نہیں ہے" else "No recent notifications",
                            color = TextOffWhite,
                            modifier = Modifier.padding(16.dp)
                        )
                    } else {
                        LazyColumn(modifier = Modifier.weight(1f)) {
                            items(notifications.sortedByDescending { it.timestamp }) { notif ->
                                val sdf = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault())
                                val timeStr = sdf.format(Date(notif.timestamp))
                                
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = DarkSlateSurfaceVariant),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 6.dp)
                                        .clickable { selectedNotification = notif }
                                ) {
                                    Row(
                                        modifier = Modifier.padding(12.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Info,
                                            contentDescription = "Notification Icon",
                                            tint = GoldAccent,
                                            modifier = Modifier.size(24.dp)
                                        )
                                        Spacer(modifier = Modifier.width(12.dp))
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = if (isUrdu) notif.messageUrdu else notif.messageEng,
                                                color = Color.White,
                                                fontSize = 14.sp,
                                                maxLines = 2,
                                                overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                                            )
                                            Spacer(modifier = Modifier.height(4.dp))
                                            Text(
                                                text = timeStr,
                                                color = TextMuted,
                                                fontSize = 10.sp
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                    
                    Button(
                        onClick = { showNotifications = false },
                        colors = ButtonDefaults.buttonColors(containerColor = DarkSlateSurfaceVariant),
                        modifier = Modifier.fillMaxWidth().padding(top = 16.dp)
                    ) {
                        Text(text = if (isUrdu) "بند کریں" else "Close", color = Color.White)
                    }
                }
            }
        }
        
        // Detailed Notification Modal
        selectedNotification?.let { notif ->
            Dialog(onDismissRequest = { selectedNotification = null }) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = DarkSlateSurface),
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(2.dp, GoldAccent),
                    modifier = Modifier.fillMaxWidth().padding(16.dp)
                ) {
                    Column(modifier = Modifier.padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.Notifications,
                            contentDescription = "Detail Icon",
                            tint = EmeraldPrimary,
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        val sdf = SimpleDateFormat("EEEE, dd MMMM yyyy\\nhh:mm a", Locale.getDefault())
                        Text(
                            text = sdf.format(Date(notif.timestamp)),
                            color = GoldAccent,
                            fontSize = 12.sp,
                            textAlign = TextAlign.Center,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(24.dp))
                        Text(
                            text = if (isUrdu) notif.messageUrdu else notif.messageEng,
                            color = Color.White,
                            fontSize = 16.sp,
                            textAlign = TextAlign.Center,
                            lineHeight = 24.sp
                        )
                        Spacer(modifier = Modifier.height(32.dp))
                        Button(
                            onClick = { selectedNotification = null },
                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(text = if (isUrdu) "واپس" else "Back", color = Color.White)
                        }
                    }
                }
            }
        }
    }"""

content = content.replace(notif_dialog_old, notif_dialog_new)
open("app/src/main/java/com/example/MainActivity.kt", "w").write(content)
