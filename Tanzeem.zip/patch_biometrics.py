import re
with open('app/src/main/java/com/example/MainActivity.kt', 'r') as f:
    content = f.read()

# 1. Revert custodian card clickable
old_cust_click = """                        .clickable {
                            val isBiometricEnabled = context.getSharedPreferences("tat_prefs", android.content.Context.MODE_PRIVATE).getBoolean("biometric_enabled", false)
                            if (isBiometricEnabled) {
                                try {
                                    val biometricPrompt = androidx.biometric.BiometricPrompt(
                                        context as androidx.fragment.app.FragmentActivity,
                                        androidx.core.content.ContextCompat.getMainExecutor(context),
                                        object : androidx.biometric.BiometricPrompt.AuthenticationCallback() {
                                            override fun onAuthenticationSucceeded(result: androidx.biometric.BiometricPrompt.AuthenticationResult) {
                                                viewModel.setAdminMode(true)
                                                viewModel.setSuperAdminMode(false)
                                                showLoginDialog = false
                                                showWelcomeScreen = false
                                                android.widget.Toast.makeText(context, Translations.getString("welcomeBack", isUrdu), android.widget.Toast.LENGTH_SHORT).show()
                                            }
                                            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                                                showLoginDialog = true
                                            }
                                        }
                                    )
                                    val promptInfo = androidx.biometric.BiometricPrompt.PromptInfo.Builder()
                                        .setTitle(if (isUrdu) "بایومیٹرک لاگ ان" else "Biometric Login")
                                        .setSubtitle(if (isUrdu) "اپنے فنگر پرنٹ کا استعمال کریں" else "Log in using your biometric credential")
                                        .setNegativeButtonText(if (isUrdu) "منسوخ کریں" else "Cancel")
                                        .build()
                                    biometricPrompt.authenticate(promptInfo)
                                } catch (e: Exception) {
                                    showLoginDialog = true
                                }
                            } else {
                                showLoginDialog = true
                            }
                        }
                        .testTag("custodian_access_card"),"""

new_cust_click = """                        .clickable { showLoginDialog = true }
                        .testTag("custodian_access_card"),"""
content = content.replace(old_cust_click, new_cust_click)

# 2. Add Biometric to PasswordScreen
old_pass_screen = """@Composable
fun PasswordScreen(onAuthenticated: () -> Unit) {
    var password by remember { mutableStateOf("") }
    var isError by remember { mutableStateOf(false) }"""

new_pass_screen = """@Composable
fun PasswordScreen(onAuthenticated: () -> Unit) {
    var password by remember { mutableStateOf("") }
    var isError by remember { mutableStateOf(false) }
    
    val context = androidx.compose.ui.platform.LocalContext.current
    androidx.compose.runtime.LaunchedEffect(Unit) {
        val isBiometricEnabled = context.getSharedPreferences("tat_prefs", android.content.Context.MODE_PRIVATE).getBoolean("biometric_enabled", false)
        if (isBiometricEnabled) {
            try {
                val biometricPrompt = androidx.biometric.BiometricPrompt(
                    context as androidx.fragment.app.FragmentActivity,
                    androidx.core.content.ContextCompat.getMainExecutor(context),
                    object : androidx.biometric.BiometricPrompt.AuthenticationCallback() {
                        override fun onAuthenticationSucceeded(result: androidx.biometric.BiometricPrompt.AuthenticationResult) {
                            onAuthenticated()
                        }
                        override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                            // Do nothing, let them use password
                        }
                    }
                )
                val promptInfo = androidx.biometric.BiometricPrompt.PromptInfo.Builder()
                    .setTitle("Biometric Login")
                    .setSubtitle("Log in using your biometric credential")
                    .setNegativeButtonText("Use Password")
                    .build()
                biometricPrompt.authenticate(promptInfo)
            } catch (e: Exception) {
                // Ignore
            }
        }
    }"""
content = content.replace(old_pass_screen, new_pass_screen)

# 3. Fix Biometric Toggle on Welcome Screen
old_bio_toggle = """                // Biometric Toggle
                val isBiometricEnabled = context.getSharedPreferences("tat_prefs", android.content.Context.MODE_PRIVATE).getBoolean("biometric_enabled", false)
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(if (isBiometricEnabled) Color(0xFF059669) else Color.Black.copy(alpha = 0.2f))
                        .border(BorderStroke(1.dp, GoldAccent.copy(alpha = 0.8f)), CircleShape)
                        .clickable { 
                            context.getSharedPreferences("tat_prefs", android.content.Context.MODE_PRIVATE)
                                .edit()
                                .putBoolean("biometric_enabled", !isBiometricEnabled)
                                .apply()
                            android.widget.Toast.makeText(context, if (!isBiometricEnabled) "Biometric Enabled" else "Biometric Disabled", android.widget.Toast.LENGTH_SHORT).show()
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Fingerprint,
                        contentDescription = "Biometric Toggle",
                        tint = if (isBiometricEnabled) Color.White else GoldAccent,
                        modifier = Modifier.size(20.dp)
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                // Theme Toggle"""

new_bio_toggle = """                // Biometric Toggle
                val isBiometricEnabled = context.getSharedPreferences("tat_prefs", android.content.Context.MODE_PRIVATE).getBoolean("biometric_enabled", false)
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(if (isBiometricEnabled) Color(0xFF059669) else Color.Black.copy(alpha = 0.2f))
                        .border(BorderStroke(1.dp, GoldAccent.copy(alpha = 0.8f)), CircleShape)
                        .clickable { 
                            context.getSharedPreferences("tat_prefs", android.content.Context.MODE_PRIVATE)
                                .edit()
                                .putBoolean("biometric_enabled", !isBiometricEnabled)
                                .apply()
                            android.widget.Toast.makeText(context, if (!isBiometricEnabled) "Biometric Enabled" else "Biometric Disabled", android.widget.Toast.LENGTH_SHORT).show()
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Fingerprint,
                        contentDescription = "Biometric Toggle",
                        tint = if (isBiometricEnabled) Color.White else GoldAccent,
                        modifier = Modifier.size(20.dp)
                    )
                    if (!isBiometricEnabled) {
                        androidx.compose.foundation.Canvas(modifier = Modifier.fillMaxSize()) {
                            drawLine(
                                color = Color.Red.copy(alpha = 0.8f),
                                start = androidx.compose.ui.geometry.Offset(size.width * 0.2f, size.height * 0.2f),
                                end = androidx.compose.ui.geometry.Offset(size.width * 0.8f, size.height * 0.8f),
                                strokeWidth = 3f,
                                cap = androidx.compose.ui.graphics.StrokeCap.Round
                            )
                        }
                    }
                }

                // Theme Toggle"""
content = content.replace(old_bio_toggle, new_bio_toggle)

with open('app/src/main/java/com/example/MainActivity.kt', 'w') as f:
    f.write(content)
