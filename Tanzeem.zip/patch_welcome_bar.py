import re

with open('app/src/main/java/com/example/MainActivity.kt', 'r') as f:
    content = f.read()

target = """                // Theme Toggle
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(Color.Black.copy(alpha = 0.2f))
                        .border(BorderStroke(1.dp, GoldAccent.copy(alpha = 0.8f)), CircleShape)
                        .clickable { viewModel.toggleTheme() }
                        .testTag("welcome_theme_toggle"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (isSystemInDarkTheme) Icons.Default.WbSunny else Icons.Default.NightsStay,
                        contentDescription = "Theme Toggle",
                        tint = GoldAccent,
                        modifier = Modifier.size(20.dp)
                    )
                }
                // Notifications
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(Color.Black.copy(alpha = 0.2f))
                        .border(BorderStroke(1.dp, GoldAccent.copy(alpha = 0.8f)), CircleShape)
                        .clickable { showNotifications = true },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Notifications,
                        contentDescription = "Notifications",
                        tint = GoldAccent,
                        modifier = Modifier.size(18.dp)
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
                // Language Selector
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(Color.Black.copy(alpha = 0.2f))
                        .border(BorderStroke(1.dp, GoldAccent.copy(alpha = 0.8f)), CircleShape)
                        .clickable { showLanguageDialog = true }
                        .testTag("welcome_language_toggle"),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = if (isUrdu) "E" else "U",
                        fontWeight = FontWeight.Bold,
                        color = GoldAccent,
                        fontSize = 16.sp
                    )
                }"""

replacement = """                // Theme Toggle
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(Color.Black.copy(alpha = 0.2f))
                        .border(BorderStroke(1.dp, GoldAccent.copy(alpha = 0.8f)), CircleShape)
                        .clickable { viewModel.toggleTheme() }
                        .testTag("welcome_theme_toggle"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (isSystemInDarkTheme) Icons.Default.WbSunny else Icons.Default.NightsStay,
                        contentDescription = "Theme Toggle",
                        tint = GoldAccent,
                        modifier = Modifier.size(20.dp)
                    )
                }
                // Language Selector
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(Color.Black.copy(alpha = 0.2f))
                        .border(BorderStroke(1.dp, GoldAccent.copy(alpha = 0.8f)), CircleShape)
                        .clickable { showLanguageDialog = true }
                        .testTag("welcome_language_toggle"),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = if (isUrdu) "E" else "U",
                        fontWeight = FontWeight.Bold,
                        color = GoldAccent,
                        fontSize = 16.sp
                    )
                }
                // Notifications
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(Color.Black.copy(alpha = 0.2f))
                        .border(BorderStroke(1.dp, GoldAccent.copy(alpha = 0.8f)), CircleShape)
                        .clickable { showNotifications = true },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Notifications,
                        contentDescription = "Notifications",
                        tint = GoldAccent,
                        modifier = Modifier.size(18.dp)
                    )
                }"""

content = content.replace(target, replacement)

with open('app/src/main/java/com/example/MainActivity.kt', 'w') as f:
    f.write(content)
