import re

with open('app/src/main/java/com/example/MainActivity.kt', 'r') as f:
    content = f.read()

# Add imports for Icons
if 'import androidx.compose.material.icons.filled.Notifications' not in content:
    content = content.replace('import androidx.compose.material.icons.filled.Person', 'import androidx.compose.material.icons.filled.Person\nimport androidx.compose.material.icons.filled.Notifications')

# Add showNotifications state to MainApp
target_state = """    var selectedTab by remember { mutableStateOf(0) }
    var isAdminMode by remember { mutableStateOf(false) }"""

replacement_state = """    var selectedTab by remember { mutableStateOf(0) }
    var isAdminMode by remember { mutableStateOf(false) }
    var showNotifications by remember { mutableStateOf(false) }
"""

content = content.replace(target_state, replacement_state)

# We have two language toggle places. Let's find them.
target_lang1 = """                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .border(1.dp, GoldAccent, CircleShape)
                        .clickable { showLanguageDialog = true }
                        .testTag("welcome_language_toggle"),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = if (isUrdu) "E" else "U","""

replacement_lang1 = """                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .border(1.dp, GoldAccent, CircleShape)
                        .clickable { showNotifications = true },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Notifications,
                        contentDescription = "Notifications",
                        tint = GoldAccent,
                        modifier = Modifier.size(20.dp)
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .border(1.dp, GoldAccent, CircleShape)
                        .clickable { showLanguageDialog = true }
                        .testTag("welcome_language_toggle"),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = if (isUrdu) "E" else "U","""

content = content.replace(target_lang1, replacement_lang1)

target_lang2 = """                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .border(1.dp, Color.White.copy(alpha = 0.5f), CircleShape)
                                        .clickable { showLanguageDialog = true }
                                        .testTag("app_language_globe_button"),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = if (isUrdu) "E" else "U","""

replacement_lang2 = """                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .border(1.dp, Color.White.copy(alpha = 0.5f), CircleShape)
                                        .clickable { showNotifications = true },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Notifications,
                                        contentDescription = "Notifications",
                                        tint = Color.White,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .border(1.dp, Color.White.copy(alpha = 0.5f), CircleShape)
                                        .clickable { showLanguageDialog = true }
                                        .testTag("app_language_globe_button"),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = if (isUrdu) "E" else "U","""

content = content.replace(target_lang2, replacement_lang2)

# Insert Notification Dialog component
# Let's insert it before check_points_restore_button or at the end of MainApp
dialog_code = """
    if (showNotifications) {
        val notifications by viewModel.notifications.collectAsState()
        AlertDialog(
            onDismissRequest = { showNotifications = false },
            containerColor = DarkSlateSurface,
            title = {
                Text(
                    text = if (isUrdu) "نوٹیفیکیشنز" else "Notifications",
                    color = Color.White,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                if (notifications.isEmpty()) {
                    Text(
                        text = if (isUrdu) "کوئی نوٹیفکیشن نہیں ہے" else "No recent notifications",
                        color = TextOffWhite
                    )
                } else {
                    LazyColumn(modifier = Modifier.fillMaxWidth().heightIn(max = 400.dp)) {
                        items(notifications.sortedByDescending { it.timestamp }) { notif ->
                            val sdf = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault())
                            val timeStr = sdf.format(Date(notif.timestamp))
                            Column(modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
                                Text(
                                    text = timeStr,
                                    color = GoldAccent,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = if (isUrdu) notif.messageUrdu else notif.messageEng,
                                    color = Color.White,
                                    fontSize = 14.sp
                                )
                                Divider(color = Color.White.copy(alpha = 0.1f), modifier = Modifier.padding(top = 8.dp))
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showNotifications = false }) {
                    Text(text = if (isUrdu) "بند کریں" else "Close", color = TextOffWhite)
                }
            }
        )
    }
"""

if 'if (showNotifications)' not in content:
    # let's insert it before `if (showLanguageDialog)`
    target_dialog = """    if (showLanguageDialog) {"""
    content = content.replace(target_dialog, dialog_code + "\n" + target_dialog)

with open('app/src/main/java/com/example/MainActivity.kt', 'w') as f:
    f.write(content)
