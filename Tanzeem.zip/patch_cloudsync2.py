import re

with open('app/src/main/java/com/example/data/CloudSyncManager.kt', 'r') as f:
    content = f.read()

# Add imports
if 'import kotlinx.coroutines.withTimeout' not in content:
    content = content.replace('import kotlinx.coroutines.tasks.await', 'import kotlinx.coroutines.tasks.await\nimport kotlinx.coroutines.withTimeout')

# wrap set operations in withTimeout
target_sync = """            // Update current state
            db?.collection(COLLECTION_DATA)?.document(DOC_CURRENT)?.set(state)?.await()"""
            
replacement_sync = """            // Update current state with timeout
            kotlinx.coroutines.withTimeout(8000L) {
                db?.collection(COLLECTION_DATA)?.document(DOC_CURRENT)?.set(state)?.await()
            }"""
content = content.replace(target_sync, replacement_sync)

target_backup = """            db?.collection(COLLECTION_DATA)
                ?.document(DOC_CURRENT)
                ?.collection(COLLECTION_BACKUPS)
                ?.document(todayStr)
                ?.set(state, SetOptions.merge())
                ?.await()"""
                
replacement_backup = """            kotlinx.coroutines.withTimeout(8000L) {
                db?.collection(COLLECTION_DATA)
                    ?.document(DOC_CURRENT)
                    ?.collection(COLLECTION_BACKUPS)
                    ?.document(todayStr)
                    ?.set(state, SetOptions.merge())
                    ?.await()
            }"""
content = content.replace(target_backup, replacement_backup)

with open('app/src/main/java/com/example/data/CloudSyncManager.kt', 'w') as f:
    f.write(content)
