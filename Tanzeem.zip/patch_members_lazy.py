import re

with open('app/src/main/java/com/example/MainActivity.kt', 'r') as f:
    content = f.read()

target = """                items(filteredMembers) { member ->
                    MemberCard(
                        member = member,
                        isAdminMode = isAdminMode,
                        isUrdu = isUrdu,
                        activeCustodianName = activeCustodianName,
                        onCheckedChange = { yIdx, checked, selectedDate ->
                            val updated = when (yIdx) {
                                1 -> member.copy(year1 = checked, year1Date = if (checked) selectedDate else null, year1ReceivedBy = if (checked) activeCustodianName else "")
                                2 -> member.copy(year2 = checked, year2Date = if (checked) selectedDate else null, year2ReceivedBy = if (checked) activeCustodianName else "")
                                3 -> member.copy(year3 = checked, year3Date = if (checked) selectedDate else null, year3ReceivedBy = if (checked) activeCustodianName else "")
                                else -> member
                            }
                            viewModel.updateMember(updated)
                        },
                        onEdit = { showEditDialog = member },
                        onDelete = { viewModel.deleteMember(member) }
                    )
                }
            }"""
            
replacement = """                items(filteredMembers) { member ->
                    MemberCard(
                        member = member,
                        isAdminMode = isAdminMode,
                        isUrdu = isUrdu,
                        activeCustodianName = activeCustodianName,
                        onCheckedChange = { yIdx, checked, selectedDate ->
                            val updated = when (yIdx) {
                                1 -> member.copy(year1 = checked, year1Date = if (checked) selectedDate else null, year1ReceivedBy = if (checked) activeCustodianName else "")
                                2 -> member.copy(year2 = checked, year2Date = if (checked) selectedDate else null, year2ReceivedBy = if (checked) activeCustodianName else "")
                                3 -> member.copy(year3 = checked, year3Date = if (checked) selectedDate else null, year3ReceivedBy = if (checked) activeCustodianName else "")
                                else -> member
                            }
                            viewModel.updateMember(updated)
                        },
                        onEdit = { showEditDialog = member },
                        onDelete = { viewModel.deleteMember(member) }
                    )
                }
                
                if (isAdminMode) {
                    item {
                        Spacer(modifier = Modifier.height(24.dp))
                        Text(
                            text = "Security: Active Devices",
                            color = GoldAccent,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(bottom = 8.dp)
                        )
                    }
                    items(devices) { device ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = DarkSlateSurfaceVariant),
                            border = BorderStroke(1.dp, if (device.isBlocked) RedForfeited else Color.White.copy(alpha = 0.1f)),
                            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp).fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "${device.deviceModel} (${device.osVersion})",
                                        color = if (device.isBlocked) RedForfeited else TextOffWhite,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp
                                    )
                                    Text(
                                        text = "ID: ${device.deviceId}",
                                        color = TextMuted,
                                        fontSize = 9.sp,
                                        maxLines = 1,
                                        overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                                    )
                                    val lastActiveDate = java.text.SimpleDateFormat("dd MMM yy HH:mm", java.util.Locale.getDefault()).format(java.util.Date(device.lastActive))
                                    Text(
                                        text = "Last Active: $lastActiveDate | Loc: ${device.locale}",
                                        color = TextMuted,
                                        fontSize = 11.sp
                                    )
                                }
                                if (device.deviceId != viewModel.currentDeviceId) {
                                    IconButton(
                                        onClick = { viewModel.toggleDeviceBlock(device.deviceId, !device.isBlocked) },
                                        modifier = Modifier.size(32.dp).background(Color.Black.copy(alpha = 0.3f), CircleShape)
                                    ) {
                                        Icon(
                                            imageVector = if (device.isBlocked) Icons.Default.LockOpen else Icons.Default.Block,
                                            contentDescription = "Toggle Block",
                                            tint = if (device.isBlocked) EmeraldPrimary else RedForfeited,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                } else {
                                    Box(
                                        modifier = Modifier.background(GoldAccent.copy(alpha=0.2f), RoundedCornerShape(4.dp)).padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text("This Device", fontSize = 9.sp, color = GoldAccent, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }
            }"""

content = content.replace(target, replacement)

with open('app/src/main/java/com/example/MainActivity.kt', 'w') as f:
    f.write(content)
