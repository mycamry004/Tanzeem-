import sys

file_path = "app/src/main/java/com/example/MainActivity.kt"

with open(file_path, "r") as f:
    content = f.read()

# Inject AppleLogoIcon
icon_code = """
@Composable
fun AppleLogoIcon(
    modifier: androidx.compose.ui.Modifier = androidx.compose.ui.Modifier,
    tint: androidx.compose.ui.graphics.Color = androidx.compose.ui.graphics.Color.White
) {
    androidx.compose.foundation.Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        
        val path = androidx.compose.ui.graphics.Path().apply {
            moveTo(w * 0.5f, h * 0.28f)
            cubicTo(w * 0.45f, h * 0.24f, w * 0.35f, h * 0.24f, w * 0.28f, h * 0.32f)
            cubicTo(w * 0.18f, h * 0.42f, w * 0.16f, h * 0.62f, w * 0.26f, h * 0.74f)
            cubicTo(w * 0.32f, h * 0.82f, w * 0.42f, h * 0.82f, w * 0.48f, h * 0.78f)
            cubicTo(w * 0.49f, h * 0.77f, w * 0.51f, h * 0.77f, w * 0.52f, h * 0.78f)
            cubicTo(w * 0.58f, h * 0.82f, w * 0.68f, h * 0.82f, w * 0.74f, h * 0.74f)
            cubicTo(w * 0.82f, h * 0.65f, w * 0.80f, h * 0.52f, w * 0.74f, h * 0.48f)
            cubicTo(w * 0.75f, h * 0.45f, w * 0.76f, h * 0.42f, w * 0.74f, h * 0.39f)
            cubicTo(w * 0.68f, h * 0.26f, w * 0.55f, h * 0.28f, w * 0.5f, h * 0.28f)
            close()
        }
        
        val leafPath = androidx.compose.ui.graphics.Path().apply {
            moveTo(w * 0.52f, h * 0.23f)
            cubicTo(w * 0.55f, h * 0.15f, w * 0.65f, h * 0.10f, w * 0.65f, h * 0.10f)
            cubicTo(w * 0.65f, h * 0.10f, w * 0.60f, h * 0.22f, w * 0.55f, h * 0.25f)
            cubicTo(w * 0.53f, h * 0.26f, w * 0.51f, h * 0.25f, w * 0.52f, h * 0.23f)
            close()
        }
        
        drawPath(path = path, color = tint)
        drawPath(path = leafPath, color = tint)
    }
}

@Composable
fun LanguagePickerDialog"""

content = content.replace("@Composable\nfun LanguagePickerDialog", icon_code)

# Inject top bar button
button_target = """                                        fontFamily = androidx.compose.ui.text.font.FontFamily.SansSerif
                                    )
                                }"""

button_code = """                                        fontFamily = androidx.compose.ui.text.font.FontFamily.SansSerif
                                    )
                                }

                                // Apple iOS PWA Sync Info Dialog Icon Button
                                var showApplePwaDialog by remember { mutableStateOf(false) }
                                Box(
                                    modifier = Modifier
                                        .size(32.dp)
                                        .clip(CircleShape)
                                        .background(Color.White.copy(alpha = 0.15f))
                                        .border(BorderStroke(1.dp, Color.White.copy(alpha = 0.3f)), CircleShape)
                                        .clickable {
                                            showApplePwaDialog = true
                                        }
                                        .testTag("top_bar_apple_button"),
                                    contentAlignment = Alignment.Center
                                ) {
                                    AppleLogoIcon(
                                        modifier = Modifier.size(16.dp),
                                        tint = Color.White
                                    )
                                }

                                if (showApplePwaDialog) {
                                    Dialog(onDismissRequest = { showApplePwaDialog = false }) {
                                        Card(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(16.dp)
                                                .testTag("apple_pwa_dialog_card"),
                                            colors = CardDefaults.cardColors(containerColor = DarkSlateSurface),
                                            border = BorderStroke(1.dp, GoldAccent.copy(alpha = 0.4f)),
                                            shape = RoundedCornerShape(16.dp)
                                        ) {
                                            Column(
                                                modifier = Modifier.padding(16.dp)
                                            ) {
                                                Row(
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                                                ) {
                                                    Box(
                                                        modifier = Modifier
                                                            .size(40.dp)
                                                            .background(TextOffWhite.copy(alpha = 0.15f), CircleShape),
                                                        contentAlignment = Alignment.Center
                                                    ) {
                                                        AppleLogoIcon(
                                                            modifier = Modifier.size(20.dp),
                                                            tint = TextOffWhite
                                                        )
                                                    }
                                                    Column(modifier = Modifier.weight(1f)) {
                                                        Text(
                                                            text = if (isUrdu) "ایپل (iOS) ویب ایپ اور پی ڈبلیو اے" else "Apple (iOS) Web App & PWA",
                                                            color = TextOffWhite,
                                                            fontSize = 15.sp,
                                                            fontWeight = FontWeight.Bold
                                                        )
                                                        Text(
                                                            text = if (isUrdu) "آئی فون صارفین کے لیے مطابقت اور مطابقت پذیری" else "Compatibility & real-time sync for iPhones.",
                                                            color = TextMuted,
                                                            fontSize = 11.sp
                                                        )
                                                    }
                                                }

                                                Spacer(modifier = Modifier.height(16.dp))
                                                androidx.compose.material3.HorizontalDivider(color = DarkSlateSurfaceVariant, thickness = 1.dp)
                                                Spacer(modifier = Modifier.height(12.dp))

                                                Text(
                                                    text = if (isUrdu) "ایپل ڈیوائسز کے لیے (iPhone/iPad):" else "For Apple Devices (iPhone/iPad):",
                                                    color = GoldAccent,
                                                    fontSize = 12.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    modifier = Modifier.padding(bottom = 4.dp)
                                                )

                                                Text(
                                                    text = if (isUrdu) {
                                                        "چونکہ اینڈرائیڈ ایپس آئی فون پر نہیں چلتیں، ہم نے اس کے لیے ایک خصوصی ویب ایپ (PWA) تیار کی ہے۔ یہ ویب ورژن اس اینڈرائیڈ ایپ کے ساتھ مکمل طور پر مطابقت پذیر (fully synced) ہے اور اس میں تمام خصوصیات موجود ہیں۔\\n\\nصارفین اسے اپنے آئی فون کے Safari براؤزر میں کھول کر 'Add to Home Screen' کر سکتے ہیں تاکہ یہ بالکل عام ایپ کی طرح کام کرے۔"
                                                    } else {
                                                        "Since Android apps don't run on iPhones natively, we have built a beautiful synced Web App (PWA) with the exact same features. Any data changes are instantly synchronized between Android and Apple devices.\\n\\nApple users can open this link in Safari on their iPhone, click the Share button, and select 'Add to Home Screen' to save it as a native-feeling app."
                                                    },
                                                    color = TextOffWhite,
                                                    fontSize = 11.sp,
                                                    lineHeight = 16.sp,
                                                    modifier = Modifier.padding(bottom = 16.dp)
                                                )

                                                Row(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                                ) {
                                                    // Copy Link Button
                                                    Button(
                                                        onClick = {
                                                            val clipboardManager = context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                                                            val clipData = android.content.ClipData.newPlainText("Web App Link", "https://untitled-397049479956.us-west1.run.app")
                                                            clipboardManager.setPrimaryClip(clipData)
                                                            android.widget.Toast.makeText(context, if (isUrdu) "لنک کاپی کر دیا گیا ہے!" else "Link copied to clipboard!", android.widget.Toast.LENGTH_SHORT).show()
                                                        },
                                                        colors = ButtonDefaults.buttonColors(containerColor = GoldAccent),
                                                        modifier = Modifier
                                                            .weight(1f)
                                                            .height(38.dp)
                                                            .testTag("apple_pwa_dialog_copy_button"),
                                                        shape = RoundedCornerShape(8.dp)
                                                    ) {
                                                        Row(
                                                            verticalAlignment = Alignment.CenterVertically,
                                                            horizontalArrangement = Arrangement.Center
                                                        ) {
                                                            Icon(
                                                                imageVector = Icons.Default.ContentCopy,
                                                                contentDescription = "Copy Link Icon",
                                                                tint = Color(0xFF0F172A),
                                                                modifier = Modifier.size(16.dp)
                                                            )
                                                            Spacer(modifier = Modifier.width(6.dp))
                                                            Text(
                                                                text = if (isUrdu) "لنک کاپی کریں" else "Copy Link",
                                                                color = Color(0xFF0F172A),
                                                                fontSize = 11.sp,
                                                                fontWeight = FontWeight.Bold
                                                            )
                                                        }
                                                    }

                                                    // Share Link Button
                                                    OutlinedButton(
                                                        onClick = {
                                                            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                                                type = "text/plain"
                                                                putExtra(Intent.EXTRA_SUBJECT, "Taqseem Amanat Tanzeem Web App")
                                                                putExtra(Intent.EXTRA_TEXT, "Open the Taqseem Amanat Tanzeem Web App on Apple (iOS) / Safari and 'Add to Home Screen' to sync with Android:\\nhttps://untitled-397049479956.us-west1.run.app")
                                                            }
                                                            context.startActivity(Intent.createChooser(shareIntent, "Share Web App Link"))
                                                        },
                                                        border = BorderStroke(1.dp, GoldAccent),
                                                        colors = ButtonDefaults.outlinedButtonColors(contentColor = GoldAccent),
                                                        modifier = Modifier
                                                            .weight(1f)
                                                            .height(38.dp)
                                                            .testTag("apple_pwa_dialog_share_button"),
                                                        shape = RoundedCornerShape(8.dp)
                                                    ) {
                                                        Row(
                                                            verticalAlignment = Alignment.CenterVertically,
                                                            horizontalArrangement = Arrangement.Center
                                                        ) {
                                                            Icon(
                                                                imageVector = Icons.Default.Share,
                                                                contentDescription = "Share Web Icon",
                                                                tint = GoldAccent,
                                                                modifier = Modifier.size(16.dp)
                                                            )
                                                            Spacer(modifier = Modifier.width(6.dp))
                                                            Text(
                                                                text = if (isUrdu) "شیئر کریں" else "Share Link",
                                                                color = GoldAccent,
                                                                fontSize = 11.sp,
                                                                fontWeight = FontWeight.Bold
                                                            )
                                                        }
                                                    }
                                                }

                                                Spacer(modifier = Modifier.height(16.dp))
                                                TextButton(
                                                    onClick = { showApplePwaDialog = false },
                                                    modifier = Modifier.fillMaxWidth()
                                                ) {
                                                    Text(if (isUrdu) "بند کریں" else "Close", color = TextMuted)
                                                }
                                            }
                                        }
                                    }
                                }"""

if button_target in content:
    content = content.replace(button_target, button_code, 1)

with open(file_path, "w") as f:
    f.write(content)
print("Reverted successfully!")
