import re

with open('app/src/main/java/com/example/data/TanzeemRepository.kt', 'r') as f:
    content = f.read()

target = """    val allClaims: Flow<List<Claim>> = callbackFlow {
        val listener = docRef.addSnapshotListener { snapshot, error ->
            if (snapshot != null && snapshot.exists()) {
                val backup = snapshot.toObject(CloudBackup::class.java)
                trySend(backup?.claims ?: emptyList())
            } else {
                trySend(emptyList())
            }
        }
        awaitClose { listener.remove() }
    }"""

replacement = """    val allClaims: Flow<List<Claim>> = callbackFlow {
        val listener = docRef.addSnapshotListener { snapshot, error ->
            if (snapshot != null && snapshot.exists()) {
                val backup = snapshot.toObject(CloudBackup::class.java)
                trySend(backup?.claims ?: emptyList())
            } else {
                trySend(emptyList())
            }
        }
        awaitClose { listener.remove() }
    }

    val allNotifications: Flow<List<AppNotification>> = callbackFlow {
        val listener = docRef.addSnapshotListener { snapshot, error ->
            if (snapshot != null && snapshot.exists()) {
                val backup = snapshot.toObject(CloudBackup::class.java)
                trySend(backup?.notifications ?: emptyList())
            } else {
                trySend(emptyList())
            }
        }
        awaitClose { listener.remove() }
    }"""

if target in content:
    content = content.replace(target, replacement)
    
target2 = """    suspend fun deleteClaim(claim: Claim) {
        db.runTransaction { transaction ->
            val snapshot = transaction.get(docRef)
            val backup = if (snapshot.exists()) snapshot.toObject(CloudBackup::class.java) ?: CloudBackup() else CloudBackup()
            val newClaims = backup.claims.filterNot { it.id == claim.id }
            transaction.set(docRef, backup.copy(claims = newClaims))
        }.await()
    }"""

replacement2 = """    suspend fun deleteClaim(claim: Claim) {
        db.runTransaction { transaction ->
            val snapshot = transaction.get(docRef)
            val backup = if (snapshot.exists()) snapshot.toObject(CloudBackup::class.java) ?: CloudBackup() else CloudBackup()
            val newClaims = backup.claims.filterNot { it.id == claim.id }
            transaction.set(docRef, backup.copy(claims = newClaims))
        }.await()
    }

    suspend fun insertNotification(notification: AppNotification) {
        db.runTransaction { transaction ->
            val snapshot = transaction.get(docRef)
            val backup = if (snapshot.exists()) snapshot.toObject(CloudBackup::class.java) ?: CloudBackup() else CloudBackup()
            val newNotifications = backup.notifications + notification
            // Keep only last 100 notifications to prevent document getting too large
            val limitedNotifications = newNotifications.sortedByDescending { it.timestamp }.take(100)
            transaction.set(docRef, backup.copy(notifications = limitedNotifications))
        }.await()
    }"""

if target2 in content:
    content = content.replace(target2, replacement2)

with open('app/src/main/java/com/example/data/TanzeemRepository.kt', 'w') as f:
    f.write(content)
