with open('app/src/main/java/com/example/MainActivity.kt', 'r') as f:
    content = f.read()

old_click = """                        .clickable {
                            showLoginDialog = true
                        }
                        .testTag("custodian_access_card"),"""

new_click = """                        .clickable {
                            val isBiometricEnabled = context.getSharedPreferences("tat_prefs", android.content.Context.MODE_PRIVATE).getBoolean("biometric_enabled", false)
                            if (isBiometricEnabled) {
                                try {
                                    val biometricPrompt = androidx.biometric.BiometricPrompt(
                                        context as androidx.fragment.app.FragmentActivity,
                                        androidx.core.content.ContextCompat.getMainExecutor(context),
                                        object : androidx.biometric.BiometricPrompt.AuthenticationCallback() {
                                            override fun onAuthenticationSucceeded(result: androidx.biometric.BiometricPrompt.AuthenticationResult) {
                                                viewModel.setAdminMode(true)
                                                viewModel.setSuperAdminMode(false)
                                                showLoginDialog = false
                                                showWelcomeScreen = false
                                                android.widget.Toast.makeText(context, Translations.getString("welcomeBack", isUrdu), android.widget.Toast.LENGTH_SHORT).show()
                                            }
                                            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                                                showLoginDialog = true
                                            }
                                        }
                                    )
                                    val promptInfo = androidx.biometric.BiometricPrompt.PromptInfo.Builder()
                                        .setTitle(if (isUrdu) "بایومیٹرک لاگ ان" else "Biometric Login")
                                        .setSubtitle(if (isUrdu) "اپنے فنگر پرنٹ کا استعمال کریں" else "Log in using your biometric credential")
                                        .setNegativeButtonText(if (isUrdu) "منسوخ کریں" else "Cancel")
                                        .build()
                                    biometricPrompt.authenticate(promptInfo)
                                } catch (e: Exception) {
                                    showLoginDialog = true
                                }
                            } else {
                                showLoginDialog = true
                            }
                        }
                        .testTag("custodian_access_card"),"""
content = content.replace(old_click, new_click)

with open('app/src/main/java/com/example/MainActivity.kt', 'w') as f:
    f.write(content)
