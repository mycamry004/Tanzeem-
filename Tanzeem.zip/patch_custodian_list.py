import re

with open('app/src/main/java/com/example/MainActivity.kt', 'r') as f:
    content = f.read()

target = """                            Text(
                                text = "${df.format(Date(custodian.startDate))} - ${df.format(Date(custodian.endDate))}",
                                color = TextMuted,
                                fontSize = 10.sp
                            )
                        }
                    }"""

replacement = """                            Text(
                                text = "${df.format(Date(custodian.startDate))} - ${df.format(Date(custodian.endDate))}",
                                color = TextMuted,
                                fontSize = 10.sp
                            )
                            if (isAdminMode) {
                                Spacer(modifier = Modifier.height(2.dp))
                                if (custodian.password.isNotEmpty()) {
                                    Text(
                                        text = "Permanent Password: ${custodian.password}",
                                        color = EmeraldPrimary,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                                if (custodian.tempPassword.isNotEmpty()) {
                                    Text(
                                        text = "Temp Password: ${custodian.tempPassword}",
                                        color = GoldAccent,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }"""

content = content.replace(target, replacement)

with open('app/src/main/java/com/example/MainActivity.kt', 'w') as f:
    f.write(content)
