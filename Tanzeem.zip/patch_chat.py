import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

replacement = """fun formatAndParseMarkdown(text: String, isUser: Boolean, accentColor: Color): androidx.compose.ui.text.AnnotatedString {
    var processed = text
    
    val termsToBold = listOf(
        "Assalamualaikum", "Assalam o Alaikum", "As-salamu alaykum", 
        "Respected Member", "Respected Custodian", "Custodian", 
        "Total Registered Members"
    )
    termsToBold.forEach { term ->
        val regex = Regex("(?<!\\\\*\\\\*)$term(?!\\\\*\\\\*)", RegexOption.IGNORE_CASE)
        processed = processed.replace(regex) { "**${it.value}**" }
    }
    
    return buildAnnotatedString {
        val lines = processed.split("\\n")
        
        for (i in lines.indices) {
            var line = lines[i]
            val trimmedLine = line.trimStart()
            val indentSpaces = line.length - trimmedLine.length
            
            if (trimmedLine.startsWith("* ") || trimmedLine.startsWith("- ")) {
                if (indentSpaces > 0) {
                    append("    ".repeat(indentSpaces / 2 + 1))
                }
                withStyle(SpanStyle(color = if (isUser) Color.White else accentColor, fontWeight = FontWeight.Bold)) {
                    append("•  ")
                }
                line = trimmedLine.drop(2)
            }
            
            val parts = line.split("**")
            for (j in parts.indices) {
                if (j % 2 != 0 && parts.size > 1) { 
                    withStyle(SpanStyle(fontWeight = FontWeight.Bold)) {
                        append(parts[j])
                    }
                } else {
                    val italicParts = parts[j].split("*")
                    for (k in italicParts.indices) {
                        if (k % 2 != 0 && italicParts.size > 1) {
                            withStyle(SpanStyle(fontStyle = FontStyle.Italic)) {
                                append(italicParts[k])
                            }
                        } else {
                            append(italicParts[k])
                        }
                    }
                }
            }
            
            if (i < lines.lastIndex) {
                append("\\n")
                // Increase line spacing for non-list items to reduce congestion
                if (line.isNotBlank() && lines[i+1].isNotBlank() && !trimmedLine.startsWith("*") && !trimmedLine.startsWith("-")) {
                   append("\\n")
                }
            }
        }
    }
}

@Composable
fun ChatBubble(message: ChatMessage, onSpeakClick: (() -> Unit)? = null) {"""

content = content.replace("fun ChatBubble(message: ChatMessage, onSpeakClick: (() -> Unit)? = null) {", replacement)

text_target = """        Surface(
            color = bubbleColor,
            border = borderStroke,
            shape = shape,
            modifier = Modifier
                .widthIn(max = 280.dp)
                .testTag("chat_bubble_${if (message.isUser) "user" else "advisor"}")
        ) {
            Text(
                text = message.text,
                fontSize = 13.sp,
                color = if (message.isUser) Color.White else TextOffWhite,
                lineHeight = 18.sp,
                modifier = Modifier.padding(12.dp)
            )
        }"""

text_replacement = """        Surface(
            color = bubbleColor,
            border = borderStroke,
            shape = shape,
            modifier = Modifier
                .widthIn(max = 280.dp)
                .testTag("chat_bubble_${if (message.isUser) "user" else "advisor"}")
        ) {
            Text(
                text = formatAndParseMarkdown(message.text, message.isUser, GoldAccent),
                fontSize = 13.sp,
                color = if (message.isUser) Color.White else TextOffWhite,
                lineHeight = 22.sp,
                modifier = Modifier.padding(16.dp)
            )
        }"""

content = content.replace(text_target, text_replacement)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
print("done")
