import re
with open('app/src/main/java/com/example/MainActivity.kt', 'r') as f:
    content = f.read()

# Replace column width calculation
old_col_widths = """    // Column widths
    val colWidths = FloatArray(headers.size)
    val columnWidth = contentWidth / headers.size.toFloat()
    for (i in headers.indices) colWidths[i] = columnWidth
    
    val headerRowHeight = 35f
    canvas.drawRect(marginLeft, currentY, pageWidth - marginRight, currentY + headerRowHeight, paintPrimary)
    for ((index, header) in headers.withIndex()) {
        val cellX = marginLeft + (index * columnWidth)
        canvas.drawText(header, cellX + 10f, currentY + 22f, paintHeaderText)
        if (index > 0) canvas.drawLine(cellX, currentY, cellX, currentY + headerRowHeight, paintBorder)
    }"""

new_col_widths = """    // Column widths
    val colWidths = FloatArray(headers.size)
    if (colWeights != null && colWeights.size == headers.size) {
        val totalWeight = colWeights.sum()
        for (i in headers.indices) colWidths[i] = (colWeights[i] / totalWeight) * contentWidth
    } else {
        val columnWidth = contentWidth / headers.size.toFloat()
        for (i in headers.indices) colWidths[i] = columnWidth
    }
    
    val headerRowHeight = 35f
    canvas.drawRect(marginLeft, currentY, pageWidth - marginRight, currentY + headerRowHeight, paintPrimary)
    var currentCellX = marginLeft
    for ((index, header) in headers.withIndex()) {
        canvas.drawText(header, currentCellX + 10f, currentY + 22f, paintHeaderText)
        if (index > 0) canvas.drawLine(currentCellX, currentY, currentCellX, currentY + headerRowHeight, paintBorder)
        currentCellX += colWidths[index]
    }"""
content = content.replace(old_col_widths, new_col_widths)


# Replace inner loops for new pages and cells
old_new_page_headers = """            for ((index, header) in headers.withIndex()) {
                val cellX = marginLeft + (index * columnWidth)
                canvas.drawText(header, cellX + 10f, currentY + 22f, paintHeaderText)
                if (index > 0) canvas.drawLine(cellX, currentY, cellX, currentY + headerRowHeight, paintBorder)
            }"""

new_new_page_headers = """            var currentCellX = marginLeft
            for ((index, header) in headers.withIndex()) {
                canvas.drawText(header, currentCellX + 10f, currentY + 22f, paintHeaderText)
                if (index > 0) canvas.drawLine(currentCellX, currentY, currentCellX, currentY + headerRowHeight, paintBorder)
                currentCellX += colWidths[index]
            }"""
content = content.replace(old_new_page_headers, new_new_page_headers)


old_cells = """        for ((colIndex, cell) in row.withIndex()) {
            var text = cell
            val maxTextWidth = columnWidth - 20f
            val measured = paintCellText.measureText(text)
            if (measured > maxTextWidth) {
                val charsToKeep = (maxTextWidth / (measured / text.length)).toInt()
                if (charsToKeep > 0 && charsToKeep < text.length) {
                    text = text.substring(0, charsToKeep - 2) + ".."
                }
            }
            
            val cellX = marginLeft + (colIndex * columnWidth)
            canvas.drawText(text, cellX + 10f, currentY + 20f, paintCellText)
            if (colIndex > 0) canvas.drawLine(cellX, currentY, cellX, currentY + rowHeight, paintBorder)
        }"""

new_cells = """        var currentCellX = marginLeft
        for ((colIndex, cell) in row.withIndex()) {
            var text = cell
            val maxTextWidth = colWidths[colIndex] - 20f
            if (maxTextWidth > 0) {
                val measured = paintCellText.measureText(text)
                if (measured > maxTextWidth) {
                    val charsToKeep = (maxTextWidth / (measured / max(1, text.length))).toInt()
                    if (charsToKeep > 0 && charsToKeep < text.length) {
                        text = text.substring(0, charsToKeep - 2) + ".."
                    }
                }
                canvas.drawText(text, currentCellX + 10f, currentY + 20f, paintCellText)
            }
            if (colIndex > 0) canvas.drawLine(currentCellX, currentY, currentCellX, currentY + rowHeight, paintBorder)
            currentCellX += colWidths[colIndex]
        }"""
content = content.replace(old_cells, new_cells)

# Need to import kotlin.math.max if missing? Just use text.length directly with a safe check
new_cells_safe = new_cells.replace('max(1, text.length)', 'if (text.isEmpty()) 1 else text.length')
content = content.replace(new_cells, new_cells_safe)

with open('app/src/main/java/com/example/MainActivity.kt', 'w') as f:
    f.write(content)
