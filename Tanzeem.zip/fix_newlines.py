with open('app/src/main/java/com/example/MainActivity.kt', 'r') as f:
    content = f.read()

# Fix the broken text string manually
fixed = content.replace('text = if (isUrdu) "کل ممبرز: $totalMembers\nموجودہ بیلنس: $currentBal QAR" else "Total Members: $totalMembers\nAvailable Balance: $currentBal QAR",',
'text = if (isUrdu) "کل ممبرز: $totalMembers\\nموجودہ بیلنس: $currentBal QAR" else "Total Members: $totalMembers\\nAvailable Balance: $currentBal QAR",')

with open('app/src/main/java/com/example/MainActivity.kt', 'w') as f:
    f.write(fixed)
