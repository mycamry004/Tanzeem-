with open('app/src/main/java/com/example/MainActivity.kt', 'r') as f:
    content = f.read()

content = content.replace("if (!isOrange) { leftContentX = marginLeft + 60f }", "if (!isOrange) { leftContentX = marginLeft + 140f }")

with open('app/src/main/java/com/example/MainActivity.kt', 'w') as f:
    f.write(content)
