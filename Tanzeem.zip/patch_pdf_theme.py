import re

file_path = "app/src/main/java/com/example/MainActivity.kt"
with open(file_path, "r") as f:
    content = f.read()

pattern = re.compile(r"fun generatePdf.*?fun sharePdfFile.*?\}\s*\}", re.DOTALL)
match = pattern.search(content)

if not match:
    print("Could not find the target functions.")
    exit(1)

replacement = """fun generatePdf(context: android.content.Context, filename: String, title: String, headers: List<String>, data: List<List<String>>, theme: String): java.io.File {
    val pdfDocument = android.graphics.pdf.PdfDocument()
    // Landscape
    val pageWidth = 842
    val pageHeight = 595
    val pageInfo = android.graphics.pdf.PdfDocument.PageInfo.Builder(pageWidth, pageHeight, 1).create()
    var page = pdfDocument.startPage(pageInfo)
    var canvas = page.canvas
    
    // Theme Colors
    val isOrange = theme == "orange"
    val primaryColor = if (isOrange) android.graphics.Color.parseColor("#F97316") else android.graphics.Color.parseColor("#0284C7") // Orange vs SkyBlue
    val secondaryColor = if (isOrange) android.graphics.Color.parseColor("#FDBA74") else android.graphics.Color.parseColor("#0369A1") 
    
    val paintPrimary = android.graphics.Paint().apply { color = primaryColor; isAntiAlias = true }
    val paintSecondary = android.graphics.Paint().apply { color = secondaryColor; isAntiAlias = true }
    
    val paintTitle = android.graphics.Paint().apply {
        color = primaryColor
        textSize = 28f
        typeface = android.graphics.Typeface.create(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD)
        isAntiAlias = true
    }
    val paintMottoEn = android.graphics.Paint().apply {
        color = android.graphics.Color.parseColor("#0F172A")
        textSize = 16f
        typeface = android.graphics.Typeface.create(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD)
        isAntiAlias = true
    }
    val paintMottoUr = android.graphics.Paint().apply {
        color = android.graphics.Color.parseColor("#475569")
        textSize = 16f
        typeface = android.graphics.Typeface.create(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.NORMAL)
        isAntiAlias = true
    }
    val paintDate = android.graphics.Paint().apply {
        color = android.graphics.Color.parseColor("#64748B")
        textSize = 12f
        isAntiAlias = true
    }
    val paintHeaderText = android.graphics.Paint().apply {
        color = android.graphics.Color.WHITE
        textSize = 12f
        typeface = android.graphics.Typeface.create(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD)
        isAntiAlias = true
    }
    val paintCellText = android.graphics.Paint().apply {
        color = android.graphics.Color.parseColor("#1E293B")
        textSize = 11f
        typeface = android.graphics.Typeface.create(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.NORMAL)
        isAntiAlias = true
    }
    val paintRowBgAlt = android.graphics.Paint().apply {
        color = android.graphics.Color.parseColor("#F8FAFC")
    }
    val paintBorder = android.graphics.Paint().apply {
        color = android.graphics.Color.parseColor("#E2E8F0")
        style = android.graphics.Paint.Style.STROKE
        strokeWidth = 1f
    }
    
    // Logo
    var scaledLogo: android.graphics.Bitmap? = null
    try {
        val originalLogo = android.graphics.BitmapFactory.decodeResource(context.resources, R.drawable.tat_emblem)
        if (originalLogo != null) {
            scaledLogo = android.graphics.Bitmap.createScaledBitmap(originalLogo, 70, 70, true)
        }
    } catch (e: Exception) {
        e.printStackTrace()
    }
    
    val marginLeft = 40f
    val marginRight = 40f
    val marginBottom = 40f
    val contentWidth = pageWidth - marginLeft - marginRight
    
    fun drawHeader(c: android.graphics.Canvas): Float {
        // Decorative top elements
        if (isOrange) {
            // Orange abstract waves top right
            val path = android.graphics.Path()
            path.moveTo(pageWidth.toFloat(), 0f)
            path.lineTo(pageWidth - 250f, 0f)
            path.quadTo(pageWidth - 150f, 80f, pageWidth.toFloat(), 150f)
            path.close()
            c.drawPath(path, paintSecondary)
            
            val path2 = android.graphics.Path()
            path2.moveTo(pageWidth.toFloat(), 0f)
            path2.lineTo(pageWidth - 150f, 0f)
            path2.quadTo(pageWidth - 50f, 50f, pageWidth.toFloat(), 100f)
            path2.close()
            c.drawPath(path2, paintPrimary)
        } else {
            // Blue geometric polygons top left
            val path = android.graphics.Path()
            path.moveTo(0f, 0f)
            path.lineTo(250f, 0f)
            path.lineTo(0f, 150f)
            path.close()
            c.drawPath(path, paintSecondary)
            
            val path2 = android.graphics.Path()
            path2.moveTo(0f, 0f)
            path2.lineTo(150f, 0f)
            path2.lineTo(0f, 100f)
            path2.close()
            c.drawPath(path2, paintPrimary)
        }
        
        var currentY = 50f
        
        // Logo & Motto (Avoid shapes based on theme)
        var leftContentX = marginLeft
        if (!isOrange) { leftContentX = marginLeft + 60f } // Push right if blue shape is there
        
        if (scaledLogo != null) {
            c.drawBitmap(scaledLogo!!, leftContentX, currentY - 10f, null)
            leftContentX += 85f
        }
        c.drawText("Tanzeem Amanat Taqseem", leftContentX, currentY + 15f, paintMottoEn)
        c.drawText("تنظیم امانت تقسیم", leftContentX, currentY + 35f, paintMottoUr)
        
        // Title & Date
        var rightContentX = pageWidth - marginRight
        if (isOrange) { rightContentX = pageWidth - marginRight - 60f }
        
        val titleText = title.uppercase()
        val titleWidth = paintTitle.measureText(titleText)
        c.drawText(titleText, rightContentX - titleWidth, currentY + 15f, paintTitle)
        
        val dateText = "Date: ${java.text.SimpleDateFormat("MMM dd, yyyy", java.util.Locale.getDefault()).format(java.util.Date())}"
        val dateWidth = paintDate.measureText(dateText)
        c.drawText(dateText, rightContentX - dateWidth, currentY + 35f, paintDate)
        
        // Divider line
        currentY += 80f
        c.drawLine(marginLeft, currentY, pageWidth - marginRight, currentY, paintPrimary)
        return currentY + 20f
    }
    
    var currentY = drawHeader(canvas)
    
    // Column widths
    val colWidths = FloatArray(headers.size)
    val columnWidth = contentWidth / headers.size.toFloat()
    for (i in headers.indices) colWidths[i] = columnWidth
    
    val headerRowHeight = 35f
    canvas.drawRect(marginLeft, currentY, pageWidth - marginRight, currentY + headerRowHeight, paintPrimary)
    for ((index, header) in headers.withIndex()) {
        val cellX = marginLeft + (index * columnWidth)
        canvas.drawText(header, cellX + 10f, currentY + 22f, paintHeaderText)
        if (index > 0) canvas.drawLine(cellX, currentY, cellX, currentY + headerRowHeight, paintBorder)
    }
    canvas.drawRect(marginLeft, currentY, pageWidth - marginRight, currentY + headerRowHeight, paintBorder)
    
    currentY += headerRowHeight
    
    val rowHeight = 30f
    for ((rowIndex, row) in data.withIndex()) {
        if (currentY + rowHeight > pageHeight - marginBottom) {
            pdfDocument.finishPage(page)
            page = pdfDocument.startPage(pageInfo)
            canvas = page.canvas
            currentY = drawHeader(canvas)
            
            canvas.drawRect(marginLeft, currentY, pageWidth - marginRight, currentY + headerRowHeight, paintPrimary)
            for ((index, header) in headers.withIndex()) {
                val cellX = marginLeft + (index * columnWidth)
                canvas.drawText(header, cellX + 10f, currentY + 22f, paintHeaderText)
                if (index > 0) canvas.drawLine(cellX, currentY, cellX, currentY + headerRowHeight, paintBorder)
            }
            canvas.drawRect(marginLeft, currentY, pageWidth - marginRight, currentY + headerRowHeight, paintBorder)
            currentY += headerRowHeight
        }
        
        if (rowIndex % 2 != 0) {
            canvas.drawRect(marginLeft, currentY, pageWidth - marginRight, currentY + rowHeight, paintRowBgAlt)
        }
        
        for ((colIndex, cell) in row.withIndex()) {
            var text = cell
            val maxTextWidth = columnWidth - 20f
            val measured = paintCellText.measureText(text)
            if (measured > maxTextWidth) {
                val charsToKeep = (maxTextWidth / (measured / text.length)).toInt()
                if (charsToKeep > 0 && charsToKeep < text.length) {
                    text = text.substring(0, charsToKeep - 2) + ".."
                }
            }
            
            val cellX = marginLeft + (colIndex * columnWidth)
            canvas.drawText(text, cellX + 10f, currentY + 20f, paintCellText)
            if (colIndex > 0) canvas.drawLine(cellX, currentY, cellX, currentY + rowHeight, paintBorder)
        }
        canvas.drawRect(marginLeft, currentY, pageWidth - marginRight, currentY + rowHeight, paintBorder)
        currentY += rowHeight
    }
    
    // Bottom decorative elements
    if (isOrange) {
        val path = android.graphics.Path()
        path.moveTo(0f, pageHeight.toFloat())
        path.lineTo(250f, pageHeight.toFloat())
        path.quadTo(150f, pageHeight - 80f, 0f, pageHeight - 150f)
        path.close()
        canvas.drawPath(path, paintSecondary)
    } else {
        val path = android.graphics.Path()
        path.moveTo(pageWidth.toFloat(), pageHeight.toFloat())
        path.lineTo(pageWidth - 250f, pageHeight.toFloat())
        path.lineTo(pageWidth.toFloat(), pageHeight - 150f)
        path.close()
        canvas.drawPath(path, paintSecondary)
    }
    
    pdfDocument.finishPage(page)
    val file = java.io.File(context.externalCacheDir, filename)
    pdfDocument.writeTo(java.io.FileOutputStream(file))
    pdfDocument.close()
    
    return file
}

fun sharePdfFile(context: android.content.Context, file: java.io.File) {
    try {
        val uri = androidx.core.content.FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )
        val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(android.content.Intent.EXTRA_SUBJECT, file.name.replace(".pdf", " Report"))
            putExtra(android.content.Intent.EXTRA_STREAM, uri)
            addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(android.content.Intent.createChooser(intent, "Export PDF Report"))
    } catch (e: Exception) {
        e.printStackTrace()
        android.widget.Toast.makeText(context, "Export failed. Please check permissions.", android.widget.Toast.LENGTH_LONG).show()
    }
}"""

new_content = content[:match.start()] + replacement + content[match.end():]

# Now we need to update the calls to generatePdf
new_content = new_content.replace('return generatePdf(context, "TAT_Members_Payment_Summary.pdf", title, headers, data)', 'return generatePdf(context, "TAT_Members_Payment_Summary.pdf", title, headers, data, "orange")')
new_content = new_content.replace('return generatePdf(context, "TAT_Custodians_History.pdf", title, headers, data)', 'return generatePdf(context, "TAT_Custodians_History.pdf", title, headers, data, "blue")')


with open(file_path, "w") as f:
    f.write(new_content)
print("Patched PDF logic successfully!")
