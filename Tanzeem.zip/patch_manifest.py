import re
with open('app/src/main/AndroidManifest.xml', 'r') as f:
    content = f.read()
    
# Remove UPDATE_PACKAGES and REQUEST_INSTALL_PACKAGES if they exist, to be safe.
# We no longer need them.
content = re.sub(r'<uses-permission android:name="android\.permission\.REQUEST_INSTALL_PACKAGES" />\n\s*', '', content)
content = re.sub(r'<provider[\s\S]*?androidx\.core\.content\.FileProvider[\s\S]*?</provider>', '', content)

with open('app/src/main/AndroidManifest.xml', 'w') as f:
    f.write(content)
