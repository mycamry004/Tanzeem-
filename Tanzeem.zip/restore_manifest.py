import re
with open('app/src/main/AndroidManifest.xml', 'r') as f:
    content = f.read()

# Restore permission
if "android.permission.REQUEST_INSTALL_PACKAGES" not in content:
    content = content.replace('<uses-permission android:name="android.permission.INTERNET" />', 
                              '<uses-permission android:name="android.permission.INTERNET" />\n    <uses-permission android:name="android.permission.REQUEST_INSTALL_PACKAGES" />')

# Restore provider
provider_xml = """        </activity>

        <provider
            android:name="androidx.core.content.FileProvider"
            android:authorities="${applicationId}.fileprovider"
            android:exported="false"
            android:grantUriPermissions="true">
            <meta-data
                android:name="android.support.FILE_PROVIDER_PATHS"
                android:resource="@xml/file_paths" />
        </provider>
    </application>"""

if "androidx.core.content.FileProvider" not in content:
    content = content.replace('        </activity>\n    </application>', provider_xml)

with open('app/src/main/AndroidManifest.xml', 'w') as f:
    f.write(content)
