import re

# Fix MainActivity.kt imports
with open('app/src/main/java/com/example/MainActivity.kt', 'r') as f:
    content = f.read()

if 'import com.example.data.AppDevice' not in content:
    content = content.replace('import com.example.data.AppNotification', 'import com.example.data.AppNotification\nimport com.example.data.AppDevice')

with open('app/src/main/java/com/example/MainActivity.kt', 'w') as f:
    f.write(content)

# Fix TatViewModel.kt imports
with open('app/src/main/java/com/example/ui/TatViewModel.kt', 'r') as f:
    content = f.read()

if 'import java.util.Locale' not in content:
    content = content.replace('import java.util.Date', 'import java.util.Date\nimport java.util.Locale')

with open('app/src/main/java/com/example/ui/TatViewModel.kt', 'w') as f:
    f.write(content)
