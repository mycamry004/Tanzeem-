sed -i 's/Icon(/Text(text = if (isUrdu) "U" else "E", fontWeight = androidx.compose.ui.text.font.FontWeight.Bold, fontSize = 16.sp, /g' app/src/main/java/com/example/MainActivity.kt
