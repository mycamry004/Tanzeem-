import sys

file_path = "app/src/main/java/com/example/MainActivity.kt"

with open(file_path, "r") as f:
    content = f.read()

target = """        // Form to log a Claim
        item {
            Card("""

replacement = """        if (isAdminMode) {
            // Form to log a Claim
            item {
                Card("""

if target in content:
    content = content.replace(target, replacement, 1)
else:
    print("Target 1 not found!")
    
target_2 = """        // Audit Result Area (If generated)
        if (auditTextResult != null && auditingActiveClaim != null) {
            item {
                Card("""

replacement_2 = """        // Audit Result Area (If generated)
            if (auditTextResult != null && auditingActiveClaim != null) {
                item {
                    Card("""

if target_2 in content:
    content = content.replace(target_2, replacement_2, 1)

target_3 = """                    }
                }
            }
        }

        // Historical Claims Header"""

replacement_3 = """                    }
                }
            }
        }
        }

        // Historical Claims Header"""

if target_3 in content:
    content = content.replace(target_3, replacement_3, 1)
else:
    print("Target 3 not found!")

with open(file_path, "w") as f:
    f.write(content)
print("Patched successfully!")
