import re

with open("app/src/main/java/com/example/ui/TatViewModel.kt", "r") as f:
    content = f.read()

# Remove prefs and _isUrdu from their current location
prefs_decl = """    private val prefs = application.getSharedPreferences("TatPrefs", android.content.Context.MODE_PRIVATE)

    // Language state: true = Urdu, false = English
    private val _isUrdu = MutableStateFlow(prefs.getBoolean("isUrdu", true))"""
content = content.replace(prefs_decl, "    // Language state: true = Urdu, false = English")

# Add them right after the class declaration
new_top = """class TatViewModel(application: Application) : AndroidViewModel(application) {

    private val prefs = application.getSharedPreferences("TatPrefs", android.content.Context.MODE_PRIVATE)
    private val _isUrdu = MutableStateFlow(prefs.getBoolean("isUrdu", true))"""
content = content.replace("class TatViewModel(application: Application) : AndroidViewModel(application) {", new_top)

with open("app/src/main/java/com/example/ui/TatViewModel.kt", "w") as f:
    f.write(content)
print("ViewModel re-ordered")
