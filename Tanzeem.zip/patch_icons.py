import re
with open('app/src/main/java/com/example/MainActivity.kt', 'r') as f:
    content = f.read()

# Add Biometric Icon
biometric_toggle = """                // Biometric Toggle
                val isBiometricEnabled = context.getSharedPreferences("tat_prefs", android.content.Context.MODE_PRIVATE).getBoolean("biometric_enabled", false)
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(if (isBiometricEnabled) Color(0xFF059669) else Color.Black.copy(alpha = 0.2f))
                        .border(BorderStroke(1.dp, GoldAccent.copy(alpha = 0.8f)), CircleShape)
                        .clickable { 
                            context.getSharedPreferences("tat_prefs", android.content.Context.MODE_PRIVATE)
                                .edit()
                                .putBoolean("biometric_enabled", !isBiometricEnabled)
                                .apply()
                            android.widget.Toast.makeText(context, if (!isBiometricEnabled) "Biometric Enabled" else "Biometric Disabled", android.widget.Toast.LENGTH_SHORT).show()
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Fingerprint,
                        contentDescription = "Biometric Toggle",
                        tint = if (isBiometricEnabled) Color.White else GoldAccent,
                        modifier = Modifier.size(20.dp)
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                // Theme Toggle"""
content = content.replace('                // Theme Toggle', biometric_toggle, 1)

# Replace Language Icons
old_lang1 = """                // Language Selector
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(Color.Black.copy(alpha = 0.2f))
                        .border(BorderStroke(1.dp, GoldAccent.copy(alpha = 0.8f)), CircleShape)
                        .clickable { showLanguageDialog = true }
                        .testTag("welcome_language_toggle"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Language,
                        contentDescription = "Language Selector",
                        tint = GoldAccent,
                        modifier = Modifier.size(20.dp)
                    )
                }"""
new_lang1 = """                // Language Selector
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(Color.Black.copy(alpha = 0.2f))
                        .border(BorderStroke(1.dp, GoldAccent.copy(alpha = 0.8f)), CircleShape)
                        .clickable { showLanguageDialog = true }
                        .testTag("welcome_language_toggle"),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = if (isUrdu) "U" else "E",
                        fontWeight = FontWeight.Bold,
                        color = GoldAccent,
                        fontSize = 16.sp
                    )
                }"""
content = content.replace(old_lang1, new_lang1)

old_lang2 = """                                // Language Selector Globe Button
                                Box(
                                    modifier = Modifier
                                        .size(32.dp)
                                        .clip(CircleShape)
                                        .background(Color.Black.copy(alpha = 0.2f))
                                        .border(BorderStroke(1.dp, Color.White.copy(alpha = 0.25f)), CircleShape)
                                        .clickable { showLanguageDialog = true }
                                        .testTag("app_language_globe_button"),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Language,
                                        contentDescription = "Select Language",
                                        tint = Color.White,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }"""
new_lang2 = """                                // Language Selector Globe Button
                                Box(
                                    modifier = Modifier
                                        .size(32.dp)
                                        .clip(CircleShape)
                                        .background(Color.Black.copy(alpha = 0.2f))
                                        .border(BorderStroke(1.dp, Color.White.copy(alpha = 0.25f)), CircleShape)
                                        .clickable { showLanguageDialog = true }
                                        .testTag("app_language_globe_button"),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = if (isUrdu) "U" else "E",
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White,
                                        fontSize = 14.sp
                                    )
                                }"""
content = content.replace(old_lang2, new_lang2)

with open('app/src/main/java/com/example/MainActivity.kt', 'w') as f:
    f.write(content)
