import sys
content = open("app/src/main/java/com/example/MainActivity.kt").read()
import re
new_items = "items(sortedCustodians, key = { it.id.toString() + it.name + it.isCurrent.toString() }) { custodian ->"
content = re.sub(r"items\(sortedCustodians, key = \{ it\.id\.toString\(\) \+ it\.name \}\)\s*\{\s*custodian\s*->", new_items, content)
open("app/src/main/java/com/example/MainActivity.kt", "w").write(content)
