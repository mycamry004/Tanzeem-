import sys

file_path = "app/src/main/java/com/example/MainActivity.kt"

with open(file_path, "r") as f:
    content = f.read()

target = "@Composable\nfun MainContent(viewModel: TatViewModel) {\n"
replacement = """@Composable
fun MainContent(viewModel: TatViewModel) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var updateInfo by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf<com.example.updater.AutoUpdater.UpdateInfo?>(null) }
    
    androidx.compose.runtime.LaunchedEffect(Unit) {
        val info = com.example.updater.AutoUpdater.checkForUpdates()
        if (info?.isUpdateAvailable == true) {
            updateInfo = info
        }
    }

    updateInfo?.let { info ->
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { updateInfo = null },
            title = { androidx.compose.material3.Text("A new update is available!", fontWeight = androidx.compose.ui.text.font.FontWeight.Bold) },
            text = { androidx.compose.material3.Text("Version ${info.latestVersionName} is available. Would you like to update now?") },
            confirmButton = {
                androidx.compose.material3.Button(
                    onClick = {
                        com.example.updater.AutoUpdater.downloadAndInstallUpdate(context, info.downloadUrl)
                        updateInfo = null
                        android.widget.Toast.makeText(context, "Downloading update...", android.widget.Toast.LENGTH_SHORT).show()
                    },
                    colors = androidx.compose.material3.ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
                ) {
                    androidx.compose.material3.Text("Update Now")
                }
            },
            dismissButton = {
                androidx.compose.material3.TextButton(onClick = { updateInfo = null }) {
                    androidx.compose.material3.Text("Later", color = TextMuted)
                }
            },
            containerColor = DarkSlateSurface,
            titleContentColor = TextOffWhite,
            textContentColor = TextOffWhite
        )
    }

"""

if target in content:
    content = content.replace(target, replacement, 1)
    with open(file_path, "w") as f:
        f.write(content)
    print("Patched successfully!")
else:
    print("Target not found!")
