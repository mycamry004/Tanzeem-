import re
with open('app/src/main/java/com/example/MainActivity.kt', 'r') as f:
    content = f.read()

old_call = """                                                viewModel.createManualBackup { success ->
                                    isBackingUp = false
                                    if (success) {
                                        Toast.makeText(context, if (isUrdu) "بیک اپ مکمل ہو گیا" else "Backup created successfully", Toast.LENGTH_SHORT).show()
                                    } else {
                                        Toast.makeText(context, if (isUrdu) "بیک اپ ناکام ہو گیا (کیا فائر بیس ترتیب دیا گیا ہے؟)" else "Backup failed (Firebase not configured?)", Toast.LENGTH_LONG).show()
                                    }
                                }"""

new_call = """                                                viewModel.createManualBackup { success, msg ->
                                    isBackingUp = false
                                    if (success) {
                                        Toast.makeText(context, if (isUrdu) "بیک اپ مکمل ہو گیا" else "Backup created successfully", Toast.LENGTH_SHORT).show()
                                    } else {
                                        Toast.makeText(context, "Backup failed: $msg", Toast.LENGTH_LONG).show()
                                    }
                                }"""
                                
content = content.replace(old_call, new_call)

with open('app/src/main/java/com/example/MainActivity.kt', 'w') as f:
    f.write(content)
