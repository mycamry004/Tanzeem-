import re

with open('app/src/main/java/com/example/MainActivity.kt', 'r') as f:
    content = f.read()

target = """                                // Theme Toggle Button
                                Box(
                                    modifier = Modifier
                                        .size(32.dp)
                                        .clip(CircleShape)
                                        .background(Color.Black.copy(alpha = 0.2f))
                                        .border(BorderStroke(1.dp, Color.White.copy(alpha = 0.25f)), CircleShape)
                                        .clickable { viewModel.toggleTheme() }
                                        .testTag("app_theme_toggle_button"),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = if (isSystemInDarkTheme) Icons.Default.WbSunny else Icons.Default.NightsStay,
                                        contentDescription = "Toggle Theme",
                                        tint = Color.White,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                                // Notifications
                                Box(
                                    modifier = Modifier
                                        .size(32.dp)
                                        .clip(CircleShape)
                                        .background(Color.Black.copy(alpha = 0.2f))
                                        .border(BorderStroke(1.dp, Color.White.copy(alpha = 0.25f)), CircleShape)
                                        .clickable { showNotifications = true },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Notifications,
                                        contentDescription = "Notifications",
                                        tint = Color.White,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                // Language Selector Globe Button
                                Box(
                                    modifier = Modifier
                                        .size(32.dp)
                                        .clip(CircleShape)
                                        .background(Color.Black.copy(alpha = 0.2f))
                                        .border(BorderStroke(1.dp, Color.White.copy(alpha = 0.25f)), CircleShape)
                                        .clickable { showLanguageDialog = true }
                                        .testTag("app_language_globe_button"),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = if (isUrdu) "E" else "U",
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White,
                                        fontSize = 14.sp
                                    )
                                }"""

replacement = """                                // Theme Toggle Button
                                Box(
                                    modifier = Modifier
                                        .size(32.dp)
                                        .clip(CircleShape)
                                        .background(Color.Black.copy(alpha = 0.2f))
                                        .border(BorderStroke(1.dp, Color.White.copy(alpha = 0.25f)), CircleShape)
                                        .clickable { viewModel.toggleTheme() }
                                        .testTag("app_theme_toggle_button"),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = if (isSystemInDarkTheme) Icons.Default.WbSunny else Icons.Default.NightsStay,
                                        contentDescription = "Toggle Theme",
                                        tint = Color.White,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                                // Language Selector Globe Button
                                Box(
                                    modifier = Modifier
                                        .size(32.dp)
                                        .clip(CircleShape)
                                        .background(Color.Black.copy(alpha = 0.2f))
                                        .border(BorderStroke(1.dp, Color.White.copy(alpha = 0.25f)), CircleShape)
                                        .clickable { showLanguageDialog = true }
                                        .testTag("app_language_globe_button"),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = if (isUrdu) "E" else "U",
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White,
                                        fontSize = 14.sp
                                    )
                                }
                                // Notifications
                                Box(
                                    modifier = Modifier
                                        .size(32.dp)
                                        .clip(CircleShape)
                                        .background(Color.Black.copy(alpha = 0.2f))
                                        .border(BorderStroke(1.dp, Color.White.copy(alpha = 0.25f)), CircleShape)
                                        .clickable { showNotifications = true },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Notifications,
                                        contentDescription = "Notifications",
                                        tint = Color.White,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }"""

content = content.replace(target, replacement)

with open('app/src/main/java/com/example/MainActivity.kt', 'w') as f:
    f.write(content)
