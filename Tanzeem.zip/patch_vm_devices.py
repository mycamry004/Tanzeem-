import re

with open('app/src/main/java/com/example/ui/TatViewModel.kt', 'r') as f:
    content = f.read()

# imports
if 'import com.example.data.AppDevice' not in content:
    content = content.replace('import com.example.data.AppNotification', 'import com.example.data.AppNotification\nimport com.example.data.AppDevice\nimport android.provider.Settings.Secure\nimport android.os.Build\nimport java.util.Locale')

# properties
target_notif = """    val notifications: StateFlow<List<AppNotification>> = repository.allNotifications
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())"""
        
replacement_notif = """    val notifications: StateFlow<List<AppNotification>> = repository.allNotifications
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val devices: StateFlow<List<AppDevice>> = repository.allDevices
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
        
    val currentDeviceId = Secure.getString(application.contentResolver, Secure.ANDROID_ID) ?: UUID.randomUUID().toString()"""

content = content.replace(target_notif, replacement_notif)

# init block
target_init = """    init {
        com.example.ui.theme.isSystemInDarkTheme = prefs.getBoolean("isDarkTheme", false)
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {"""
        
replacement_init = """    init {
        com.example.ui.theme.isSystemInDarkTheme = prefs.getBoolean("isDarkTheme", false)
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            try {
                val localeStr = Locale.getDefault().displayName
                val deviceModel = Build.MANUFACTURER + " " + Build.MODEL
                val osVersion = "Android " + Build.VERSION.RELEASE
                repository.registerOrUpdateDevice(
                    AppDevice(
                        deviceId = currentDeviceId,
                        deviceModel = deviceModel,
                        osVersion = osVersion,
                        locale = localeStr,
                        lastActive = System.currentTimeMillis()
                    )
                )
            } catch(e: Exception) { e.printStackTrace() }"""

content = content.replace(target_init, replacement_init)

# block device function
content += """
    fun toggleDeviceBlock(deviceId: String, block: Boolean) {
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            repository.toggleDeviceBlock(deviceId, block)
            val actionEng = if (block) "Blocked device: $deviceId" else "Unblocked device: $deviceId"
            val actionUrdu = if (block) "ڈیوائس بلاک کی گئی: $deviceId" else "ڈیوائس ان بلاک کی گئی: $deviceId"
            logAction(actionEng, actionUrdu)
        }
    }
"""

with open('app/src/main/java/com/example/ui/TatViewModel.kt', 'w') as f:
    f.write(content)
