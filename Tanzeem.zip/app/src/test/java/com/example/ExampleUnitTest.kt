package com.example

import com.example.data.Custodian
import org.junit.Assert.*
import org.junit.Test

class ExampleUnitTest {
  @Test
  fun addition_isCorrect() {
    assertEquals(4, 2 + 2)
  }

  @Test
  fun testCustodianActiveRotationAndPastExclusion() {
    val now = System.currentTimeMillis()
    val oldCustodian = Custodian(
        id = 1L,
        name = "Manzoor",
        isCurrent = false,
        isPast = true,
        startDate = now - 100000,
        endDate = now - 1000
    )
    val newCustodian = Custodian(
        id = 2L,
        name = "Abdul Samad",
        isCurrent = true,
        isPast = false,
        startDate = now,
        endDate = now + 100000
    )
    val upcomingCustodian = Custodian(
        id = 3L,
        name = "Farhan",
        isCurrent = false,
        isPast = false,
        startDate = now + 200000,
        endDate = now + 300000
    )

    val allCustodians = listOf(oldCustodian, newCustodian, upcomingCustodian)

    // UI filter for members, custodians, and admins: only active and upcoming
    val visibleCustodians = allCustodians
        .filter { !it.isPast && (it.isCurrent || it.endDate >= now) }
        .sortedWith(compareBy({ !it.isCurrent }, { it.orderIndex }))

    // Old custodian must be excluded from UI list
    assertFalse(visibleCustodians.any { it.name == "Manzoor" })
    assertEquals(2, visibleCustodians.size)
    assertEquals("Abdul Samad", visibleCustodians.first().name)
    assertTrue(visibleCustodians.first().isCurrent)

    // All custodians (including old/past) remain available for the PDF report
    val forReport = allCustodians.sortedWith(
        compareBy<Custodian> { 
            when {
                it.isPast || (!it.isCurrent && it.endDate < now) -> 0
                it.isCurrent -> 1
                else -> 2
            }
        }.thenBy { it.startDate }
    )
    assertEquals(3, forReport.size)
    assertEquals("Manzoor", forReport.first().name)
    assertTrue(forReport.first().isPast)
  }
}
