package com.example.network

import com.example.BuildConfig
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.delay
import okhttp3.OkHttpClient
import retrofit2.HttpException
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.http.Path
import retrofit2.http.Query
import java.util.concurrent.TimeUnit

interface GeminiApiService {
    @POST("v1beta/models/{model}:generateContent")
    suspend fun generateContent(
        @Path("model") model: String,
        @Query("key") apiKey: String,
        @Body request: GeminiRequest
    ): GeminiResponse

    @POST("v1beta/models/{model}:streamGenerateContent?alt=sse")
    @retrofit2.http.Streaming
    suspend fun streamGenerateContent(
        @Path("model") model: String,
        @Query("key") apiKey: String,
        @Body request: GeminiRequest
    ): okhttp3.ResponseBody
}

object GeminiClient {
    private const val BASE_URL = "https://generativelanguage.googleapis.com/"

    // Candidate models in order of preference: primary latest model, followed by ultra-stable fallbacks
    private val MODEL_CASCADE = listOf(
        "gemini-3.8-flash",
        "gemini-3.5-flash",
        "gemini-2.5-flash"
    )

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()

    private val moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()

    private val retrofit = Retrofit.Builder()
        .baseUrl(BASE_URL)
        .client(okHttpClient)
        .addConverterFactory(MoshiConverterFactory.create(moshi))
        .build()

    val service: GeminiApiService by lazy {
        retrofit.create(GeminiApiService::class.java)
    }

    suspend fun generateGeminiResponse(prompt: String, systemInstruction: String? = null): String {
        val apiKey = BuildConfig.GEMINI_API_KEY.trim().removeSurrounding("\"").removeSurrounding("'")
        if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
            return "Error: Gemini API key is not configured. Please enter a valid key in the Secrets panel."
        }

        val request = GeminiRequest(
            contents = listOf(Content(parts = listOf(Part(text = prompt)))),
            systemInstruction = systemInstruction?.let { Content(parts = listOf(Part(text = it))) }
        )

        var lastException: Exception? = null

        // Try primary model (gemini-3.8-flash) then fallback models if 503/429/5xx occurs
        for (modelName in MODEL_CASCADE) {
            for (attempt in 1..2) {
                try {
                    val response = service.generateContent(modelName, apiKey, request)
                    val reply = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
                    if (!reply.isNullOrBlank()) {
                        return reply
                    }
                } catch (e: Exception) {
                    lastException = e
                    val isRecoverable = when (e) {
                        is HttpException -> e.code() in listOf(503, 500, 502, 504, 429)
                        is java.io.IOException -> true
                        else -> false
                    }
                    if (isRecoverable) {
                        delay(600L * attempt)
                    } else {
                        break // Non-recoverable error for this model, try next model
                    }
                }
            }
        }

        return "معذرت، اس وقت اے آئی سروس پر عارضی لوڈ ہے۔ براہ کرم کچھ دیر بعد دوبارہ سوال پوچھیے۔"
    }

    suspend fun streamGeminiResponse(prompt: String, systemInstruction: String? = null, onChunk: (String) -> Unit) {
        val apiKey = BuildConfig.GEMINI_API_KEY.trim().removeSurrounding("\"").removeSurrounding("'")
        if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
            onChunk("Error: Gemini API key is not configured. Please enter a valid key in the Secrets panel.")
            return
        }

        val request = GeminiRequest(
            contents = listOf(Content(parts = listOf(Part(text = prompt)))),
            systemInstruction = systemInstruction?.let { Content(parts = listOf(Part(text = it))) }
        )

        var streamedSuccessfully = false
        var lastException: Exception? = null

        for (modelName in MODEL_CASCADE) {
            for (attempt in 1..2) {
                try {
                    val response = service.streamGenerateContent(modelName, apiKey, request)
                    var receivedAnyChunk = false

                    kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                        response.byteStream().bufferedReader().use { reader ->
                            var line: String?
                            while (reader.readLine().also { line = it } != null) {
                                if (line!!.startsWith("data: ")) {
                                    val jsonStr = line!!.substring(6)
                                    if (jsonStr.trim() == "[DONE]") continue
                                    try {
                                        val json = org.json.JSONObject(jsonStr)
                                        val candidates = json.optJSONArray("candidates")
                                        if (candidates != null && candidates.length() > 0) {
                                            val content = candidates.getJSONObject(0).optJSONObject("content")
                                            val parts = content?.optJSONArray("parts")
                                            if (parts != null && parts.length() > 0) {
                                                val text = parts.getJSONObject(0).optString("text", "")
                                                if (text.isNotEmpty()) {
                                                    receivedAnyChunk = true
                                                    onChunk(text)
                                                }
                                            }
                                        }
                                    } catch (e: Exception) {
                                        // Ignore partial JSON parsing glitches in streaming chunk
                                    }
                                }
                            }
                        }
                    }

                    if (receivedAnyChunk) {
                        streamedSuccessfully = true
                        return
                    }
                } catch (e: Exception) {
                    lastException = e
                    val isRecoverable = when (e) {
                        is HttpException -> e.code() in listOf(503, 500, 502, 504, 429)
                        is java.io.IOException -> true
                        else -> false
                    }
                    if (isRecoverable) {
                        delay(600L * attempt)
                    } else {
                        break
                    }
                }
            }
        }

        if (!streamedSuccessfully) {
            onChunk("معذرت، اس وقت اے آئی سروس پر عارضی لوڈ کی وجہ سے رابطہ نہیں ہو سکا۔ براہ کرم دوبارہ سوال پوچھیے۔")
        }
    }
}
