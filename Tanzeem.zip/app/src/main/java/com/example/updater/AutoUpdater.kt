package com.example.updater

import android.app.DownloadManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.util.Log
import androidx.core.content.FileProvider
import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

object AutoUpdater {
    private const val GITHUB_REPO = "mycamry004/Tanzeem-"
    private const val TAG = "AutoUpdater"

    data class UpdateInfo(
        val isUpdateAvailable: Boolean,
        val latestVersionName: String,
        val downloadUrl: String,
        val releaseNotes: String
    )

    suspend fun checkForUpdates(): UpdateInfo? = withContext(Dispatchers.IO) {
        try {
            val apiUrl = "https://api.github.com/repos/$GITHUB_REPO/releases/latest"
            val url = URL(apiUrl)
            val connection = url.openConnection() as HttpURLConnection
            connection.requestMethod = "GET"
            connection.setRequestProperty("Accept", "application/vnd.github.v3+json")
            
            if (connection.responseCode == HttpURLConnection.HTTP_OK) {
                val response = connection.inputStream.bufferedReader().use { it.readText() }
                val json = JSONObject(response)
                
                val latestTag = json.getString("tag_name").replace("v", "", ignoreCase = true)
                val body = json.optString("body", "No release notes available.")
                
                val assets = json.getJSONArray("assets")
                var downloadUrl = ""
                for (i in 0 until assets.length()) {
                    val asset = assets.getJSONObject(i)
                    if (asset.getString("name").endsWith(".apk")) {
                        downloadUrl = asset.getString("browser_download_url")
                        break
                    }
                }
                
                if (downloadUrl.isEmpty()) {
                    return@withContext null
                }
                
                val currentVersion = BuildConfig.VERSION_NAME.replace("v", "", ignoreCase = true)
                
                val isUpdateAvailable = isRemoteVersionHigher(currentVersion, latestTag)
                
                return@withContext UpdateInfo(
                    isUpdateAvailable = isUpdateAvailable,
                    latestVersionName = latestTag,
                    downloadUrl = downloadUrl,
                    releaseNotes = body
                )
            } else {
                Log.d(TAG, "API returned code ${connection.responseCode}")
            }
        } catch (e: Exception) {
            Log.d(TAG, "Error checking for updates", e)
        }
        return@withContext null
    }

    private fun isRemoteVersionHigher(local: String, remote: String): Boolean {
        val localParts = local.split(".").map { it.toIntOrNull() ?: 0 }
        val remoteParts = remote.split(".").map { it.toIntOrNull() ?: 0 }
        val maxLength = maxOf(localParts.size, remoteParts.size)
        
        for (i in 0 until maxLength) {
            val l = localParts.getOrElse(i) { 0 }
            val r = remoteParts.getOrElse(i) { 0 }
            if (r > l) return true
            if (l > r) return false
        }
        return false
    }

    fun downloadAndInstallUpdate(context: Context, downloadUrl: String, versionName: String) {
        try {
            val fileName = "update-$versionName.apk"
            val request = DownloadManager.Request(Uri.parse(downloadUrl))
                .setTitle("Downloading Update")
                .setDescription("Downloading version $versionName")
                .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName)
                .setAllowedOverMetered(true)
                .setAllowedOverRoaming(true)
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setMimeType("application/vnd.android.package-archive")
                
            val downloadManager = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            val downloadId = downloadManager.enqueue(request)
            
            val onComplete = object : BroadcastReceiver() {
                override fun onReceive(ctxt: Context, intent: Intent) {
                    val id = intent.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1)
                    if (downloadId == id) {
                        installApk(ctxt, fileName, downloadManager, downloadId)
                        ctxt.unregisterReceiver(this)
                    }
                }
            }
            
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                context.registerReceiver(onComplete, IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE), Context.RECEIVER_EXPORTED)
            } else {
                context.registerReceiver(onComplete, IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE))
            }
        } catch(e: Exception) {
            Log.e(TAG, "Error starting download", e)
        }
    }

    private fun installApk(context: Context, fileName: String, downloadManager: DownloadManager, downloadId: Long) {
        try {
            // First try using DownloadManager's Uri (safest on modern Android)
            val downloadedUri = downloadManager.getUriForDownloadedFile(downloadId)
            if (downloadedUri != null) {
                val intent = Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(downloadedUri, "application/vnd.android.package-archive")
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION
                }
                context.startActivity(intent)
                return
            }
        } catch (e: Exception) {
            Log.d(TAG, "Error installing APK via DownloadManager Uri", e)
        }
        
        // Fallback to FileProvider
        try {
            val file = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), fileName)
            if (file.exists()) {
                val apkUri = FileProvider.getUriForFile(
                    context,
                    "${context.packageName}.fileprovider",
                    file
                )
                val intent = Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(apkUri, "application/vnd.android.package-archive")
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
            }
        } catch (e: Exception) {
            Log.d(TAG, "Error installing APK via FileProvider", e)
        }
    }
}
