package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

@OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
@Composable
fun ApplePwaTutorial(
    isUrdu: Boolean,
    primaryColor: Color,
    surfaceColor: Color,
    textColor: Color,
    mutedColor: Color
) {
    val pagerState = rememberPagerState(pageCount = { 3 })
    val coroutineScope = rememberCoroutineScope()

    val slides = listOf(
        TutorialSlide(
            icon = Icons.Outlined.Public,
            title = if (isUrdu) "سفاری میں کھولیں" else "1. Open in Safari",
            description = if (isUrdu) "آئی فون پر سفاری براؤزر کھولیں اور لنک درج کریں۔" else "Open the Safari browser on your iPhone and visit the web app link."
        ),
        TutorialSlide(
            icon = Icons.Outlined.IosShare,
            title = if (isUrdu) "شیئر بٹن دبائیں" else "2. Tap Share Button",
            description = if (isUrdu) "سکرین کے نیچے دیے گئے شیئر بٹن پر کلک کریں۔" else "Tap the Share icon at the bottom of the Safari screen."
        ),
        TutorialSlide(
            icon = Icons.Outlined.AddBox,
            title = if (isUrdu) "'Add to Home Screen' منتخب کریں" else "3. Add to Home Screen",
            description = if (isUrdu) "نیچے سکرول کریں اور 'Add to Home Screen' پر کلک کریں تاکہ یہ ایک ایپ کی طرح محفوظ ہو جائے۔" else "Scroll down the share menu and select 'Add to Home Screen' to save it as an app."
        )
    )

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(surfaceColor)
            .padding(vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        HorizontalPager(
            state = pagerState,
            modifier = Modifier
                .fillMaxWidth()
                .height(230.dp)
        ) { page ->
            val slide = slides[page]
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Box(
                    modifier = Modifier
                        .size(64.dp)
                        .background(primaryColor.copy(alpha = 0.15f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = slide.icon,
                        contentDescription = slide.title,
                        tint = primaryColor,
                        modifier = Modifier.size(32.dp)
                    )
                }
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = slide.title,
                    color = textColor,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = slide.description,
                    color = mutedColor,
                    fontSize = 12.sp,
                    textAlign = TextAlign.Center,
                    lineHeight = 18.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Pager Indicators and Navigation
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Back Button
            IconButton(
                onClick = {
                    coroutineScope.launch {
                        if (pagerState.currentPage > 0) {
                            pagerState.animateScrollToPage(pagerState.currentPage - 1)
                        }
                    }
                },
                enabled = pagerState.currentPage > 0,
                modifier = Modifier.size(36.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.ChevronLeft,
                    contentDescription = "Previous",
                    tint = if (pagerState.currentPage > 0) primaryColor else mutedColor.copy(alpha = 0.3f)
                )
            }

            // Dots Indicator
            Row(
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                repeat(slides.size) { iteration ->
                    val color = if (pagerState.currentPage == iteration) primaryColor else mutedColor.copy(alpha = 0.3f)
                    val width = if (pagerState.currentPage == iteration) 16.dp else 6.dp
                    Box(
                        modifier = Modifier
                            .padding(horizontal = 3.dp)
                            .height(6.dp)
                            .width(width)
                            .clip(CircleShape)
                            .background(color)
                    )
                }
            }

            // Next Button
            IconButton(
                onClick = {
                    coroutineScope.launch {
                        if (pagerState.currentPage < slides.size - 1) {
                            pagerState.animateScrollToPage(pagerState.currentPage + 1)
                        }
                    }
                },
                enabled = pagerState.currentPage < slides.size - 1,
                modifier = Modifier.size(36.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.ChevronRight,
                    contentDescription = "Next",
                    tint = if (pagerState.currentPage < slides.size - 1) primaryColor else mutedColor.copy(alpha = 0.3f)
                )
            }
        }
    }
}

data class TutorialSlide(
    val icon: ImageVector,
    val title: String,
    val description: String
)
