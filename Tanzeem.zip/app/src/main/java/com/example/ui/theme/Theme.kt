package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = EmeraldPrimary,
    onPrimary = Color.White,
    primaryContainer = EmeraldDark,
    onPrimaryContainer = TextOffWhite,
    secondary = GoldAccent,
    onSecondary = Color(0xFF0F172A),
    secondaryContainer = DarkSlateSurfaceVariant,
    onSecondaryContainer = TextOffWhite,
    tertiary = AmberAccent,
    onTertiary = Color(0xFF0F172A),
    background = DarkSlateBackground,
    onBackground = TextOffWhite,
    surface = DarkSlateSurface,
    onSurface = TextOffWhite,
    surfaceVariant = DarkSlateSurfaceVariant,
    onSurfaceVariant = TextOffWhite,
    error = RedForfeited,
    onError = Color.White
)

@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = Typography,
        content = content
    )
}
