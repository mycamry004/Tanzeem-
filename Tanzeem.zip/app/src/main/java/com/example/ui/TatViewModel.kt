package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.Claim
import com.example.data.Custodian
import com.example.data.Member
import com.example.data.AppNotification
import com.example.data.AppDevice
import android.provider.Settings.Secure
import android.os.Build
import com.example.data.TanzeemRepository
import com.example.network.GeminiClient
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

data class ChatMessage(
    val id: String = UUID.randomUUID().toString(),
    val text: String,
    val isUser: Boolean,
    val timestamp: Long = System.currentTimeMillis()
)

class TatViewModel(application: Application) : AndroidViewModel(application) {

    private val prefs = application.getSharedPreferences("TatPrefs", android.content.Context.MODE_PRIVATE)
    private val _isUrdu = MutableStateFlow(prefs.getBoolean("isUrdu", true))

    private val database = AppDatabase.getDatabase(application, viewModelScope)
    private val repository = TanzeemRepository(database.tanzeemDao())

    init {
        com.example.ui.theme.isSystemInDarkTheme = prefs.getBoolean("isDarkTheme", false)
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            try {
                val localeStr = Locale.getDefault().displayName
                val deviceModel = Build.MANUFACTURER + " " + Build.MODEL
                val osVersion = "Android " + Build.VERSION.RELEASE
                repository.registerOrUpdateDevice(
                    AppDevice(
                        deviceId = currentDeviceId,
                        deviceModel = deviceModel,
                        osVersion = osVersion,
                        locale = localeStr,
                        lastActive = System.currentTimeMillis()
                    )
                )
            } catch(e: Exception) { e.printStackTrace() }
            try {
                val dao = database.tanzeemDao()
                if (dao.getMembersCount() == 0) {
                    // AppDatabase.populateDatabase(dao) // Removed to prevent dummy data
                }

                // Self-healing: Deduplicate existing members and custodians unconditionally on start
                val membersList = dao.getAllMembersList()
                val seenQids = mutableSetOf<String>()
                for (member in membersList) {
                    val qidKey = member.qid.trim()
                    if (seenQids.contains(qidKey)) {
                        dao.deleteMember(member)
                    } else {
                        seenQids.add(qidKey)
                    }
                }

                val custodiansList = dao.getAllCustodiansList()
                val seenCustodians = mutableSetOf<String>()
                val df = java.text.SimpleDateFormat("dd MMM yyyy", java.util.Locale.US)
                for (custodian in custodiansList) {
                    val dateStr = df.format(java.util.Date(custodian.startDate))
                    val key = "${custodian.name.trim().lowercase()}_$dateStr"
                    if (seenCustodians.contains(key)) {
                        dao.deleteCustodian(custodian)
                    } else {
                        seenCustodians.add(key)
                    }
                }
                

            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    // Language state: true = Urdu, false = English
    val isUrdu: StateFlow<Boolean> = _isUrdu.asStateFlow()

    // Access Mode: true = Custodian (Admin), false = Member (Read-only)
    private val _isAdminMode = MutableStateFlow(false)
    val isAdminMode: StateFlow<Boolean> = _isAdminMode.asStateFlow()

    private val _isSuperAdmin = MutableStateFlow(false)
    val isSuperAdmin: StateFlow<Boolean> = _isSuperAdmin.asStateFlow()

    // Local DB Observables
    val members: StateFlow<List<Member>> = repository.allMembers
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val custodians: StateFlow<List<Custodian>> = repository.allCustodians
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val claims: StateFlow<List<Claim>> = repository.allClaims
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val notifications: StateFlow<List<AppNotification>> = repository.allNotifications
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val devices: StateFlow<List<AppDevice>> = repository.allDevices
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
        
    val currentDeviceId = Secure.getString(application.contentResolver, Secure.ANDROID_ID) ?: UUID.randomUUID().toString()

    private fun logAction(msgEng: String, msgUrdu: String) {
        if (!_isSuperAdmin.value) {
            viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
                repository.insertNotification(
                    AppNotification(
                        messageEng = msgEng,
                        messageUrdu = msgUrdu
                    )
                )
            }
        }
    }

    // Computed Pool Balance
    val poolBalance: StateFlow<Double> = combine(members, claims) { memberList, claimList ->
        // Contributions: 200 QAR per year paid + surplus paid amount
        var totalContributions = 0.0
        for (m in memberList) {
            if (m.year1Paid) totalContributions += 200.0
            if (m.year2Paid) totalContributions += 200.0
            if (m.year3Paid) totalContributions += 200.0
            totalContributions += m.surplusPaidAmount
        }
        val totalExpenses = claimList.sumOf { it.actualExpenses }
        totalContributions - totalExpenses
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    // AI Advisor Chat state
    private val _chatHistory = MutableStateFlow<List<ChatMessage>>(emptyList())
    val chatHistory: StateFlow<List<ChatMessage>> = _chatHistory.asStateFlow()

    private val _isAdvisorLoading = MutableStateFlow(false)
    val isAdvisorLoading: StateFlow<Boolean> = _isAdvisorLoading.asStateFlow()

    // AI Auditor execution state
    private val _isAuditorLoading = MutableStateFlow(false)
    val isAuditorLoading: StateFlow<Boolean> = _isAuditorLoading.asStateFlow()

    init {
        // Add a welcoming greeting from the AI Advisor
        resetChat()
    }

        fun toggleTheme() {
        val newTheme = !com.example.ui.theme.isSystemInDarkTheme
        com.example.ui.theme.isSystemInDarkTheme = newTheme
        prefs.edit().putBoolean("isDarkTheme", newTheme).apply()
    }

    fun toggleLanguage() {
        _isUrdu.value = !_isUrdu.value
        prefs.edit().putBoolean("isUrdu", _isUrdu.value).apply()
        resetChat() // refresh welcoming message in correct language
    }

    fun setLanguage(isUrdu: Boolean) {
        if (_isUrdu.value != isUrdu) {
            _isUrdu.value = isUrdu
            prefs.edit().putBoolean("isUrdu", isUrdu).apply()
            resetChat()
        }
    }

    fun setAdminMode(enabled: Boolean) {
        _isAdminMode.value = enabled
    }
    
    fun setSuperAdminMode(enabled: Boolean) {
        _isSuperAdmin.value = enabled
    }

    fun resetChat() {
        val welcomeText = if (_isUrdu.value) {
            "السلام علیکم! میں تنظیم امانت تقسیم کا سرکاری اے آئی مشیر ہوں۔ آپ مجھ سے فنڈ کے قواعد، رکنیت، امانت کی گردش، یا جنازے کے کلیم کے بارے میں کچھ بھی پوچھ سکتے ہیں۔"
        } else {
            "Assalamu Alaikum! I am the official Tanzeem Amanat Taqseem Community Support Fund AI Advisor. Ask me anything about fund contributions, custody rotations, or funeral claims."
        }
        _chatHistory.value = listOf(ChatMessage(text = welcomeText, isUser = false))
    }

    // --- Member Administration ---
    fun addMember(name: String, qid: String, phone: String, status: String, y1: Boolean, y2: Boolean, y3: Boolean) {
        viewModelScope.launch {
            val today = SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date())
            repository.insertMember(
                Member(
                    name = name,
                    qid = qid,
                    phone = phone,
                    status = status,
                    year1Paid = y1,
                    year2Paid = y2,
                    year3Paid = y3,
                    year1PaymentDate = if (y1) today else null,
                    year2PaymentDate = if (y2) today else null,
                    year3PaymentDate = if (y3) today else null
                )
            )
            logAction(
                "Added new member: $name",
                "نیا ممبر شامل کیا گیا: $name"
            )
        }
    }

    fun updateMember(member: Member) {
        viewModelScope.launch {
            val oldMember = members.value.find { it.id == member.id }
            repository.updateMember(member)
            
            if (oldMember != null) {
                // Check if payment was made
                val paidNew = (member.year1Paid && !oldMember.year1Paid) || 
                              (member.year2Paid && !oldMember.year2Paid) || 
                              (member.year3Paid && !oldMember.year3Paid) ||
                              (member.surplusPaid && !oldMember.surplusPaid)
                              
                val statusChanged = member.status != oldMember.status
                
                if (paidNew) {
                    logAction(
                        "Payment received from: ${member.name}",
                        "${member.name} سے رقم وصول کی گئی"
                    )
                } else if (statusChanged) {
                    logAction(
                        "Status changed for ${member.name} to ${member.status}",
                        "${member.name} کا اسٹیٹس ${member.status} میں تبدیل ہو گیا"
                    )
                } else {
                    logAction(
                        "Updated member details: ${member.name}",
                        "ممبر کی معلومات اپ ڈیٹ کی گئیں: ${member.name}"
                    )
                }
            }
        }
    }

    fun restoreFromCloud() {
        // Obsolete in Cloud-Native architecture. 
        // Real-time listener already handles this automatically.
    }
    
    fun fetchCheckpoints(onResult: (List<String>) -> Unit) {
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            val checkpoints = com.example.data.CloudSyncManager.fetchCheckpoints()
            kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {
                onResult(checkpoints)
            }
        }
    }
    
    fun createManualBackup(backupName: String, onComplete: (Boolean, String) -> Unit) {
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            try {
                val (success, msg) = com.example.data.CloudSyncManager.syncToCloud(
                    members = members.value,
                    claims = claims.value,
                    custodians = custodians.value,
                    backupName = backupName,
                    isManualBackup = true
                )
                kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {
                    onComplete(success, msg)
                }
            } catch (e: Exception) {
                e.printStackTrace()
                kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {
                    onComplete(false, e.message ?: "Unknown Error")
                }
            }
        }
    }
    
fun restoreCheckpoint(dateStr: String) {
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            try {
                val backup = com.example.data.CloudSyncManager.restoreCheckpoint(dateStr)
                if (backup != null) {
                    // In Cloud-Native, we just overwrite the current_state document in Firebase.
                    // The SnapshotListener in TanzeemRepository will instantly update the UI.
                    com.example.data.CloudSyncManager.syncToCloud(
                        backup.members,
                        backup.claims,
                        backup.custodians,
                        backup.notifications,
                        backup.devices
                    )
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun deleteMember(member: Member) {
        viewModelScope.launch {
            repository.deleteMember(member)
            logAction(
                "Deleted member: ${member.name}",
                "ممبر کو حذف کر دیا گیا: ${member.name}"
            )
        }
    }

    // --- Custodian Rotation and Handover ---
    fun addCustodian(name: String, phone: String, startDate: Long, endDate: Long, orderIndex: Int, password: String) {
        viewModelScope.launch {
            val list = custodians.value
            val currentActive = list.firstOrNull { it.isCurrent }
            val now = System.currentTimeMillis()
            val shouldBeActive = currentActive == null && now in startDate..endDate
            repository.insertCustodian(
                Custodian(name = name, phone = phone, startDate = startDate, endDate = endDate, isCurrent = shouldBeActive, orderIndex = orderIndex, password = password)
            )
        }
    }

    fun updateCustodian(custodian: Custodian) {
        viewModelScope.launch {
            repository.updateCustodian(custodian)
        }
    }

    fun swapCustodians(c1: Custodian, c2: Custodian) {
        viewModelScope.launch {
            repository.swapCustodiansOrder(c1, c2)
        }
    }

    fun forceActiveCustodian(newActive: Custodian) {
        viewModelScope.launch {
            repository.forceActiveCustodian(newActive)
        }
    }

    fun deleteCustodian(custodian: Custodian) {
        viewModelScope.launch {
            repository.deleteCustodian(custodian)
        }
    }

    /**
     * Executes the Sacred AMANAT Handover protocol:
     * - Physical transfer of exact current balance confirmed.
     * - Active custodian access invalidated (password changed/removed or marked as past).
     * - Next custodian in queue promoted to Active.
     * - Generates a secure random password for the incoming custodian.
     * - Outputs a receipt text.
     */
    /**
     * Step 1 of Custodian Handover:
     * - Generates a secure random TEMPORARY password for the incoming custodian.
     * - Updates the next custodian with this temporary password.
     * - Leaves the current custodian active (their access remains active until the next custodian claims with temp password).
     * - Outputs a receipt text.
     */
    fun performHandover(
        currentBalance: Double,
        onComplete: (receipt: String, tempPassword: String, nextName: String, nextPhone: String) -> Unit
    ) {
        viewModelScope.launch {
            val list = custodians.value
            val current = list.firstOrNull { it.isCurrent }
            val next = list.filter { !it.isCurrent && it.startDate > (current?.endDate ?: 0L) }
                .minByOrNull { it.orderIndex }
                ?: list.firstOrNull { !it.isCurrent } // fallback to any other non-current

            if (current != null && next != null) {
                // Generate temporary unique password for incoming (random 5-character string)
                val allowedChars = ('a'..'z') + ('0'..'9')
                val generatedTempPassword = (1..5)
                    .map { allowedChars.random() }
                    .joinToString("")

                // Set tempPassword on the next custodian
                val updatedNext = next.copy(
                    tempPassword = generatedTempPassword
                )
                repository.updateCustodian(updatedNext)

                // Generate dispatch receipt summary
                val dateFormat = SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.getDefault())
                val nowStr = dateFormat.format(Date())

                val receipt = if (_isUrdu.value) {
                    """
                    سرکاری عارضی چابی منتقلی رسید
                    -----------------------------
                    تاریخ منتقلی: $nowStr
                    منجانب (سابقہ امانت دار): ${current.name}
                    الیٰ (نیا امانت دار): ${next.name}
                    منتقل شدہ رقم: ${String.format(Locale.US, "%,.2f", currentBalance)} ریال (QAR)
                    حیثیت: عارضی چابی کامیابی سے تخلیق کر دی گئی ہے۔
                    
                    انتباہ: نیا نگران لاگ ان کرنے اور عارضی چابی درج کر کے اپنا مستقل پاس ورڈ حاصل کر سکتا ہے۔ تب تک سابقہ نگران کا پاس ورڈ فعال رہے گا۔
                    """.trimIndent()
                } else {
                    """
                    OFFICIAL TEMPORARY HANDOVER RECEIPT
                    ---------------------------------
                    Timestamp: $nowStr
                    Outbound Custodian (Amanat Holder): ${current.name}
                    Inbound Custodian (New Custodian): ${next.name}
                    Transferred Balance: ${String.format(Locale.US, "%,.2f", currentBalance)} QAR
                    Status: Temporary Activation Code generated successfully.
                    
                    Security Notice: The incoming custodian can activate custody and generate their secure personal password using the temporary code. The outbound custodian's access remains active until activation is completed.
                    """.trimIndent()
                }

                onComplete(receipt, generatedTempPassword, next.name, next.phone)
            }
        }
    }

    /**
     * Step 2 of Custodian Handover:
     * - Checks if the temporary password matches a custodian's tempPassword.
     * - Generates a secure random final password for them.
     * - Demotes the current active custodian and clears their password.
     * - Promotes the matching custodian to current active with the final password.
     */
    fun activateNewCustodian(
        tempPass: String,
        onResult: (success: Boolean, generatedPass: String, errorMsg: String) -> Unit
    ) {
        viewModelScope.launch {
            val list = custodians.value
            val trimmedTemp = tempPass.trim()
            if (trimmedTemp.isEmpty()) {
                onResult(false, "", if (_isUrdu.value) "براہ کرم عارضی پاس ورڈ درج کریں۔" else "Please enter the temporary password.")
                return@launch
            }

            val matchingCustodian = list.firstOrNull { it.tempPassword.trim().equals(trimmedTemp, ignoreCase = true) }
            if (matchingCustodian == null) {
                onResult(false, "", if (_isUrdu.value) "غلط عارضی پاس ورڈ۔ دوبارہ کوشش کریں۔" else "Incorrect temporary password. Please try again.")
                return@launch
            }

            val finalPassword = if (matchingCustodian.password.isNotEmpty()) {
                matchingCustodian.password
            } else {
                val allowedChars = ('a'..'z') + ('0'..'9')
                (1..6).map { allowedChars.random() }.joinToString("")
            }

            // 1. Demote current active custodian(s) and clear their password
            val currentActiveList = list.filter { it.isCurrent }
            for (curr in currentActiveList) {
                val demotedCurr = curr.copy(
                    isCurrent = false,
                    password = ""
                )
                repository.updateCustodian(demotedCurr)
            }

            // 2. Promote matching custodian to active, set final password, clear temp password
            val promotedCustodian = matchingCustodian.copy(
                isCurrent = true,
                password = finalPassword,
                tempPassword = ""
            )
            repository.updateCustodian(promotedCustodian)

            onResult(true, finalPassword, "")
        }
    }

    // --- Claims Audit ---
    fun addClaim(claim: Claim) {
        viewModelScope.launch {
            repository.insertClaim(claim)
            
            val currentMembers = members.value
            if (currentMembers.isEmpty()) return@launch

            // Determine which year to consume
            val hasYear3Payments = currentMembers.any { it.year3Paid }
            val hasYear2Payments = currentMembers.any { it.year2Paid }
            val hasYear1Payments = currentMembers.any { it.year1Paid }

            val yearToConsume = when {
                hasYear3Payments -> 3
                hasYear2Payments -> 2
                hasYear1Payments -> 1
                else -> 1
            }

            // Deficit is actualExpenses - allocatedCap. If deficit is positive, all members share the burden.
            val deficit = claim.deficitRecoupment
            val perMemberDeficit = if (deficit > 0) deficit / currentMembers.size else 0.0

            for (m in currentMembers) {
                val updated = m.copy(
                    year1Paid = if (yearToConsume == 1) false else m.year1Paid,
                    year1PaymentDate = if (yearToConsume == 1) null else m.year1PaymentDate,
                    
                    year2Paid = if (yearToConsume == 2) false else m.year2Paid,
                    year2PaymentDate = if (yearToConsume == 2) null else m.year2PaymentDate,
                    
                    year3Paid = if (yearToConsume == 3) false else m.year3Paid,
                    year3PaymentDate = if (yearToConsume == 3) null else m.year3PaymentDate,
                    
                    surplusOwed = m.surplusOwed + perMemberDeficit
                )
                repository.updateMember(updated)
            }
        }
    }

    fun deleteClaim(claim: Claim) {
        viewModelScope.launch {
            repository.deleteClaim(claim)
        }
    }

    /**
     * Executes an AI-powered constitutional audit ruling on a prospective claim.
     */
    fun auditClaimWithGemini(
        deceasedName: String,
        deceasedQid: String,
        residencyStatus: String,
        scenario: String,
        allocatedCap: Double,
        actualExpenses: Double,
        onComplete: (Claim) -> Unit
    ) {
        viewModelScope.launch {
            _isAuditorLoading.value = true

            // Formulate standard constitution audit prompt
            val prompt = """
                As the Supreme Tanzeem Amanat Taqseem AI Constitutional Auditor, analyze the following community claim:
                - Deceased Name: $deceasedName
                - QID Number: $deceasedQid
                - Residency Status at Death: $residencyStatus
                - Selected Scenario: $scenario
                - Benefit Cap Allocation: $allocatedCap QAR
                - Actual Expenses Incurred: $actualExpenses QAR
                
                COMMUNITY CONSTITUTION PILLARS:
                1. TANZEEM: Fixed 2-year annual cycle (200 QAR/year). Strictly non-refundable. Coverage is strictly FORFEITED if the member permanently left Qatar ("Left Qatar for Good").
                2. AMANAT: Physical custody with rotation. 
                3. TAQSEEM: Actual funeral expenses are paid first against allocated benefit caps. 
                   - Local Burial Cap: 10,000 QAR
                   - Repatriation Cap: 15,000 QAR
                   - Vacation Death Cap: 5,000 QAR
                   - Left Qatar permanently Cap: 0 QAR
                   - Strict Payout Limit: Regardless of how many years of contributions have been collected (e.g., even if 3 years of payments are collected), the deceased member receives exactly one year's worth of the benefit payout (the specified cap of 10k/15k/5k QAR) under their corresponding scenario. It is never multiplied by the number of contribution years.
                   Any SURPLUS (Allocated Cap - Actual Expenses) must be handed over to the deceased's immediate family.
                   Any DEFICIT (Actual Expenses - Allocated Cap) must be recovered/recouped from the next year's collective pool.
                
                Please evaluate and output an official audit ruling. If Residency Status is "Left Qatar for Good", reject coverage. If status is "Active Qatar" or "On Vacation", approve and calculate:
                1. Approved Benefit Paid: (The lesser of Cap and Actual Expenses)
                2. Surplus Handover to Deceased's Family: (If Actual Expenses < Cap, then Cap - Actual Expenses. Else 0)
                3. Deficit Recoupment Schedule from Next Year's Pool: (If Actual Expenses > Cap, then Actual Expenses - Cap. Else 0)
                
                Output the response clearly under these headers:
                - AUDIT STATUS: (APPROVED or REJECTED)
                - CONSTITUTIONAL RATIONALE: (Explain why based on the 3 pillars)
                - FINANCIAL DISTRIBUTION BREAKDOWN:
                  * Allocated Cap: X QAR
                  * Actual Expenses Paid First: Y QAR
                  * Surplus Handover to Family: Z QAR
                  * Deficit Recoupment from Next Year's Pool: W QAR
            """.trimIndent()

            val systemInstruction = "You are the strict, official Tanzeem Amanat Taqseem Community Support Fund Auditor. Be highly formal, respectful, and authoritative. Reference the three pillars in every audit ruling."

            val rulingText = GeminiClient.generateGeminiResponse(prompt, systemInstruction)

            // Calculate values programmatically to ensure precision in the Room entity
            val isEligible = residencyStatus != "Left Qatar for Good"
            val surplus = if (isEligible && actualExpenses < allocatedCap) {
                allocatedCap - actualExpenses
            } else {
                0.0
            }
            val deficit = if (isEligible && actualExpenses > allocatedCap) {
                actualExpenses - allocatedCap
            } else {
                0.0
            }

            val auditedClaim = Claim(
                deceasedName = deceasedName,
                deceasedQid = deceasedQid,
                residencyStatus = residencyStatus,
                scenario = scenario,
                allocatedCap = allocatedCap,
                actualExpenses = actualExpenses,
                auditRuling = rulingText,
                surplusHandover = surplus,
                deficitRecoupment = deficit
            )

            _isAuditorLoading.value = false
            onComplete(auditedClaim)
        }
    }

    // --- AI Advisor Chat ---
    fun sendChatMessage(text: String) {
        if (text.trim().isEmpty()) return

        val userMessage = ChatMessage(text = text, isUser = true)
        _chatHistory.value = _chatHistory.value + userMessage

        viewModelScope.launch {
            _isAdvisorLoading.value = true

            // Gather context
            val balance = poolBalance.value
            val mList = members.value
            val activeCount = mList.count { it.status != "Left Qatar for Good" }
            val currentCust = custodians.value.firstOrNull { it.isCurrent }?.name ?: "None"

            val systemInstruction = """
                You are the official Tanzeem Amanat Taqseem Community Support Fund AI Advisor, designed for overseas Pakistani members residing in Qatar.
                Answer questions instantly, strictly adhering to the Constitution:
                
                1. TANZEEM (Organization & Ledger):
                   - Fixed 3-year contribution cycle (Year 1, Year 2, and Year 3) of 200 QAR per year.
                   - Contributions are strictly non-refundable under all circumstances.
                   - If a member permanently leaves Qatar ("Left Qatar for Good"), all coverage is forfeited.
                
                2. AMANAT (Sacred Trust & Custody):
                   - The physical cash pool is held directly by trusted community custodians on strict 3-month rotations.
                   - There is no bank account used. It is a cash pool.
                   - This rotation guarantees transparent and decentralized communal trust.
                
                3. TAQSEEM (Distribution & Claims):
                   - The amount that should be given to the deceased member in Scenario A (Death in Qatar, Burial in Qatar), Scenario B (Death in Qatar, Repatriation to Pakistan), and Scenario C (Death in Pakistan on Vacation) is: Total Registered Members x 200 QAR only.
                   - Scenario D (Left Qatar Permanently) is: 0 QAR (Forfeited).
                   - Any surplus is paid immediately to the deceased's family.
                
                LIVE FUND CONTEXT:
                - Current Live Pool Balance: $balance QAR
                - Total Registered Members: ${mList.size}
                - Active Members (covered): $activeCount
                - Active Cash Custodian (Amanat Holder): $currentCust
                
                LANGUAGE RULES:
                - You must support speaking in English, Urdu, and Pashto.
                - Urdu is the official default language for the AI advisor.
                - If the user asks in English -> answer in English.
                - If the user asks in Urdu -> answer in Urdu.
                - If the user asks in Pashto -> answer in Pashto.
                - Keep your answers concise, dignified, warm, and highly helpful. Do not provide long, detailed responses unless explicitly asked.
            """.trimIndent()

            val msgId = java.util.UUID.randomUUID().toString()
            var firstChunk = true
            var fullAnswer = ""

            GeminiClient.streamGeminiResponse(text, systemInstruction) { chunk ->
                fullAnswer += chunk
                if (firstChunk) {
                    firstChunk = false
                    val responseMessage = ChatMessage(id = msgId, text = fullAnswer, isUser = false)
                    _chatHistory.value = _chatHistory.value + responseMessage
                } else {
                    _chatHistory.value = _chatHistory.value.map {
                        if (it.id == msgId) it.copy(text = fullAnswer) else it
                    }
                }
            }

            _isAdvisorLoading.value = false
        }
    }
    fun toggleDeviceBlock(deviceId: String, block: Boolean) {
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            repository.toggleDeviceBlock(deviceId, block)
            val actionEng = if (block) "Blocked device: $deviceId" else "Unblocked device: $deviceId"
            val actionUrdu = if (block) "ڈیوائس بلاک کی گئی: $deviceId" else "ڈیوائس ان بلاک کی گئی: $deviceId"
            logAction(actionEng, actionUrdu)
        }
    }
}

    