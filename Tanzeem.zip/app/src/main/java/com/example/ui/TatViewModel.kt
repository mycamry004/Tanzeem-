package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.Claim
import com.example.data.Custodian
import com.example.data.Member
import com.example.data.AppNotification
import com.example.data.AppDevice
import android.provider.Settings.Secure
import android.os.Build
import com.example.data.TanzeemRepository
import com.example.network.GeminiClient
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

data class ChatMessage(
    val id: String = UUID.randomUUID().toString(),
    val text: String,
    val isUser: Boolean,
    val timestamp: Long = System.currentTimeMillis()
)

class TatViewModel(application: Application) : AndroidViewModel(application) {

    private val prefs = application.getSharedPreferences("TatPrefs", android.content.Context.MODE_PRIVATE)
    private val _isUrdu = MutableStateFlow(prefs.getBoolean("isUrdu", true))

    private val database = AppDatabase.getDatabase(application, viewModelScope)
    private val repository = TanzeemRepository(database.tanzeemDao())

    init {
        com.example.ui.theme.isSystemInDarkTheme = prefs.getBoolean("isDarkTheme", false)
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            try {
                val localeStr = Locale.getDefault().displayName
                val deviceModel = Build.MANUFACTURER + " " + Build.MODEL
                val osVersion = "Android " + Build.VERSION.RELEASE
                repository.registerOrUpdateDevice(
                    AppDevice(
                        deviceId = currentDeviceId,
                        deviceModel = deviceModel,
                        osVersion = osVersion,
                        locale = localeStr,
                        lastActive = System.currentTimeMillis()
                    )
                )
            } catch(e: Exception) { e.printStackTrace() }
                        try {
                val dao = database.tanzeemDao()
                if (dao.getMembersCount() == 0) {
                    // AppDatabase.populateDatabase(dao) // Removed to prevent dummy data
                }

                // Self-healing: Deduplicate existing members and custodians unconditionally on start
                val membersList = dao.getAllMembersList()
                val seenQids = mutableSetOf<String>()
                for (member in membersList) {
                    val qidKey = member.qid.trim()
                    if (seenQids.contains(qidKey)) {
                        dao.deleteMember(member)
                    } else {
                        seenQids.add(qidKey)
                    }
                }

                val custodiansList = dao.getAllCustodiansList()
                val seenCustodians = mutableSetOf<String>()
                val df = java.text.SimpleDateFormat("dd MMM yyyy", java.util.Locale.US)
                for (custodian in custodiansList) {
                    val dateStr = df.format(java.util.Date(custodian.startDate))
                    val key = "${custodian.name.trim().lowercase()}_$dateStr"
                    if (seenCustodians.contains(key)) {
                        dao.deleteCustodian(custodian)
                    } else {
                        seenCustodians.add(key)
                    }
                }
                

            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    // Language state: true = Urdu, false = English
    val isUrdu: StateFlow<Boolean> = _isUrdu.asStateFlow()

    // Access Mode: true = Custodian (Admin), false = Member (Read-only)
    private val _isAdminMode = MutableStateFlow(false)
    val isAdminMode: StateFlow<Boolean> = _isAdminMode.asStateFlow()

    private val _isSuperAdmin = MutableStateFlow(false)
    val isSuperAdmin: StateFlow<Boolean> = _isSuperAdmin.asStateFlow()

    // Local DB Observables
    val members: StateFlow<List<Member>> = repository.allMembers
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val custodians: StateFlow<List<Custodian>> = repository.allCustodians
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val claims: StateFlow<List<Claim>> = repository.allClaims
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val notifications: StateFlow<List<AppNotification>> = repository.allNotifications
        .map { list ->
            list.filter { notif ->
                !notif.isAdminAction &&
                !notif.actorName.equals("Admin", ignoreCase = true) &&
                !notif.messageEng.startsWith("Admin", ignoreCase = true) &&
                !notif.messageUrdu.startsWith("ایڈمن")
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val devices: StateFlow<List<AppDevice>> = repository.allDevices
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
        
    val currentDeviceId = Secure.getString(application.contentResolver, Secure.ANDROID_ID) ?: UUID.randomUUID().toString()

    fun logAction(msgEng: String, msgUrdu: String, category: String = "General", customActor: String? = null) {
        if (_isAdminMode.value || _isSuperAdmin.value) {
            // Any addition or changes in admin mode will not be listed in the notification center.
            return
        }
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            val activeName = customActor ?: (custodians.value.firstOrNull { it.isCurrent }?.name ?: "Custodian")
            repository.insertNotification(
                AppNotification(
                    messageEng = msgEng,
                    messageUrdu = msgUrdu,
                    category = category,
                    actorName = activeName,
                    isAdminAction = false
                )
            )
        }
    }

    fun deleteNotification(id: String) {
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            repository.deleteNotification(id)
        }
    }

    // Computed Pool Balance
    val poolBalance: StateFlow<Double> = combine(members, claims) { memberList, claimList ->
        // Contributions: 200 QAR per year paid + surplus paid amount
        var totalContributions = 0.0
        for (m in memberList) {
            if (m.year1Paid) totalContributions += 200.0
            if (m.year2Paid) totalContributions += 200.0
            if (m.year3Paid) totalContributions += 200.0
            totalContributions += m.surplusPaidAmount
        }
        val totalExpenses = claimList.sumOf { it.actualExpenses }
        totalContributions - totalExpenses
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    // AI Advisor Chat state
    private val _chatHistory = MutableStateFlow<List<ChatMessage>>(emptyList())
    val chatHistory: StateFlow<List<ChatMessage>> = _chatHistory.asStateFlow()

    private val _isAdvisorLoading = MutableStateFlow(false)
    val isAdvisorLoading: StateFlow<Boolean> = _isAdvisorLoading.asStateFlow()

    // AI Auditor execution state
    private val _isAuditorLoading = MutableStateFlow(false)
    val isAuditorLoading: StateFlow<Boolean> = _isAuditorLoading.asStateFlow()

    init {
        // Add a welcoming greeting from the AI Advisor
        resetChat()

        viewModelScope.launch {
            val currentList = repository.allCustodians.firstOrNull { it.isNotEmpty() } ?: emptyList()
            if (currentList.isNotEmpty() && currentList.none { it.isCurrent }) {
                val firstCust = currentList.filter { !it.isPast }.minByOrNull { it.orderIndex } ?: currentList.firstOrNull { !it.isPast }
                if (firstCust != null) {
                    repository.forceActiveCustodian(firstCust)
                }
            }
        }
    }

        fun toggleTheme() {
        val newTheme = !com.example.ui.theme.isSystemInDarkTheme
        com.example.ui.theme.isSystemInDarkTheme = newTheme
        prefs.edit().putBoolean("isDarkTheme", newTheme).apply()
    }

    fun toggleLanguage() {
        _isUrdu.value = !_isUrdu.value
        prefs.edit().putBoolean("isUrdu", _isUrdu.value).apply()
        resetChat() // refresh welcoming message in correct language
    }

    fun setLanguage(isUrdu: Boolean) {
        if (_isUrdu.value != isUrdu) {
            _isUrdu.value = isUrdu
            prefs.edit().putBoolean("isUrdu", isUrdu).apply()
            resetChat()
        }
    }

    fun setAdminMode(enabled: Boolean) {
        _isAdminMode.value = enabled
    }
    
    fun setSuperAdminMode(enabled: Boolean) {
        _isSuperAdmin.value = enabled
    }

    fun resetChat() {
        val welcomeText = if (_isUrdu.value) {
            "السلام علیکم! میں تنظیم امانت تقسیم کا سرکاری اے آئی مشیر ہوں۔ آپ مجھ سے فنڈ کے قواعد، رکنیت، امانت کی گردش، یا جنازے کے دعوے کے بارے میں کچھ بھی پوچھ سکتے ہیں۔"
        } else {
            "Assalamu Alaikum! I am the official Tanzeem Amanat Taqseem Community Support Fund AI Advisor. Ask me anything about fund contributions, custody rotations, or funeral claims."
        }
        _chatHistory.value = listOf(ChatMessage(text = welcomeText, isUser = false))
    }

    // --- Member Administration ---
    fun addMember(
        name: String,
        qid: String,
        phone: String,
        status: String,
        y1: Boolean,
        y2: Boolean,
        y3: Boolean,
        y1Date: String? = null,
        y2Date: String? = null,
        y3Date: String? = null
    ) {
        viewModelScope.launch {
            val today = SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date())
            repository.insertMember(
                Member(
                    name = name,
                    qid = qid,
                    phone = phone,
                    status = status,
                    year1Paid = y1,
                    year2Paid = y2,
                    year3Paid = y3,
                    year1PaymentDate = if (y1) (y1Date ?: today) else null,
                    year2PaymentDate = if (y2) (y2Date ?: today) else null,
                    year3PaymentDate = if (y3) (y3Date ?: today) else null
                )
            )
            logAction(
                "Added new member: $name (QID: $qid)",
                "نیا ممبر شامل کیا گیا: $name (شناختی نمبر: $qid)",
                "Member"
            )
        }
    }

    fun updateMember(member: Member) {
        viewModelScope.launch {
            val oldMember = members.value.find { it.id == member.id }
            repository.updateMember(member)
            
            if (oldMember != null) {
                // Check if payment was made
                val paidNew = (member.year1Paid && !oldMember.year1Paid) || 
                              (member.year2Paid && !oldMember.year2Paid) || 
                              (member.year3Paid && !oldMember.year3Paid) ||
                              (member.surplusPaid && !oldMember.surplusPaid)
                              
                val statusChanged = member.status != oldMember.status
                
                if (paidNew) {
                    val yearPaid = when {
                        member.year3Paid && !oldMember.year3Paid -> "Year 3"
                        member.year2Paid && !oldMember.year2Paid -> "Year 2"
                        member.year1Paid && !oldMember.year1Paid -> "Year 1"
                        member.surplusPaid && !oldMember.surplusPaid -> "Surplus"
                        else -> "Fee"
                    }
                    logAction(
                        "Payment received from ${member.name} ($yearPaid - 200 QAR)",
                        "${member.name} سے رقم وصول کی گئی ($yearPaid - 200 ریال)",
                        "Payment"
                    )
                } else if (statusChanged) {
                    logAction(
                        "Status changed for ${member.name} to ${member.status}",
                        "${member.name} کا اسٹیٹس ${member.status} میں تبدیل ہو گیا",
                        "Member"
                    )
                } else {
                    logAction(
                        "Updated member details: ${member.name}",
                        "ممبر کی معلومات اپ ڈیٹ کی گئیں: ${member.name}",
                        "Member"
                    )
                }
            }
        }
    }

    fun restoreFromCloud() {
        // Obsolete in Cloud-Native architecture. 
        // Real-time listener already handles this automatically.
    }
    
    fun fetchCheckpoints(onResult: (List<String>) -> Unit) {
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            val checkpoints = com.example.data.CloudSyncManager.fetchCheckpoints()
            kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {
                onResult(checkpoints)
            }
        }
    }
    
    fun createManualBackup(backupName: String, onComplete: (Boolean, String) -> Unit) {
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            try {
                val (success, msg) = com.example.data.CloudSyncManager.syncToCloud(
                    members = members.value,
                    claims = claims.value,
                    custodians = custodians.value,
                    notifications = notifications.value,
                    devices = devices.value,
                    backupName = backupName,
                    isManualBackup = true
                )
                kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {
                    onComplete(success, msg)
                }
            } catch (e: Exception) {
                e.printStackTrace()
                kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {
                    onComplete(false, e.message ?: "Unknown Error")
                }
            }
        }
    }
    
    fun restoreCheckpoint(dateStr: String, onComplete: ((Boolean) -> Unit)? = null) {
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            try {
                val backup = com.example.data.CloudSyncManager.restoreCheckpoint(dateStr)
                if (backup != null) {
                    repository.restoreFromBackup(backup)
                    logAction(
                        "Restored database checkpoint from $dateStr",
                        "ڈیٹا بیس چیک پوائنٹ بحال کیا گیا: $dateStr",
                        "System"
                    )
                    kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {
                        onComplete?.invoke(true)
                    }
                } else {
                    kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {
                        onComplete?.invoke(false)
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
                kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {
                    onComplete?.invoke(false)
                }
            }
        }
    }

    fun deleteMember(member: Member) {
        viewModelScope.launch {
            repository.deleteMember(member)
            logAction(
                "Removed member: ${member.name} (QID: ${member.qid})",
                "ممبر کو خارج کر دیا گیا: ${member.name} (شناختی نمبر: ${member.qid})",
                "Member"
            )
        }
    }

    // --- Custodian Rotation and Handover ---
    
    fun cleanupMultipleActiveCustodians(trueActive: Custodian) {
        viewModelScope.launch {
            val list = custodians.value
            val newCustodians = list.map { curr ->
                if (curr.id == trueActive.id || (curr.name == trueActive.name && curr.startDate == trueActive.startDate)) {
                    curr.copy(isCurrent = true)
                } else {
                    curr.copy(isCurrent = false)
                }
            }
            repository.updateCustodiansList(newCustodians)
        }
    }

    fun addCustodian(name: String, phone: String, startDate: Long, endDate: Long, orderIndex: Int, password: String) {
        viewModelScope.launch {
            val list = custodians.value
            val currentActive = list.firstOrNull { it.isCurrent }
            val now = System.currentTimeMillis()
            val shouldBeActive = currentActive == null && now in startDate..endDate
            repository.insertCustodian(
                Custodian(name = name, phone = phone, startDate = startDate, endDate = endDate, isCurrent = shouldBeActive, orderIndex = orderIndex, password = password)
            )
            logAction(
                "Added $name to custodian rotation queue",
                "$name کو نگران کی گردش کی فہرست میں شامل کیا گیا",
                "Custodian"
            )
        }
    }

    fun updateCustodian(custodian: Custodian) {
        viewModelScope.launch {
            repository.updateCustodian(custodian)
        }
    }

    fun swapCustodians(c1: Custodian, c2: Custodian) {
        viewModelScope.launch {
            repository.swapCustodiansOrder(c1, c2)
        }
    }

    fun moveCustodianUp(custodian: Custodian) {
        viewModelScope.launch {
            val all = custodians.value
            val nonPast = all.filter { !it.isPast }.sortedWith(compareBy({ it.orderIndex }, { it.startDate })).toMutableList()
            val index = nonPast.indexOfFirst { 
                if (custodian.id != 0L && it.id != 0L) it.id == custodian.id 
                else it.name.trim().equals(custodian.name.trim(), ignoreCase = true) 
            }
            if (index > 0) {
                val item = nonPast.removeAt(index)
                nonPast.add(index - 1, item)
                val updatedNonPast = nonPast.mapIndexed { idx, c ->
                    c.copy(orderIndex = idx)
                }
                val past = all.filter { it.isPast }
                val fullList = updatedNonPast + past
                repository.updateCustodiansList(fullList)
                logAction(
                    "Moved custodian ${custodian.name} up in schedule",
                    "نگران ${custodian.name} کی باری اوپر کی گئی",
                    "Custodian"
                )
            }
        }
    }

    fun moveCustodianDown(custodian: Custodian) {
        viewModelScope.launch {
            val all = custodians.value
            val nonPast = all.filter { !it.isPast }.sortedWith(compareBy({ it.orderIndex }, { it.startDate })).toMutableList()
            val index = nonPast.indexOfFirst { 
                if (custodian.id != 0L && it.id != 0L) it.id == custodian.id 
                else it.name.trim().equals(custodian.name.trim(), ignoreCase = true) 
            }
            if (index >= 0 && index < nonPast.size - 1) {
                val item = nonPast.removeAt(index)
                nonPast.add(index + 1, item)
                val updatedNonPast = nonPast.mapIndexed { idx, c ->
                    c.copy(orderIndex = idx)
                }
                val past = all.filter { it.isPast }
                val fullList = updatedNonPast + past
                repository.updateCustodiansList(fullList)
                logAction(
                    "Moved custodian ${custodian.name} down in schedule",
                    "نگران ${custodian.name} کی باری نیچے کی گئی",
                    "Custodian"
                )
            }
        }
    }

    fun reorderActiveCustodians(fromIndex: Int, toIndex: Int) {
        viewModelScope.launch {
            val all = custodians.value
            val nonPast = all.filter { !it.isPast }.sortedWith(compareBy({ it.orderIndex }, { it.startDate })).toMutableList()

            if (fromIndex in nonPast.indices && toIndex in nonPast.indices && fromIndex != toIndex) {
                val item = nonPast.removeAt(fromIndex)
                nonPast.add(toIndex, item)

                val updatedQueue = nonPast.mapIndexed { idx, c ->
                    c.copy(orderIndex = idx)
                }

                val past = all.filter { it.isPast }
                val fullList = updatedQueue + past
                repository.updateCustodiansList(fullList)
                logAction(
                    "Rearranged custodian schedule: ${nonPast[toIndex].name} shifted to position #${toIndex + 1}",
                    "نگران کی باری کی ترتیب تبدیل: ${nonPast[toIndex].name} پوزیشن #${toIndex + 1}",
                    "Custodian"
                )
            }
        }
    }

    fun forceActiveCustodian(newActive: Custodian) {
        viewModelScope.launch {
            repository.forceActiveCustodian(newActive)
            logAction(
                "Switched active custodian to ${newActive.name}",
                "فعال نگران تبدیل کر کے ${newActive.name} کو مقرر کیا گیا",
                "Custodian"
            )
        }
    }

    fun deleteCustodian(custodian: Custodian) {
        viewModelScope.launch {
            repository.deleteCustodian(custodian)
            logAction(
                "Removed ${custodian.name} from custodian list",
                "نگران ${custodian.name} کو فہرست سے خارج کر دیا گیا",
                "Custodian"
            )
        }
    }

    /**
     * Executes the Sacred AMANAT Handover protocol:
     * - Physical transfer of exact current balance confirmed.
     * - Active custodian access invalidated (password changed/removed or marked as past).
     * - Next custodian in queue promoted to Active.
     * - Generates a secure random password for the incoming custodian.
     * - Outputs a receipt text.
     */
    /**
     * Step 1 of Custodian Handover:
     * - Generates a secure random TEMPORARY password for the incoming custodian.
     * - Updates the next custodian with this temporary password.
     * - Leaves the current custodian active (their access remains active until the next custodian claims with temp password).
     * - Outputs a receipt text.
     */
    
    fun adminInitiateHandover(
        targetCustodian: Custodian,
        currentBalance: Double,
        onComplete: (receipt: String, tempPassword: String, nextName: String, nextPhone: String) -> Unit
    ) {
        viewModelScope.launch {
            val list = custodians.value
            val current = list.firstOrNull { it.isCurrent }
            
            // Generate temporary unique password for incoming (random 5-character string)
            val allowedChars = ('a'..'z') + ('0'..'9')
            val generatedTempPassword = (1..5)
                .map { allowedChars.random() }
                .joinToString("")

            // Set tempPassword on the target custodian
            val updatedNext = targetCustodian.copy(
                tempPassword = generatedTempPassword
            )
            repository.updateCustodian(updatedNext)

            // Generate dispatch receipt summary
            val dateFormat = java.text.SimpleDateFormat("dd MMM yyyy, HH:mm", java.util.Locale.getDefault())
            val nowStr = dateFormat.format(java.util.Date())

            val receipt = if (_isUrdu.value) {
                """
                سرکاری عارضی چابی منتقلی رسید (ایڈمن)
                -----------------------------
                تاریخ منتقلی: $nowStr
                منجانب (سابقہ امانت دار): ${current?.name ?: "Admin"}
                الیٰ (نیا امانت دار): ${targetCustodian.name}
                منتقل شدہ رقم: ${String.format(java.util.Locale.US, "%,.2f", currentBalance)} ریال (QAR)
                حیثیت: عارضی چابی کامیابی سے تخلیق کر دی گئی ہے۔
                
                انتباہ: نیا نگران لاگ ان کرنے اور عارضی چابی درج کر کے اپنا مستقل پاس ورڈ حاصل کر سکتا ہے۔ تب تک سابقہ نگران کا پاس ورڈ فعال رہے گا۔
                """.trimIndent()
            } else {
                """
                OFFICIAL TEMPORARY HANDOVER RECEIPT (ADMIN)
                ---------------------------------
                Timestamp: $nowStr
                Outbound Custodian (Amanat Holder): ${current?.name ?: "Admin"}
                Inbound Custodian (Incoming Holder): ${targetCustodian.name}
                Transferred Funds: ${String.format(java.util.Locale.US, "%,.2f", currentBalance)} QAR
                Status: Temporary Handover Key Generated successfully.
                
                NOTICE: The new custodian can log in and enter this temporary key to claim their permanent password. The previous custodian's access remains active until claimed.
                """.trimIndent()
            }

            logAction(
                "Custodianship transfer initiated from ${current?.name ?: "Admin"} to ${targetCustodian.name} (Amount: ${String.format(java.util.Locale.US, "%,.2f", currentBalance)} QAR)",
                "نگرانی کی منتقلی شروع کی گئی: ${current?.name ?: "ایڈمن"} سے ${targetCustodian.name} کو (رقم: ${String.format(java.util.Locale.US, "%,.2f", currentBalance)} ریال)",
                "Custodian"
            )

            onComplete(receipt, generatedTempPassword, targetCustodian.name, targetCustodian.phone)
        }
    }

    fun performHandover(
        currentBalance: Double,
        onComplete: (receipt: String, tempPassword: String, nextName: String, nextPhone: String) -> Unit
    ) {
        viewModelScope.launch {
            val list = custodians.value
            val current = list.firstOrNull { it.isCurrent }
            val next = list.filter { !it.isCurrent && !it.isPast && it.startDate > (current?.endDate ?: 0L) }
                .minByOrNull { it.orderIndex }
                ?: list.firstOrNull { !it.isCurrent && !it.isPast } // fallback to any other non-current, non-past

            if (current != null && next != null) {
                // Generate temporary unique password for incoming (random 5-character string)
                val allowedChars = ('a'..'z') + ('0'..'9')
                val generatedTempPassword = (1..5)
                    .map { allowedChars.random() }
                    .joinToString("")

                // Set tempPassword on the next custodian
                val updatedNext = next.copy(
                    tempPassword = generatedTempPassword
                )
                repository.updateCustodian(updatedNext)

                // Generate dispatch receipt summary
                val dateFormat = SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.getDefault())
                val nowStr = dateFormat.format(Date())

                val receipt = if (_isUrdu.value) {
                    """
                    سرکاری عارضی چابی منتقلی رسید
                    -----------------------------
                    تاریخ منتقلی: $nowStr
                    منجانب (سابقہ امانت دار): ${current.name}
                    الیٰ (نیا امانت دار): ${next.name}
                    منتقل شدہ رقم: ${String.format(Locale.US, "%,.2f", currentBalance)} ریال (QAR)
                    حیثیت: عارضی چابی کامیابی سے تخلیق کر دی گئی ہے۔
                    
                    انتباہ: نیا نگران لاگ ان کرنے اور عارضی چابی درج کر کے اپنا مستقل پاس ورڈ حاصل کر سکتا ہے۔ تب تک سابقہ نگران کا پاس ورڈ فعال رہے گا۔
                    """.trimIndent()
                } else {
                    """
                    OFFICIAL TEMPORARY HANDOVER RECEIPT
                    ---------------------------------
                    Timestamp: $nowStr
                    Outbound Custodian (Amanat Holder): ${current.name}
                    Inbound Custodian (New Custodian): ${next.name}
                    Transferred Balance: ${String.format(Locale.US, "%,.2f", currentBalance)} QAR
                    Status: Temporary Activation Code generated successfully.
                    
                    Security Notice: The incoming custodian can activate custody and generate their secure personal password using the temporary code. The outbound custodian's access remains active until activation is completed.
                    """.trimIndent()
                }

                logAction(
                    "Handover initiated to ${next.name} (Amount: ${String.format(Locale.US, "%,.2f", currentBalance)} QAR)",
                    "نگرانی کی منتقلی شروع کی گئی: ${next.name} کو (رقم: ${String.format(Locale.US, "%,.2f", currentBalance)} ریال)",
                    "Custodian"
                )

                onComplete(receipt, generatedTempPassword, next.name, next.phone)
            }
        }
    }

    /**
     * Step 2 of Custodian Handover:
     * - Checks if the temporary password matches a custodian's tempPassword.
     * - Generates a secure random final password for them.
     * - Demotes the current active custodian, marks them as past custodian (isPast = true).
     * - Promotes the matching custodian to active (isCurrent = true, isPast = false).
     */
    fun activateNewCustodian(
        tempPass: String,
        onResult: (success: Boolean, generatedPass: String, errorMsg: String) -> Unit
    ) {
        viewModelScope.launch {
            val list = custodians.value
            val trimmedTemp = tempPass.trim()
            if (trimmedTemp.isEmpty()) {
                onResult(false, "", if (_isUrdu.value) "براہ کرم عارضی پاس ورڈ درج کریں۔" else "Please enter the temporary password.")
                return@launch
            }

            val matchingCustodian = list.firstOrNull { it.tempPassword.trim().equals(trimmedTemp, ignoreCase = true) }
            if (matchingCustodian == null) {
                onResult(false, "", if (_isUrdu.value) "غلط عارضی پاس ورڈ۔ دوبارہ کوشش کریں۔" else "Incorrect temporary password. Please try again.")
                return@launch
            }

            val finalPassword = if (matchingCustodian.password.isNotBlank()) {
                matchingCustodian.password
            } else {
                val allowedChars = ('a'..'z') + ('0'..'9')
                (1..6).map { allowedChars.random() }.joinToString("")
            }

            val now = System.currentTimeMillis()
            val newCustodians = list.map { curr ->
                val isTarget = (matchingCustodian.id != 0L && curr.id == matchingCustodian.id) ||
                               curr.name.trim().equals(matchingCustodian.name.trim(), ignoreCase = true) ||
                               (curr.tempPassword.isNotBlank() && curr.tempPassword.trim().equals(trimmedTemp, ignoreCase = true))
                
                if (isTarget) {
                    curr.copy(
                        isCurrent = true,
                        isPast = false,
                        password = finalPassword,
                        tempPassword = ""
                    )
                } else if (curr.isCurrent) {
                    // Outgoing custodian becomes a past custodian (removed from active list)
                    curr.copy(
                        isCurrent = false,
                        isPast = true,
                        endDate = if (curr.endDate > now) now else curr.endDate
                    )
                } else {
                    curr
                }
            }
            
            val outgoingCustodian = list.firstOrNull { it.isCurrent }
            val prevName = outgoingCustodian?.name?.ifBlank { "سابقہ نگران" } ?: "سابقہ نگران"
            val newName = matchingCustodian.name

            android.util.Log.d("TatViewModel", "Calling updateCustodiansList with activated custodian $newName")
            repository.updateCustodiansList(newCustodians)

            val currentBal = poolBalance.value
            val formattedBal = String.format(java.util.Locale.US, "%,.2f", currentBal)
            logAction(
                "I ($newName) declare that I have safely received the total fund amount of ($formattedBal) QAR, cash or via bank, from ($prevName) and accept full responsibility for this trust as custodian.",
                "میں \u200F(\u200E$newName\u200E)\u200F اقرار کرتا ہوں کہ میں نے \u200F(\u200E$prevName\u200E)\u200F سے باحفاظت فنڈ کی کل رقم \u200F(\u200E$formattedBal\u200E)\u200F قطری ریال، نقد یا بذریعہ بنک وصول کر لی ہے اور میں بطور نگران اس امانت کی مکمل زمہ داری قبول کرتا ہوںـ",
                "Custodian",
                customActor = newName
            )

            onResult(true, finalPassword, "")
        }
    }

    // --- Claims Audit ---
    fun addClaim(claim: Claim) {
        viewModelScope.launch {
            repository.insertClaim(claim)
            
            val currentMembers = members.value
            if (currentMembers.isEmpty()) return@launch

            // Determine which year to consume
            val hasYear3Payments = currentMembers.any { it.year3Paid }
            val hasYear2Payments = currentMembers.any { it.year2Paid }
            val hasYear1Payments = currentMembers.any { it.year1Paid }

            val yearToConsume = when {
                hasYear3Payments -> 3
                hasYear2Payments -> 2
                hasYear1Payments -> 1
                else -> 1
            }

            // Deficit is actualExpenses - allocatedCap. If deficit is positive, all members share the burden.
            val deficit = claim.deficitRecoupment
            val perMemberDeficit = if (deficit > 0) deficit / currentMembers.size else 0.0

            for (m in currentMembers) {
                val updated = m.copy(
                    year1Paid = if (yearToConsume == 1) false else m.year1Paid,
                    year1PaymentDate = if (yearToConsume == 1) null else m.year1PaymentDate,
                    
                    year2Paid = if (yearToConsume == 2) false else m.year2Paid,
                    year2PaymentDate = if (yearToConsume == 2) null else m.year2PaymentDate,
                    
                    year3Paid = if (yearToConsume == 3) false else m.year3Paid,
                    year3PaymentDate = if (yearToConsume == 3) null else m.year3PaymentDate,
                    
                    surplusOwed = m.surplusOwed + perMemberDeficit
                )
                repository.updateMember(updated)
            }

            logAction(
                "Recorded funeral claim for deceased ${claim.deceasedName} (Amount: ${claim.allocatedCap} QAR)",
                "مرحوم ${claim.deceasedName} کا جنازہ دعویٰ درج کیا گیا (رقم: ${claim.allocatedCap} ریال)",
                "Claim"
            )
        }
    }

    fun deleteClaim(claim: Claim) {
        viewModelScope.launch {
            repository.deleteClaim(claim)
            logAction(
                "Deleted claim record for ${claim.deceasedName}",
                "${claim.deceasedName} کا دعویٰ ریکارڈ حذف کیا گیا",
                "Claim"
            )
        }
    }

    /**
     * Executes an AI-powered constitutional audit ruling on a prospective claim.
     */
    fun auditClaimWithGemini(
        deceasedName: String,
        deceasedQid: String,
        residencyStatus: String,
        scenario: String,
        allocatedCap: Double,
        actualExpenses: Double,
        isUrdu: Boolean = false,
        onComplete: (Claim) -> Unit
    ) {
        viewModelScope.launch {
            _isAuditorLoading.value = true

            val systemInstruction = if (isUrdu) {
                "آپ تنظیم امانت تقسیم کمیونٹی سپورٹ فنڈ کے باضابطہ آئینی آڈیٹر ہیں۔ تمام فیصلہ جات شائستہ، واضح اور دو ٹوک سلیس اردو میں تحریر کریں۔ کسی بھی قسم کے مارک ڈاؤن علامات (#، *، **، وغیرہ) یا خط و کتابت کے دفتری ہیڈرز (TO، FROM، SUBJECT وغیرہ) کا استعمال ہرگز نہ کریں۔ مختصر، جامع اور ٹو دی پوائنٹ فیصلہ لکھیں۔"
            } else {
                "You are the official Tanzeem Amanat Taqseem Community Support Fund Constitutional Auditor. Provide concise, respectful, authoritative, and direct rulings. Do NOT use markdown formatting characters like #, *, **, or bureaucratic memo headers like TO, FROM, DATE, SUBJECT. Keep the output clean, structured, and to the point."
            }

            val prompt = if (isUrdu) {
                """
                تنظیم امانت تقسیم کے آئین کے تحت مندرجہ ذیل کلیم کا باضابطہ آڈٹ کریں اور سلیس اردو میں دو ٹوک اور ٹو دی پوائنٹ فیصلہ دیں:
                - نام مرحوم: $deceasedName
                - قطری شناختی کارڈ (QID): $deceasedQid
                - وفات کے وقت رہائشی حیثیت: $residencyStatus
                - کلیم کی نوعیت: $scenario
                - مقررہ حد فنڈ: $allocatedCap قطری ریال
                - اصل اخراجات: $actualExpenses قطری ریال

                آئینی ضوابط:
                1. تنظیم: مستقل قطر چھوڑنے ("Left Qatar for Good") پر فنڈ کوریج مکمل طور پر منسوخ (مسترد) ہو جاتی ہے۔
                2. امانت: نگران کے پاس جمع فنڈ سے اصل اخراجات کی ادائیگی۔
                3. تقسیم: اصل اخراجات کی ادائیگی مقررہ حد تک۔ اگر اخراجات حد سے کم ہوں تو زائد رقم مرحوم کے اہلخانہ کو دی جائے گی۔ اگر اخراجات حد سے زیادہ ہوں تو خسارہ آئندہ سال کے فنڈ سے پورا ہو گا۔

                براہ کرم بغیر کسی مارک ڈاؤن علامت (# یا *) کے درج ذیل صاف ہیڈنگز کے ساتھ فیصلہ لکھیں:

                آئینی حیثیت: [منظور شدہ یا مسترد شدہ]

                آئینی وجہ:
                [دو سے تین جملوں میں دو ٹوک اور آسان فہم آئینی وضاحت]

                مالی تقسیم:
                - مقررہ حد فنڈ: $allocatedCap قطری ریال
                - منظور شدہ اخراجات: [کم از کم رقم] قطری ریال
                - اہلخانہ کو زائد رقم: [زائد رقم یا صفر] قطری ریال
                - آئندہ سال خسارہ ریکوری: [خسارہ یا صفر] قطری ریال
                """.trimIndent()
            } else {
                """
                Analyze the following community fund claim and output a clean, direct constitutional audit ruling:
                - Deceased Name: $deceasedName
                - QID Number: $deceasedQid
                - Residency Status: $residencyStatus
                - Selected Scenario: $scenario
                - Benefit Cap Allocation: $allocatedCap QAR
                - Actual Expenses: $actualExpenses QAR

                CONSTITUTIONAL PILLARS:
                1. TANZEEM: Coverage is strictly FORFEITED if member permanently left Qatar ("Left Qatar for Good").
                2. AMANAT: Physical custody pool with rotation.
                3. TAQSEEM: Actual expenses paid up to cap. Surplus (Cap - Expenses) given to family. Deficit (Expenses - Cap) recouped from next year pool.

                Output strictly without any markdown symbols (#, *, **), formatted clearly as:

                RULING STATUS: [APPROVED or REJECTED]

                CONSTITUTIONAL RATIONALE:
                [2-3 direct sentences explaining why under fund rules]

                FINANCIAL BREAKDOWN:
                - Allocated Cap: $allocatedCap QAR
                - Approved Expenses: [Lesser of Cap and Expenses] QAR
                - Surplus to Family: [Surplus or 0] QAR
                - Deficit Recoupment: [Deficit or 0] QAR
                """.trimIndent()
            }

            val rawRuling = GeminiClient.generateGeminiResponse(prompt, systemInstruction)

            // Sanitize response: strip any stray markdown symbols (#, *, etc.) and remove bureaucratic memo headers
            val rulingText = rawRuling
                .replace("#", "")
                .replace("*", "")
                .replace("`", "")
                .lines()
                .filterNot { line ->
                    val l = line.trim().lowercase()
                    l.startsWith("to:") || l.startsWith("from:") || l.startsWith("date:") || 
                    l.startsWith("subject:") || l.startsWith("memorandum:") || 
                    l.startsWith("official audit ruling") || l.startsWith("official constitutional")
                }
                .joinToString("\n")
                .trim()

            // Calculate values programmatically to ensure precision in the Room entity
            val isEligible = residencyStatus != "Left Qatar for Good"
            val surplus = if (isEligible && actualExpenses < allocatedCap) {
                allocatedCap - actualExpenses
            } else {
                0.0
            }
            val deficit = if (isEligible && actualExpenses > allocatedCap) {
                actualExpenses - allocatedCap
            } else {
                0.0
            }

            val auditedClaim = Claim(
                deceasedName = deceasedName,
                deceasedQid = deceasedQid,
                residencyStatus = residencyStatus,
                scenario = scenario,
                allocatedCap = allocatedCap,
                actualExpenses = actualExpenses,
                auditRuling = rulingText,
                surplusHandover = surplus,
                deficitRecoupment = deficit
            )

            _isAuditorLoading.value = false
            onComplete(auditedClaim)
        }
    }

    // --- AI Advisor Chat ---
    fun sendChatMessage(text: String) {
        if (text.trim().isEmpty()) return

        val userMessage = ChatMessage(text = text, isUser = true)
        _chatHistory.value = _chatHistory.value + userMessage

        viewModelScope.launch {
            _isAdvisorLoading.value = true

            // Gather context
            val balance = poolBalance.value
            val mList = members.value
            val activeCount = mList.count { it.status != "Left Qatar for Good" }
            val currentCust = custodians.value.firstOrNull { it.isCurrent }?.name ?: "None"

            val systemInstruction = """
                You are the official Tanzeem Amanat Taqseem Community Support Fund AI Advisor, designed for overseas Pakistani members residing in Qatar.
                Answer questions instantly, strictly adhering to the Constitution:
                
                1. TANZEEM (Organization & Ledger):
                   - Fixed 3-year contribution cycle (Year 1, Year 2, and Year 3) of 200 QAR per year.
                   - Contributions are strictly non-refundable under all circumstances.
                   - If a member permanently leaves Qatar ("Left Qatar for Good"), all coverage is forfeited.
                
                2. AMANAT (Sacred Trust & Custody):
                   - The physical cash pool is held directly by trusted community custodians on strict 3-month rotations.
                   - There is no bank account used. It is a cash pool.
                   - This rotation guarantees transparent and decentralized communal trust.
                
                3. TAQSEEM (Distribution & Claims):
                   - The amount that should be given to the deceased member in Scenario A (Death in Qatar, Burial in Qatar), Scenario B (Death in Qatar, Repatriation to Pakistan), and Scenario C (Death in Pakistan on Vacation) is: Total Registered Members x 200 QAR only.
                   - Scenario D (Left Qatar Permanently) is: 0 QAR (Forfeited).
                   - Any surplus is paid immediately to the deceased's family.
                
                LIVE FUND CONTEXT:
                - Current Live Pool Balance: $balance QAR
                - Total Registered Members: ${mList.size}
                - Active Members (covered): $activeCount
                - Active Cash Custodian (Amanat Holder): $currentCust
                
                LANGUAGE & NATURAL SPOKEN CADENCE RULES:
                - You must support speaking in English, Urdu, and Pashto.
                - Urdu is the official default language for the AI advisor.
                - When speaking in Urdu: Speak in genuine, fluent, natural conversational Urdu as a wise, respectful, articulate Pakistani elder (ایک باوقار، شفیق اور فصیح بزرگ).
                - OPTIMIZED FOR NATURAL VOICE SPEECH: Your answer will be read aloud to the user by a Text-To-Speech voice engine. Avoid robotic formatting such as bullet points, markdown bold/headers (**, ###), brackets, or dry lists. Instead, connect ideas with smooth, natural spoken sentences.
                - Use natural Urdu pauses with commas (،) and full stops (۔) so the spoken voice pauses gently and sounds like a real person conversing warmly.
                - Always say "قطری ریال" instead of the English acronym "QAR".
                - CRITICAL URDU VOCABULARY RULE: Never use the Romanized English loanword "کلیم" in Urdu. Always use "دعویٰ" (singular) or "دعوے" (plural), e.g., جنازے کا دعویٰ, اخراجات کے دعوے.
                - If the user asks in English -> answer in clear, warm, conversational English.
                - If the user asks in Urdu -> answer in natural, spoken Urdu.
                - If the user asks in Pashto -> answer in natural Pashto.
                - Keep your answers concise (2 to 4 smooth sentences), dignified, warm, and comforting. Do not provide long, mechanical bullet points unless specifically requested.
            """.trimIndent()

            val msgId = java.util.UUID.randomUUID().toString()
            var firstChunk = true
            var fullAnswer = ""

            GeminiClient.streamGeminiResponse(text, systemInstruction) { chunk ->
                fullAnswer += chunk
                if (firstChunk) {
                    firstChunk = false
                    val responseMessage = ChatMessage(id = msgId, text = fullAnswer, isUser = false)
                    _chatHistory.value = _chatHistory.value + responseMessage
                } else {
                    _chatHistory.value = _chatHistory.value.map {
                        if (it.id == msgId) it.copy(text = fullAnswer) else it
                    }
                }
            }

            _isAdvisorLoading.value = false
        }
    }
    fun toggleDeviceBlock(deviceId: String, block: Boolean) {
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            repository.toggleDeviceBlock(deviceId, block)
            val actionEng = if (block) "Blocked device: $deviceId" else "Unblocked device: $deviceId"
            val actionUrdu = if (block) "ڈیوائس بلاک کی گئی: $deviceId" else "ڈیوائس ان بلاک کی گئی: $deviceId"
            logAction(actionEng, actionUrdu)
        }
    }
}

    