package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.Claim
import com.example.data.Custodian
import com.example.data.Member
import com.example.data.TanzeemRepository
import com.example.network.GeminiClient
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

data class ChatMessage(
    val id: String = UUID.randomUUID().toString(),
    val text: String,
    val isUser: Boolean,
    val timestamp: Long = System.currentTimeMillis()
)

class TatViewModel(application: Application) : AndroidViewModel(application) {

    private val database = AppDatabase.getDatabase(application, viewModelScope)
    private val repository = TanzeemRepository(database.tanzeemDao())

    init {
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            try {
                if (repository.getMembersCount() == 0) {
                    AppDatabase.populateDatabase(database.tanzeemDao())
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    // Language state: true = Urdu, false = English
    private val _isUrdu = MutableStateFlow(false)
    val isUrdu: StateFlow<Boolean> = _isUrdu.asStateFlow()

    // Access Mode: true = Custodian (Admin), false = Member (Read-only)
    private val _isAdminMode = MutableStateFlow(false)
    val isAdminMode: StateFlow<Boolean> = _isAdminMode.asStateFlow()

    // Local DB Observables
    val members: StateFlow<List<Member>> = repository.allMembers
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val custodians: StateFlow<List<Custodian>> = repository.allCustodians
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val claims: StateFlow<List<Claim>> = repository.allClaims
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Computed Pool Balance
    val poolBalance: StateFlow<Double> = combine(members, claims) { memberList, claimList ->
        // Contributions: 200 QAR per year paid
        var totalContributions = 0.0
        for (m in memberList) {
            if (m.year1Paid) totalContributions += 200.0
            if (m.year2Paid) totalContributions += 200.0
            if (m.year3Paid) totalContributions += 200.0
        }
        val totalExpenses = claimList.sumOf { it.actualExpenses }
        totalContributions - totalExpenses
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    // AI Advisor Chat state
    private val _chatHistory = MutableStateFlow<List<ChatMessage>>(emptyList())
    val chatHistory: StateFlow<List<ChatMessage>> = _chatHistory.asStateFlow()

    private val _isAdvisorLoading = MutableStateFlow(false)
    val isAdvisorLoading: StateFlow<Boolean> = _isAdvisorLoading.asStateFlow()

    // AI Auditor execution state
    private val _isAuditorLoading = MutableStateFlow(false)
    val isAuditorLoading: StateFlow<Boolean> = _isAuditorLoading.asStateFlow()

    init {
        // Add a welcoming greeting from the AI Advisor
        resetChat()
    }

    fun toggleLanguage() {
        _isUrdu.value = !_isUrdu.value
        resetChat() // refresh welcoming message in correct language
    }

    fun setLanguage(isUrdu: Boolean) {
        if (_isUrdu.value != isUrdu) {
            _isUrdu.value = isUrdu
            resetChat()
        }
    }

    fun setAdminMode(enabled: Boolean) {
        _isAdminMode.value = enabled
    }

    fun resetChat() {
        val welcomeText = if (_isUrdu.value) {
            "السلام علیکم! میں تنظیم امانت تقسیم کا سرکاری اے آئی مشیر ہوں۔ آپ مجھ سے فنڈ کے قواعد، رکنیت، امانت کی گردش، یا جنازے کے کلیم کے بارے میں کچھ بھی پوچھ سکتے ہیں۔"
        } else {
            "Assalamu Alaikum! I am the official Tanzeem Amanat Taqseem Community Support Fund AI Advisor. Ask me anything about fund contributions, custody rotations, or funeral claims."
        }
        _chatHistory.value = listOf(ChatMessage(text = welcomeText, isUser = false))
    }

    // --- Member Administration ---
    fun addMember(name: String, qid: String, phone: String, status: String, y1: Boolean, y2: Boolean, y3: Boolean) {
        viewModelScope.launch {
            val today = SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date())
            repository.insertMember(
                Member(
                    name = name,
                    qid = qid,
                    phone = phone,
                    status = status,
                    year1Paid = y1,
                    year2Paid = y2,
                    year3Paid = y3,
                    year1PaymentDate = if (y1) today else null,
                    year2PaymentDate = if (y2) today else null,
                    year3PaymentDate = if (y3) today else null
                )
            )
        }
    }

    fun updateMember(member: Member) {
        viewModelScope.launch {
            repository.updateMember(member)
        }
    }

    fun deleteMember(member: Member) {
        viewModelScope.launch {
            repository.deleteMember(member)
        }
    }

    // --- Custodian Rotation and Handover ---
    fun addCustodian(name: String, phone: String, startDate: Long, endDate: Long, orderIndex: Int, password: String) {
        viewModelScope.launch {
            repository.insertCustodian(
                Custodian(name = name, phone = phone, startDate = startDate, endDate = endDate, isCurrent = false, orderIndex = orderIndex, password = password)
            )
        }
    }

    fun updateCustodian(custodian: Custodian) {
        viewModelScope.launch {
            repository.updateCustodian(custodian)
        }
    }

    fun deleteCustodian(custodian: Custodian) {
        viewModelScope.launch {
            repository.deleteCustodian(custodian)
        }
    }

    /**
     * Executes the Sacred AMANAT Handover protocol:
     * - Physical transfer of exact current balance confirmed.
     * - Active custodian access invalidated (password changed/removed or marked as past).
     * - Next custodian in queue promoted to Active.
     * - Generates a secure random password for the incoming custodian.
     * - Outputs a receipt text.
     */
    fun performHandover(
        currentBalance: Double,
        onComplete: (receipt: String, newPassword: String, nextName: String, nextPhone: String) -> Unit
    ) {
        viewModelScope.launch {
            val list = custodians.value
            val current = list.firstOrNull { it.isCurrent }
            val next = list.filter { !it.isCurrent && it.startDate > (current?.endDate ?: 0L) }
                .minByOrNull { it.orderIndex }
                ?: list.firstOrNull { !it.isCurrent } // fallback to any other non-current

            if (current != null && next != null) {
                // Generate secure unique password for incoming
                val allowedChars = ('a'..'z') + ('0'..'9')
                val generatedPassword = (1..6)
                    .map { allowedChars.random() }
                    .joinToString("")

                // Invalidate current custodian
                val updatedCurrent = current.copy(
                    isCurrent = false,
                    password = "" // invalidate password
                )
                repository.updateCustodian(updatedCurrent)

                // Promote next custodian
                val updatedNext = next.copy(
                    isCurrent = true,
                    password = generatedPassword
                )
                repository.updateCustodian(updatedNext)

                // Generate dispatch receipt summary
                val dateFormat = SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.getDefault())
                val nowStr = dateFormat.format(Date())

                val receipt = if (_isUrdu.value) {
                    """
                    سرکاری ڈسپیچ رسید
                    -----------------------------
                    تاریخ منتقلی: $nowStr
                    منجانب (سابقہ امانت دار): ${current.name}
                    الیٰ (نیا امانت دار): ${next.name}
                    منتقل شدہ رقم: ${String.format(Locale.US, "%,.2f", currentBalance)} ریال (QAR)
                    حیثیت: امانت (مقدس تحویل) کامیابی سے منتقل ہو گئی۔
                    
                    انتباہ: سابقہ نگران کا پاس ورڈ فوری طور پر منسوخ کر دیا گیا ہے۔ نئے نگران کا اکاؤنٹ فعال کر دیا گیا ہے۔
                    """.trimIndent()
                } else {
                    """
                    OFFICIAL DISPATCH RECEIPT
                    ---------------------------------
                    Timestamp: $nowStr
                    Outbound Custodian (Amanat Holder): ${current.name}
                    Inbound Custodian (New Trustee): ${next.name}
                    Transferred Balance: ${String.format(Locale.US, "%,.2f", currentBalance)} QAR
                    Status: Sacred Custody Transferred successfully as per AMANAT Pillar 2.
                    
                    Notice: Outgoing custodian password has been immediately invalidated. Incoming custodian is now the sole active administrator.
                    """.trimIndent()
                }

                onComplete(receipt, generatedPassword, next.name, next.phone)
            }
        }
    }

    // --- Claims Audit ---
    fun addClaim(claim: Claim) {
        viewModelScope.launch {
            repository.insertClaim(claim)
        }
    }

    fun deleteClaim(claim: Claim) {
        viewModelScope.launch {
            repository.deleteClaim(claim)
        }
    }

    /**
     * Executes an AI-powered constitutional audit ruling on a prospective claim.
     */
    fun auditClaimWithGemini(
        deceasedName: String,
        deceasedQid: String,
        residencyStatus: String,
        scenario: String,
        allocatedCap: Double,
        actualExpenses: Double,
        onComplete: (Claim) -> Unit
    ) {
        viewModelScope.launch {
            _isAuditorLoading.value = true

            // Formulate standard constitution audit prompt
            val prompt = """
                As the Supreme Tanzeem Amanat Taqseem AI Constitutional Auditor, analyze the following community claim:
                - Deceased Name: $deceasedName
                - QID Number: $deceasedQid
                - Residency Status at Death: $residencyStatus
                - Selected Scenario: $scenario
                - Benefit Cap Allocation: $allocatedCap QAR
                - Actual Expenses Incurred: $actualExpenses QAR
                
                COMMUNITY CONSTITUTION PILLARS:
                1. TANZEEM: Fixed 2-year annual cycle (200 QAR/year). Strictly non-refundable. Coverage is strictly FORFEITED if the member permanently left Qatar ("Left Qatar for Good").
                2. AMANAT: Physical custody with rotation. 
                3. TAQSEEM: Actual funeral expenses are paid first against allocated benefit caps. 
                   - Local Burial Cap: 10,000 QAR
                   - Repatriation Cap: 15,000 QAR
                   - Vacation Death Cap: 5,000 QAR
                   - Left Qatar permanently Cap: 0 QAR
                   Any SURPLUS (Allocated Cap - Actual Expenses) must be handed over to the deceased's immediate family.
                   Any DEFICIT (Actual Expenses - Allocated Cap) must be recovered/recouped from the next year's collective pool.
                
                Please evaluate and output an official audit ruling. If Residency Status is "Left Qatar for Good", reject coverage. If status is "Active Qatar" or "On Vacation", approve and calculate:
                1. Approved Benefit Paid: (The lesser of Cap and Actual Expenses)
                2. Surplus Handover to Deceased's Family: (If Actual Expenses < Cap, then Cap - Actual Expenses. Else 0)
                3. Deficit Recoupment Schedule from Next Year's Pool: (If Actual Expenses > Cap, then Actual Expenses - Cap. Else 0)
                
                Output the response clearly under these headers:
                - AUDIT STATUS: (APPROVED or REJECTED)
                - CONSTITUTIONAL RATIONALE: (Explain why based on the 3 pillars)
                - FINANCIAL DISTRIBUTION BREAKDOWN:
                  * Allocated Cap: X QAR
                  * Actual Expenses Paid First: Y QAR
                  * Surplus Handover to Family: Z QAR
                  * Deficit Recoupment from Next Year's Pool: W QAR
            """.trimIndent()

            val systemInstruction = "You are the strict, official Tanzeem Amanat Taqseem Community Support Fund Auditor. Be highly formal, respectful, and authoritative. Reference the three pillars in every audit ruling."

            val rulingText = GeminiClient.generateGeminiResponse(prompt, systemInstruction)

            // Calculate values programmatically to ensure precision in the Room entity
            val isEligible = residencyStatus != "Left Qatar for Good"
            val surplus = if (isEligible && actualExpenses < allocatedCap) {
                allocatedCap - actualExpenses
            } else {
                0.0
            }
            val deficit = if (isEligible && actualExpenses > allocatedCap) {
                actualExpenses - allocatedCap
            } else {
                0.0
            }

            val auditedClaim = Claim(
                deceasedName = deceasedName,
                deceasedQid = deceasedQid,
                residencyStatus = residencyStatus,
                scenario = scenario,
                allocatedCap = allocatedCap,
                actualExpenses = actualExpenses,
                auditRuling = rulingText,
                surplusHandover = surplus,
                deficitRecoupment = deficit
            )

            _isAuditorLoading.value = false
            onComplete(auditedClaim)
        }
    }

    // --- AI Advisor Chat ---
    fun sendChatMessage(text: String) {
        if (text.trim().isEmpty()) return

        val userMessage = ChatMessage(text = text, isUser = true)
        _chatHistory.value = _chatHistory.value + userMessage

        viewModelScope.launch {
            _isAdvisorLoading.value = true

            // Gather context
            val balance = poolBalance.value
            val mList = members.value
            val activeCount = mList.count { it.status != "Left Qatar for Good" }
            val currentCust = custodians.value.firstOrNull { it.isCurrent }?.name ?: "None"

            val systemInstruction = """
                You are the official Tanzeem Amanat Taqseem Community Support Fund AI Advisor, designed for overseas Pakistani members residing in Qatar.
                Answer questions instantly, strictly adhering to the Constitution:
                
                1. TANZEEM (Organization & Ledger):
                   - Fixed 2-year annual contribution cycle of 200 QAR per year.
                   - Contributions are strictly non-refundable under all circumstances.
                   - If a member permanently leaves Qatar ("Left Qatar for Good"), all coverage is forfeited.
                
                2. AMANAT (Sacred Trust & Custody):
                   - The physical cash pool is held directly by trusted community custodians on strict 3-month rotations.
                   - There is no bank account used. It is a cash pool.
                   - This rotation guarantees transparent and decentralized communal trust.
                
                3. TAQSEEM (Distribution & Claims):
                   - Funeral expenses are paid first against allocated benefit caps:
                     * Scenario A: Death in Qatar (Burial in Qatar) -> Cap: 10,000 QAR
                     * Scenario B: Death in Qatar (Repatriation to Pakistan) -> Cap: 15,000 QAR
                     * Scenario C: Death in Pakistan (Temporary Vacation) -> Cap: 5,000 QAR
                     * Scenario D: Left Qatar Permanently -> Cap: 0 QAR (Forfeited)
                   - Any surplus (Allocated Cap - Actual Expenses) is paid immediately to the deceased's family.
                   - Any deficit (Actual Expenses - Allocated Cap) is recovered/recouped from the next year's collective pool.
                
                LIVE FUND CONTEXT:
                - Current Live Pool Balance: $balance QAR
                - Total Registered Members: ${mList.size}
                - Active Members (covered): $activeCount
                - Active Cash Custodian (Amanat Holder): $currentCust
                
                Answer in the language of the user's inquiry (English or Urdu) in a dignified, warm, and highly helpful manner.
            """.trimIndent()

            val answer = GeminiClient.generateGeminiResponse(text, systemInstruction)
            val responseMessage = ChatMessage(text = answer, isUser = false)
            _chatHistory.value = _chatHistory.value + responseMessage

            _isAdvisorLoading.value = false
        }
    }
}
