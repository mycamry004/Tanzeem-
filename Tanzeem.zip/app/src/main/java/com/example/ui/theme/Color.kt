package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Elegant Dark Palette with Islamic-inspired Accents
val EmeraldPrimary = Color(0xFF046307)
val EmeraldDark = Color(0xFF023C04)
val EmeraldLight = Color(0xFF10B981) // emerald-500

val GoldAccent = Color(0xFFF59E0B) // amber-500 for striking contrast and accents
val AmberAccent = Color(0xFFFFBF00)

val DarkSlateBackground = Color(0xFF0F172A) // slate-900: elegant deep blue-slate
val DarkSlateSurface = Color(0xFF1E293B) // slate-800: beautiful containers
val DarkSlateSurfaceVariant = Color(0xFF334155) // slate-700: inputs & secondary highlights

val TextOffWhite = Color(0xFFF1F5F9) // slate-100
val TextMuted = Color(0xFF94A3B8) // slate-400

val RedForfeited = Color(0xFFEF4444) // red-500
val GreenActive = Color(0xFF10B981) // emerald-500
val BlueVacation = Color(0xFF3B82F6) // blue-500
