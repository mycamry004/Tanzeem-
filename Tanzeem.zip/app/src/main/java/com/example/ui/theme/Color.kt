package com.example.ui.theme

import androidx.compose.ui.graphics.Color
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.Composable
import androidx.compose.material3.MaterialTheme

// Global Theme State: defaults to dark theme
var isSystemInDarkTheme by mutableStateOf(true)

// Elegant Dynamic Palette with Islamic-inspired Accents
val EmeraldPrimary: Color
    @Composable
    get() = MaterialTheme.colorScheme.primary

val EmeraldDark: Color
    @Composable
    get() = MaterialTheme.colorScheme.primaryContainer

val EmeraldLight: Color
    @Composable
    get() = if (isSystemInDarkTheme) Color(0xFF10B981) else Color(0xFF059669)

val GoldAccent: Color
    @Composable
    get() = MaterialTheme.colorScheme.secondary

val AmberAccent: Color
    @Composable
    get() = MaterialTheme.colorScheme.tertiary

val DarkSlateBackground: Color
    @Composable
    get() = MaterialTheme.colorScheme.background

val DarkSlateSurface: Color
    @Composable
    get() = MaterialTheme.colorScheme.surface

val DarkSlateSurfaceVariant: Color
    @Composable
    get() = MaterialTheme.colorScheme.surfaceVariant

val TextOffWhite: Color
    @Composable
    get() = MaterialTheme.colorScheme.onSurface

val TextMuted: Color
    @Composable
    get() = MaterialTheme.colorScheme.onSurfaceVariant

val RedForfeited = Color(0xFFEF4444) // red-500
val GreenActive = Color(0xFF10B981) // emerald-500
val BlueVacation = Color(0xFF3B82F6) // blue-500

