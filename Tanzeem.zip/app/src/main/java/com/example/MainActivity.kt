package com.example
import kotlinx.coroutines.launch

import android.app.Application
import android.content.Intent
import android.speech.RecognizerIntent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.Claim
import com.example.data.Custodian
import com.example.data.Member
import com.example.ui.ChatMessage
import com.example.ui.TatViewModel
import com.example.ui.Translations
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

import com.google.firebase.FirebaseApp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        FirebaseApp.initializeApp(this)
        enableEdgeToEdge()
                setContent {
            MyApplicationTheme {
                val currentDensity = androidx.compose.ui.platform.LocalDensity.current
                val customDensity = androidx.compose.ui.unit.Density(
                    density = currentDensity.density,
                    fontScale = currentDensity.fontScale * 0.8f
                )
                androidx.compose.runtime.CompositionLocalProvider(
                    androidx.compose.ui.platform.LocalDensity provides customDensity
                ) {
                    var isAuthenticated by remember { mutableStateOf(false) }
                    
                    if (isAuthenticated) {
                        val viewModel: TatViewModel = viewModel()
                        MainContent(viewModel)
                    } else {
                        PasswordScreen(onAuthenticated = { isAuthenticated = true })
                    }
                }
            }
        }
    }
}


@Composable
fun PasswordScreen(onAuthenticated: () -> Unit) {
    var password by remember { mutableStateOf("") }
    var isError by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkSlateBackground)
    ) {
                val emerald = EmeraldPrimary
        val gold = GoldAccent

        // Abstract Background Elements
        androidx.compose.foundation.Canvas(modifier = Modifier.fillMaxSize()) {
            val canvasWidth = size.width
            val canvasHeight = size.height

            // Top abstract shape
            val path1 = androidx.compose.ui.graphics.Path().apply {
                moveTo(canvasWidth, 0f)
                lineTo(canvasWidth - 300f, 0f)
                quadraticBezierTo(canvasWidth - 100f, 150f, canvasWidth, 300f)
                close()
            }
            drawPath(path1, emerald.copy(alpha = 0.2f))
            
            val path2 = androidx.compose.ui.graphics.Path().apply {
                moveTo(canvasWidth, 0f)
                lineTo(canvasWidth - 150f, 0f)
                quadraticBezierTo(canvasWidth - 50f, 80f, canvasWidth, 150f)
                close()
            }
            drawPath(path2, gold.copy(alpha = 0.3f))

            // Bottom abstract shape
            val path3 = androidx.compose.ui.graphics.Path().apply {
                moveTo(0f, canvasHeight)
                lineTo(300f, canvasHeight)
                quadraticBezierTo(100f, canvasHeight - 150f, 0f, canvasHeight - 300f)
                close()
            }
            drawPath(path3, emerald.copy(alpha = 0.15f))
            
            val path4 = androidx.compose.ui.graphics.Path().apply {
                moveTo(0f, canvasHeight)
                lineTo(150f, canvasHeight)
                quadraticBezierTo(50f, canvasHeight - 80f, 0f, canvasHeight - 150f)
                close()
            }
            drawPath(path4, gold.copy(alpha = 0.25f))
        }

        // Main Content
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // Logo
            Surface(
                shape = CircleShape,
                color = DarkSlateSurface,
                border = BorderStroke(2.dp, GoldAccent.copy(alpha = 0.5f)),
                shadowElevation = 8.dp,
                modifier = Modifier.size(120.dp)
            ) {
                Image(
                    painter = painterResource(id = R.drawable.tat_emblem),
                    contentDescription = "Logo",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize().clip(CircleShape)
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            Text(
                text = "Tanzeem Amanat Taqseem",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                color = EmeraldPrimary,
                textAlign = TextAlign.Center
            )
            Text(
                text = "تنظیم امانت تقسیم",
                fontSize = 20.sp,
                color = TextMuted,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(48.dp))

            OutlinedTextField(
                value = password,
                onValueChange = { 
                    password = it
                    isError = false
                },
                label = { Text("Enter Password", color = TextMuted) },
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                singleLine = true,
                isError = isError,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = EmeraldPrimary,
                    unfocusedBorderColor = TextMuted.copy(alpha = 0.5f),
                    focusedTextColor = TextOffWhite,
                    unfocusedTextColor = TextOffWhite,
                    errorBorderColor = RedForfeited,
                    errorTextColor = RedForfeited
                ),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth(),
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = "Lock",
                        tint = if (isError) RedForfeited else EmeraldPrimary
                    )
                }
            )

            if (isError) {
                Text(
                    text = "Incorrect password. Please try again.",
                    color = RedForfeited,
                    fontSize = 12.sp,
                    modifier = Modifier
                        .align(Alignment.Start)
                        .padding(start = 16.dp, top = 4.dp)
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            Button(
                onClick = { 
                    if (password == "TAT@2026") {
                        onAuthenticated()
                    } else {
                        isError = true
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
            ) {
                Text(
                    text = "Unlock",
                    color = Color.White,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
fun MainContent(viewModel: TatViewModel) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var updateInfo by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf<com.example.updater.AutoUpdater.UpdateInfo?>(null) }
    
    androidx.compose.runtime.LaunchedEffect(Unit) {
        val info = com.example.updater.AutoUpdater.checkForUpdates()
        if (info?.isUpdateAvailable == true) {
            updateInfo = info
        }
    }

    updateInfo?.let { info ->
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { updateInfo = null },
            title = { androidx.compose.material3.Text("Update Available", fontWeight = androidx.compose.ui.text.font.FontWeight.Bold) },
            text = { 
                androidx.compose.foundation.layout.Column {
                    androidx.compose.material3.Text("Version ${info.latestVersionName} is available.")
                    androidx.compose.foundation.layout.Spacer(modifier = androidx.compose.ui.Modifier.height(8.dp))
                    androidx.compose.material3.Text(info.releaseNotes, fontSize = 14.sp)
                }
            },
            confirmButton = {
                androidx.compose.material3.Button(
                    onClick = {
                        com.example.updater.AutoUpdater.downloadAndInstallUpdate(context, info.downloadUrl, info.latestVersionName)
                        updateInfo = null
                        android.widget.Toast.makeText(context, "Downloading update...", android.widget.Toast.LENGTH_SHORT).show()
                    },
                    colors = androidx.compose.material3.ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
                ) {
                    androidx.compose.material3.Text("Update Now")
                }
            },
            dismissButton = {
                androidx.compose.material3.TextButton(onClick = { updateInfo = null }) {
                    androidx.compose.material3.Text("Later", color = TextMuted)
                }
            },
            containerColor = DarkSlateSurface,
            titleContentColor = TextOffWhite,
            textContentColor = TextOffWhite
        )
    }

    val isUrdu by viewModel.isUrdu.collectAsStateWithLifecycle()
    val isAdminMode by viewModel.isAdminMode.collectAsStateWithLifecycle()
    val isSuperAdmin by viewModel.isSuperAdmin.collectAsStateWithLifecycle()
    val members by viewModel.members.collectAsStateWithLifecycle()
    val custodians by viewModel.custodians.collectAsStateWithLifecycle()
    val claims by viewModel.claims.collectAsStateWithLifecycle()
    val poolBalance by viewModel.poolBalance.collectAsStateWithLifecycle()

    var showWelcomeScreen by remember { mutableStateOf(true) }
    var showLanguageDialog by remember { mutableStateOf(false) }
    var showLoginDialog by remember { mutableStateOf(false) }
    var enteredPassword by remember { mutableStateOf("") }
    var loginError by remember { mutableStateOf<String?>(null) }

    var isNewCustodianFlow by remember { mutableStateOf(false) }
    var tempPasswordInput by remember { mutableStateOf("") }
    var activationError by remember { mutableStateOf<String?>(null) }
    var activatedPasswordShow by remember { mutableStateOf("") }

    // Navigation states
    var selectedTab by remember { mutableStateOf(0) } // 0: Members, 1: Custodians, 2: Claims, 3: AI Advisor

    // Handover receipt dialog states
    var showReceiptDialog by remember { mutableStateOf(false) }
    var receiptText by remember { mutableStateOf("") }
    var generatedPassword by remember { mutableStateOf("") }
    var nextCustodianName by remember { mutableStateOf("") }
    var nextCustodianPhone by remember { mutableStateOf("") }


    val uriHandler = androidx.compose.ui.platform.LocalUriHandler.current

    // Initialize Text-To-Speech with DisposableEffect for lifecycle safety
    var tts by remember { mutableStateOf<android.speech.tts.TextToSpeech?>(null) }
    var isTtsReady by remember { mutableStateOf(false) }

    DisposableEffect(context) {
        val ttsInstance = android.speech.tts.TextToSpeech(context) { status ->
            if (status == android.speech.tts.TextToSpeech.SUCCESS) {
                isTtsReady = true
            }
        }
        tts = ttsInstance
        onDispose {
            ttsInstance.stop()
            ttsInstance.shutdown()
        }
    }

    val speakText: (String, Boolean) -> Unit = { text, isUrduText ->
        val ttsInstance = tts
        if (ttsInstance != null && isTtsReady) {
            ttsInstance.stop()
            // Clean the text to avoid reading out punctuation and symbols
            val cleanText = text.replace(Regex("""[*()/\[\]{}<>_~]"""), " ")
            val hasPashto = cleanText.any { it in listOf('ښ', 'ځ', 'څ', 'ډ', 'ړ', 'ږ', 'ټ', 'ګ', 'ڼ', 'ې', 'ۍ') }
            val hasUrdu = cleanText.any { it.code in 0x0600..0x06FF } && !hasPashto
            
            // Try to set locale appropriately. For Pashto/Urdu, Android TTS usually relies on 'ur' or 'ps' if available.
            val locale = when {
                hasPashto -> java.util.Locale("ps")
                hasUrdu || isUrduText -> java.util.Locale("ur", "PK")
                else -> java.util.Locale.US
            }
            ttsInstance.language = locale
            // Use normal pitch and speech rate to avoid sounding like a distorted machine
            ttsInstance.setPitch(1.0f)
            ttsInstance.setSpeechRate(1.0f)
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
                ttsInstance.speak(cleanText, android.speech.tts.TextToSpeech.QUEUE_FLUSH, null, "UtteranceId")
            } else {
                @Suppress("DEPRECATION")
                ttsInstance.speak(cleanText, android.speech.tts.TextToSpeech.QUEUE_FLUSH, null)
            }
        }
    }

    val stopSpeaking: () -> Unit = {
        tts?.stop()
    }

    val lifecycleOwner = androidx.lifecycle.compose.LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = androidx.lifecycle.LifecycleEventObserver { _, event ->
            if (event == androidx.lifecycle.Lifecycle.Event.ON_PAUSE || event == androidx.lifecycle.Lifecycle.Event.ON_STOP) {
                stopSpeaking()
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    // Dynamic Back Handler: goes to Welcome Screen from any inside screen, exits app from Welcome Screen
    androidx.activity.compose.BackHandler(enabled = !showWelcomeScreen) {
        showWelcomeScreen = true
    }

    if (showWelcomeScreen) {
        // --- WELCOME HERO SCREEN ---
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = if (isSystemInDarkTheme) {
                            listOf(DarkSlateBackground, Color(0xFF071208))
                        } else {
                            listOf(DarkSlateBackground, Color(0xFFE8F5E9))
                        }
                    )
                )
                .safeDrawingPadding()
                .padding(24.dp)
        ) {
            // Language and Theme selectors top-right
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.End),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Theme Toggle
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(Color.Black.copy(alpha = 0.2f))
                        .border(BorderStroke(1.dp, GoldAccent.copy(alpha = 0.8f)), CircleShape)
                        .clickable { viewModel.toggleTheme() }
                        .testTag("welcome_theme_toggle"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (isSystemInDarkTheme) Icons.Default.WbSunny else Icons.Default.NightsStay,
                        contentDescription = "Theme Toggle",
                        tint = GoldAccent,
                        modifier = Modifier.size(20.dp)
                    )
                }

                // Language Selector
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(Color.Black.copy(alpha = 0.2f))
                        .border(BorderStroke(1.dp, GoldAccent.copy(alpha = 0.8f)), CircleShape)
                        .clickable { showLanguageDialog = true }
                        .testTag("welcome_language_toggle"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Language,
                        contentDescription = "Language Selector",
                        tint = GoldAccent,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            // Core emblem and text content
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.Center),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                // Centered Official Emblem Logo with Golden Mask
                Box(
                    modifier = Modifier
                        .size(160.dp)
                        .clip(CircleShape)
                        .background(DarkSlateSurface)
                        .border(3.dp, GoldAccent, CircleShape)
                        .padding(4.dp)
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.tat_emblem),
                        contentDescription = "Official Emblem",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .fillMaxSize()
                            .clip(CircleShape)
                    )
                }

                Spacer(modifier = Modifier.height(24.dp))

                // Title in English and Urdu
                Text(
                    text = "Tanzeem - Amanat - Taqseem",
                    color = GoldAccent,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.ExtraBold,
                    textAlign = TextAlign.Center,
                    letterSpacing = 0.5.sp
                )
                Text(
                    text = "تنظیم - امانت - تقسیم",
                    color = TextOffWhite,
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(top = 4.dp)
                )

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = Translations.getString("subtitle", isUrdu),
                    color = TextMuted,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(horizontal = 16.dp)
                )

                Spacer(modifier = Modifier.height(36.dp))

                // Pathway A: Tanzeem Member (Read-Only)
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            viewModel.setAdminMode(false)
                            viewModel.setSuperAdminMode(false)
                            showWelcomeScreen = false
                        }
                        .testTag("member_access_card"),
                    colors = CardDefaults.cardColors(containerColor = EmeraldPrimary),
                    shape = RoundedCornerShape(16.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .padding(20.dp)
                            .fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .background(Color(0x33FFFFFF), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Person,
                                contentDescription = "Member Access",
                                tint = Color.White,
                                modifier = Modifier.size(28.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(16.dp))
                        Column {
                            Text(
                                text = Translations.getString("memberAccess", isUrdu),
                                color = Color.White,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = Translations.getString("memberDesc", isUrdu),
                                color = Color.White.copy(alpha = 0.85f),
                                fontSize = 12.sp
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Pathway B: Tanzeem Custodian (Admin Password)
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            showLoginDialog = true
                        }
                        .testTag("custodian_access_card"),
                    colors = CardDefaults.cardColors(containerColor = DarkSlateSurface),
                    border = BorderStroke(1.dp, GoldAccent.copy(alpha = 0.5f)),
                    shape = RoundedCornerShape(16.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .padding(20.dp)
                            .fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .background(GoldAccent.copy(alpha = 0.15f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Lock,
                                contentDescription = "Custodian Access",
                                tint = GoldAccent,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(16.dp))
                        Column {
                            Text(
                                text = Translations.getString("custodianAccess", isUrdu),
                                color = GoldAccent,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = Translations.getString("custodianDesc", isUrdu),
                                color = TextMuted,
                                fontSize = 12.sp
                            )
                        }
                    }
                }
            }

            // Trust disclaimer at bottom
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.BottomCenter)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Star,
                        contentDescription = "Pillar Icon",
                        tint = GoldAccent,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = Translations.getString("allContributionsForfeited", isUrdu),
                        color = TextMuted,
                        fontSize = 11.sp,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
    } else {
        // --- MAIN APP PORTAL SCREEN ---
        Scaffold(
            topBar = {
                Surface(
                    color = EmeraldPrimary,
                    border = BorderStroke(1.dp, Color(0xFF057A09)),
                    shadowElevation = 8.dp
                ) {
                    Column(
                        modifier = Modifier
                            .statusBarsPadding()
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            // Back home button
                            IconButton(
                                onClick = { showWelcomeScreen = true },
                                modifier = Modifier.testTag("back_to_welcome_button")
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                    contentDescription = "Welcome screen",
                                    tint = Color.White
                                )
                            }

                            // Title in middle
                            Column(
                                modifier = Modifier.weight(1f),
                                horizontalAlignment = Alignment.Start
                            ) {
                                val badgeColor = if (isAdminMode) Color(0xFF057A09) else Color(0x33FFFFFF)
                                val badgeBorderColor = if (isAdminMode) GoldAccent else Color.White.copy(alpha = 0.2f)
                                val badgeText = if (isAdminMode) {
                                    Translations.getString("adminModeActive", isUrdu)
                                } else {
                                    Translations.getString("readOnlyModeActive", isUrdu)
                                }

                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(badgeColor)
                                        .border(1.dp, badgeBorderColor, RoundedCornerShape(4.dp))
                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Text(
                                        text = badgeText,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White
                                    )
                                }
                            }

                            // Top Bar Actions
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                // WhatsApp Group Quick Action Icon Button
                                Box(
                                    modifier = Modifier
                                        .size(32.dp)
                                        .clip(CircleShape)
                                        .background(Color(0xFF25D366))
                                        .clickable {
                                            uriHandler.openUri("https://chat.whatsapp.com/Dj1WTCHJ4A1JpEU5cgUNNV?s=cl&p=a&ilr=4")
                                        }
                                        .testTag("top_bar_whatsapp_button"),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "W",
                                        color = Color.White,
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Black,
                                        fontFamily = androidx.compose.ui.text.font.FontFamily.SansSerif
                                    )
                                }

                                // Apple iOS PWA Sync Info Dialog Icon Button
                                var showApplePwaDialog by remember { mutableStateOf(false) }
                                Box(
                                    modifier = Modifier
                                        .size(32.dp)
                                        .clip(CircleShape)
                                        .background(Color.White.copy(alpha = 0.15f))
                                        .border(BorderStroke(1.dp, Color.White.copy(alpha = 0.3f)), CircleShape)
                                        .clickable {
                                            showApplePwaDialog = true
                                        }
                                        .testTag("top_bar_apple_button"),
                                    contentAlignment = Alignment.Center
                                ) {
                                    AppleLogoIcon(
                                        modifier = Modifier.size(16.dp),
                                        tint = Color.White
                                    )
                                }

                                if (showApplePwaDialog) {
                                    Dialog(onDismissRequest = { showApplePwaDialog = false }) {
                                        Card(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(16.dp)
                                                .testTag("apple_pwa_dialog_card"),
                                            colors = CardDefaults.cardColors(containerColor = DarkSlateSurface),
                                            border = BorderStroke(1.dp, GoldAccent.copy(alpha = 0.4f)),
                                            shape = RoundedCornerShape(16.dp)
                                        ) {
                                            Column(
                                                modifier = Modifier.padding(16.dp)
                                            ) {
                                                Row(
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                                                ) {
                                                    Box(
                                                        modifier = Modifier
                                                            .size(40.dp)
                                                            .background(TextOffWhite.copy(alpha = 0.15f), CircleShape),
                                                        contentAlignment = Alignment.Center
                                                    ) {
                                                        AppleLogoIcon(
                                                            modifier = Modifier.size(20.dp),
                                                            tint = TextOffWhite
                                                        )
                                                    }
                                                    Column(modifier = Modifier.weight(1f)) {
                                                        Text(
                                                            text = if (isUrdu) "ایپل (iOS) ویب ایپ اور پی ڈبلیو اے" else "Apple (iOS) Web App & PWA",
                                                            color = TextOffWhite,
                                                            fontSize = 15.sp,
                                                            fontWeight = FontWeight.Bold
                                                        )
                                                        Text(
                                                            text = if (isUrdu) "آئی فون صارفین کے لیے مطابقت اور مطابقت پذیری" else "Compatibility & real-time sync for iPhones.",
                                                            color = TextMuted,
                                                            fontSize = 11.sp
                                                        )
                                                    }
                                                }

                                                com.example.ui.ApplePwaTutorial(
                                                    isUrdu = isUrdu,
                                                    primaryColor = GoldAccent,
                                                    surfaceColor = DarkSlateSurfaceVariant,
                                                    textColor = TextOffWhite,
                                                    mutedColor = TextMuted
                                                )
                                                Spacer(modifier = Modifier.height(16.dp))
                                                Row(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                                ) {
                                                    // Copy Link Button
                                                    Button(
                                                        onClick = {
                                                            val clipboardManager = context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                                                            val clipData = android.content.ClipData.newPlainText("Web App Link", "https://untitled-397049479956.us-west1.run.app")
                                                            clipboardManager.setPrimaryClip(clipData)
                                                            android.widget.Toast.makeText(context, if (isUrdu) "لنک کاپی کر دیا گیا ہے!" else "Link copied to clipboard!", android.widget.Toast.LENGTH_SHORT).show()
                                                        },
                                                        colors = ButtonDefaults.buttonColors(containerColor = GoldAccent),
                                                        modifier = Modifier
                                                            .weight(1f)
                                                            .height(38.dp)
                                                            .testTag("apple_pwa_dialog_copy_button"),
                                                        shape = RoundedCornerShape(8.dp)
                                                    ) {
                                                        Row(
                                                            verticalAlignment = Alignment.CenterVertically,
                                                            horizontalArrangement = Arrangement.Center
                                                        ) {
                                                            Icon(
                                                                imageVector = Icons.Default.ContentCopy,
                                                                contentDescription = "Copy Link Icon",
                                                                tint = Color(0xFF0F172A),
                                                                modifier = Modifier.size(16.dp)
                                                            )
                                                            Spacer(modifier = Modifier.width(6.dp))
                                                            Text(
                                                                text = if (isUrdu) "لنک کاپی کریں" else "Copy Link",
                                                                color = Color(0xFF0F172A),
                                                                fontSize = 11.sp,
                                                                fontWeight = FontWeight.Bold
                                                            )
                                                        }
                                                    }

                                                    // Share Link Button
                                                    OutlinedButton(
                                                        onClick = {
                                                            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                                                type = "text/plain"
                                                                putExtra(Intent.EXTRA_SUBJECT, "Taqseem Amanat Tanzeem Web App")
                                                                putExtra(Intent.EXTRA_TEXT, "Open the Taqseem Amanat Tanzeem Web App on Apple (iOS) / Safari and 'Add to Home Screen' to sync with Android:\nhttps://untitled-397049479956.us-west1.run.app")
                                                            }
                                                            context.startActivity(Intent.createChooser(shareIntent, "Share Web App Link"))
                                                        },
                                                        border = BorderStroke(1.dp, GoldAccent),
                                                        colors = ButtonDefaults.outlinedButtonColors(contentColor = GoldAccent),
                                                        modifier = Modifier
                                                            .weight(1f)
                                                            .height(38.dp)
                                                            .testTag("apple_pwa_dialog_share_button"),
                                                        shape = RoundedCornerShape(8.dp)
                                                    ) {
                                                        Row(
                                                            verticalAlignment = Alignment.CenterVertically,
                                                            horizontalArrangement = Arrangement.Center
                                                        ) {
                                                            Icon(
                                                                imageVector = Icons.Default.Share,
                                                                contentDescription = "Share Web Icon",
                                                                tint = GoldAccent,
                                                                modifier = Modifier.size(16.dp)
                                                            )
                                                            Spacer(modifier = Modifier.width(6.dp))
                                                            Text(
                                                                text = if (isUrdu) "شیئر کریں" else "Share Link",
                                                                color = GoldAccent,
                                                                fontSize = 11.sp,
                                                                fontWeight = FontWeight.Bold
                                                            )
                                                        }
                                                    }
                                                }

                                                Spacer(modifier = Modifier.height(16.dp))
                                                TextButton(
                                                    onClick = { showApplePwaDialog = false },
                                                    modifier = Modifier.fillMaxWidth()
                                                ) {
                                                    Text(if (isUrdu) "بند کریں" else "Close", color = TextMuted)
                                                }
                                            }
                                        }
                                    }
                                }




                                // Theme Toggle Button
                                Box(
                                    modifier = Modifier
                                        .size(32.dp)
                                        .clip(CircleShape)
                                        .background(Color.Black.copy(alpha = 0.2f))
                                        .border(BorderStroke(1.dp, Color.White.copy(alpha = 0.25f)), CircleShape)
                                        .clickable { viewModel.toggleTheme() }
                                        .testTag("app_theme_toggle_button"),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = if (isSystemInDarkTheme) Icons.Default.WbSunny else Icons.Default.NightsStay,
                                        contentDescription = "Toggle Theme",
                                        tint = Color.White,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }

                                // Language Selector Globe Button
                                Box(
                                    modifier = Modifier
                                        .size(32.dp)
                                        .clip(CircleShape)
                                        .background(Color.Black.copy(alpha = 0.2f))
                                        .border(BorderStroke(1.dp, Color.White.copy(alpha = 0.25f)), CircleShape)
                                        .clickable { showLanguageDialog = true }
                                        .testTag("app_language_globe_button"),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Language,
                                        contentDescription = "Select Language",
                                        tint = Color.White,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            },
            bottomBar = {
                NavigationBar(
                    containerColor = DarkSlateSurface,
                    tonalElevation = 8.dp
                ) {
                    val tabs = listOf(
                        Translations.getString("dashboardTab", isUrdu) to Icons.Default.Dashboard,
                        Translations.getString("membersTab", isUrdu) to Icons.Default.Person,
                        Translations.getString("custodiansTab", isUrdu) to Icons.Default.Lock,
                        Translations.getString("claimsTab", isUrdu) to Icons.Default.Info,
                        Translations.getString("advisorTab", isUrdu) to Icons.Default.Star
                    )

                    tabs.forEachIndexed { index, (label, icon) ->
                        NavigationBarItem(
                            selected = selectedTab == index,
                            onClick = { selectedTab = index },
                            icon = {
                                Icon(
                                    imageVector = icon,
                                    contentDescription = label,
                                    tint = if (selectedTab == index) EmeraldLight else TextMuted
                                )
                            },
                            label = {
                                Text(
                                    text = label,
                                    fontSize = 9.sp,
                                    fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Medium,
                                    color = if (selectedTab == index) EmeraldLight else TextMuted,
                                    maxLines = 1,
                                    overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                                    softWrap = false
                                )
                            },
                            colors = NavigationBarItemDefaults.colors(
                                indicatorColor = EmeraldLight.copy(alpha = 0.15f)
                            ),
                            modifier = Modifier.testTag("nav_tab_$index")
                        )
                    }
                }
            },
            containerColor = DarkSlateBackground
        ) { paddingValues ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
            ) {
                when (selectedTab) {
                    0 -> DashboardTabScreen(
                        viewModel = viewModel,
                        members = members,
                        claims = claims,
                        poolBalance = poolBalance,
                        isUrdu = isUrdu,
                        isAdminMode = isAdminMode,
                        isSuperAdmin = isSuperAdmin
                    )
                    1 -> MembersTabScreen(
                        viewModel = viewModel,
                        members = members,
                        isAdminMode = isAdminMode,
                        isUrdu = isUrdu
                    )
                    2 -> CustodiansTabScreen(
                        viewModel = viewModel,
                        custodians = custodians,
                        members = members,
                        poolBalance = poolBalance,
                        isAdminMode = isAdminMode,
                        isUrdu = isUrdu,
                        onHandoverTriggered = { receipt, newPass, name, phone ->
                            receiptText = receipt
                            generatedPassword = newPass
                            nextCustodianName = name
                            nextCustodianPhone = phone
                            showReceiptDialog = true

                            // Auto send WhatsApp as well
                            try {
                                val cleanPhone = phone.replace(Regex("[^0-9]"), "")
                                val textMsg = if (isUrdu) {
                                    "نگران منتقلی: السلام علیکم $name، اب آپ تنظیم - امانت - تقسیم کے نئے نگران ہیں۔ آپ کا عارضی لاگ ان پاس ورڈ یہ ہے: $newPass\nبراہ کرم ایپ کھولیں، نگران لاگ ان بٹن پر کلک کریں، اور اپنا مستقل پاس ورڈ بنانے کے لیے عارضی پاس ورڈ درج کریں۔"
                                } else {
                                    "Custodian Handover: Hello $name, you are the incoming Custodian for Tanzeem - Amanat - Taqseem. Your temporary activation password is: $newPass\nPlease open the app, click Custodian Access, and enter this temporary password to activate your account and generate your secure admin password."
                                }
                                val url = "https://wa.me/$cleanPhone?text=${java.net.URLEncoder.encode(textMsg, "UTF-8")}"
                                uriHandler.openUri(url)
                            } catch (e: Exception) {
                                e.printStackTrace()
                            }
                        }
                    )
                    3 -> ClaimsTabScreen(
                        viewModel = viewModel,
                        claims = claims,
                        members = members,
                        isAdminMode = isAdminMode,
                        isUrdu = isUrdu
                    )
                    4 -> {
                        DisposableEffect(Unit) {
                            onDispose { stopSpeaking() }
                        }
                        AIAdvisorTabScreen(
                            viewModel = viewModel,
                            isUrdu = isUrdu,
                            speakText = speakText,
                            stopSpeaking = stopSpeaking
                        )
                    }
                }
            }
        }
    }

    if (showLanguageDialog) {
        LanguagePickerDialog(
            isUrdu = isUrdu,
            onDismiss = { showLanguageDialog = false },
            onLanguageSelected = { selectedUrdu ->
                viewModel.setLanguage(selectedUrdu)
            }
        )
    }

    // --- CUSTODIAN LOGIN DIALOG ---
    if (showLoginDialog) {
        val currentCustodian = custodians.firstOrNull { it.isCurrent }
        val activeCustodianName = currentCustodian?.name ?: "Imran Khan"
        val activePassHint = currentCustodian?.password ?: "tat123"

        Dialog(onDismissRequest = { 
            showLoginDialog = false 
            isNewCustodianFlow = false
            tempPasswordInput = ""
            activationError = null
            activatedPasswordShow = ""
        }) {
            Card(
                colors = CardDefaults.cardColors(containerColor = DarkSlateSurface),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, GoldAccent),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
                    .testTag("login_dialog")
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    if (isNewCustodianFlow) {
                        if (activatedPasswordShow.isNotEmpty()) {
                            // Sub-flow: Activation Success, display the generated password
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = "Success",
                                tint = EmeraldPrimary,
                                modifier = Modifier.size(48.dp)
                            )
                            Spacer(modifier = Modifier.height(16.dp))
                            Text(
                                text = if (isUrdu) "فعال سازی کامیاب!" else "Activation Successful!",
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextOffWhite,
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = if (isUrdu) {
                                    "آپ کا نیا منفرد اور محفوظ ایڈمن پاس ورڈ تیار کر دیا گیا ہے۔ براہ کرم اسے محفوظ کر لیں:"
                                } else {
                                    "Your new secure personal admin password has been generated. Please save this password safely:"
                                },
                                fontSize = 13.sp,
                                color = TextOffWhite.copy(alpha = 0.85f),
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(16.dp))

                            Card(
                                colors = CardDefaults.cardColors(containerColor = EmeraldDark),
                                border = BorderStroke(1.dp, GoldAccent),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp)
                            ) {
                                Text(
                                    text = activatedPasswordShow,
                                    fontSize = 24.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = GoldAccent,
                                    textAlign = TextAlign.Center,
                                    letterSpacing = 2.sp,
                                    modifier = Modifier.fillMaxWidth().padding(16.dp)
                                )
                            }

                            Spacer(modifier = Modifier.height(16.dp))

                            val clipboardManager = androidx.compose.ui.platform.LocalClipboardManager.current
                            Column(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Button(
                                    onClick = {
                                        isNewCustodianFlow = false
                                        activatedPasswordShow = ""
                                        tempPasswordInput = ""
                                        activationError = null
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)
                                ) {
                                    Text(if (isUrdu) "لاگ ان پر جائیں" else "Go to Login", color = Color.White)
                                }
                                
                                Spacer(modifier = Modifier.height(8.dp))
                                
                                TextButton(
                                    onClick = {
                                        clipboardManager.setText(androidx.compose.ui.text.AnnotatedString(activatedPasswordShow))
                                        Toast.makeText(context, if (isUrdu) "پاس ورڈ کاپی ہو گیا!" else "Password copied!", Toast.LENGTH_SHORT).show()
                                    }
                                ) {
                                    Icon(imageVector = Icons.Default.Share, contentDescription = "Copy", tint = GoldAccent)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(if (isUrdu) "کاپی کریں" else "Copy Password", color = GoldAccent)
                                }
                            }
                        } else {
                            // Sub-flow: Enter Temporary Password
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = "Activation",
                                tint = GoldAccent,
                                modifier = Modifier.size(40.dp)
                            )
                            Spacer(modifier = Modifier.height(16.dp))
                            Text(
                                text = if (isUrdu) "نیا نگران فعال کریں" else "New Custodian Activation",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextOffWhite,
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = if (isUrdu) {
                                    "اپنا اکاؤنٹ چالو کرنے اور مستقل پاس ورڈ حاصل کرنے کے لیے موصول شدہ عارضی پاس ورڈ درج کریں:"
                                } else {
                                    "Enter the temporary password you received to activate your account and generate a secure password:"
                                },
                                fontSize = 12.sp,
                                color = TextMuted,
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(16.dp))

                            OutlinedTextField(
                                value = tempPasswordInput,
                                onValueChange = {
                                    tempPasswordInput = it
                                    activationError = null
                                },
                                label = { Text(if (isUrdu) "عارضی پاس ورڈ" else "Temporary Password", color = TextMuted) },
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = GoldAccent,
                                    unfocusedBorderColor = TextMuted.copy(alpha = 0.5f),
                                    focusedLabelColor = GoldAccent,
                                    cursorColor = GoldAccent,
                                    focusedTextColor = TextOffWhite,
                                    unfocusedTextColor = TextOffWhite
                                ),
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )

                            if (activationError != null) {
                                Text(
                                    text = activationError!!,
                                    color = MaterialTheme.colorScheme.error,
                                    fontSize = 11.sp,
                                    modifier = Modifier.padding(top = 8.dp).fillMaxWidth(),
                                    textAlign = TextAlign.Start
                                )
                            }

                            Spacer(modifier = Modifier.height(24.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.End
                            ) {
                                TextButton(
                                    onClick = {
                                        isNewCustodianFlow = false
                                        tempPasswordInput = ""
                                        activationError = null
                                    }
                                ) {
                                    Text(if (isUrdu) "واپس" else "Back", color = TextMuted)
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Button(
                                    onClick = {
                                        viewModel.activateNewCustodian(tempPasswordInput) { success, generatedPass, error ->
                                            if (success) {
                                                activatedPasswordShow = generatedPass
                                                tempPasswordInput = ""
                                                activationError = null
                                                Toast.makeText(context, if (isUrdu) "اکاؤنٹ کامیابی سے فعال ہو گیا!" else "Account successfully activated!", Toast.LENGTH_SHORT).show()
                                            } else {
                                                activationError = error
                                            }
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
                                ) {
                                    Text(if (isUrdu) "سرگرم کریں" else "Activate", color = Color.White)
                                }
                            }
                        }
                    } else {
                        // Standard Flow
                        // Top option button for "New Custodian"
                        Button(
                            onClick = {
                                isNewCustodianFlow = true
                                tempPasswordInput = ""
                                activationError = null
                                activatedPasswordShow = ""
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = GoldAccent.copy(alpha = 0.15f)),
                            border = BorderStroke(1.dp, GoldAccent),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(
                                imageVector = Icons.Default.Person,
                                contentDescription = "New Custodian Icon",
                                tint = GoldAccent,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (isUrdu) "نیا نگران (New Custodian)" else "New Custodian",
                                color = GoldAccent,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        }

                        Spacer(modifier = Modifier.height(20.dp))
                        androidx.compose.material3.HorizontalDivider(color = TextMuted.copy(alpha = 0.2f), thickness = 1.dp)
                        Spacer(modifier = Modifier.height(20.dp))

                        Icon(
                            imageVector = Icons.Default.Lock,
                            contentDescription = "Custodian Lock",
                            tint = GoldAccent,
                            modifier = Modifier.size(40.dp)
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = Translations.getString("enterPassword", isUrdu),
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextOffWhite,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Active: $activeCustodianName",
                            fontSize = 12.sp,
                            color = GoldAccent,
                            fontWeight = FontWeight.SemiBold
                        )
                        if (activePassHint.isNotEmpty()) {
                            Text(
                                text = "Demo Hint Password: '$activePassHint'",
                                fontSize = 10.sp,
                                color = TextMuted,
                                modifier = Modifier.padding(top = 2.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(16.dp))

                        OutlinedTextField(
                            value = enteredPassword,
                            onValueChange = {
                                enteredPassword = it
                                loginError = null
                            },
                            label = { Text(Translations.getString("password", isUrdu), color = TextMuted) },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = GoldAccent,
                                unfocusedBorderColor = TextMuted.copy(alpha = 0.5f),
                                focusedLabelColor = GoldAccent,
                                cursorColor = GoldAccent,
                                focusedTextColor = TextOffWhite,
                                unfocusedTextColor = TextOffWhite
                            ),
                            singleLine = true,
                            visualTransformation = PasswordVisualTransformation(),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("password_input_field")
                        )

                        if (loginError != null) {
                            Text(
                                text = loginError!!,
                                color = MaterialTheme.colorScheme.error,
                                fontSize = 11.sp,
                                modifier = Modifier
                                    .padding(top = 8.dp)
                                    .fillMaxWidth(),
                                textAlign = TextAlign.Start
                            )
                        }

                        Spacer(modifier = Modifier.height(24.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End
                        ) {
                            TextButton(
                                onClick = {
                                    showLoginDialog = false
                                    enteredPassword = ""
                                    loginError = null
                                },
                                modifier = Modifier.testTag("login_cancel_button")
                            ) {
                                Text(Translations.getString("cancel", isUrdu), color = TextMuted)
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Button(
                                onClick = {
                                    val isSuper = enteredPassword.isNotBlank() && enteredPassword == "Tanzeem004"
                                    val isCust = enteredPassword.isNotBlank() && custodians.any { it.isCurrent && it.password == enteredPassword }
                                    val match = isSuper || isCust
                                    if (match) {
                                        viewModel.setAdminMode(true)
                                        viewModel.setSuperAdminMode(isSuper)
                                        showLoginDialog = false
                                        showWelcomeScreen = false
                                        enteredPassword = ""
                                        loginError = null
                                        Toast.makeText(context, Translations.getString("welcomeBack", isUrdu), Toast.LENGTH_SHORT).show()
                                    } else {
                                        loginError = Translations.getString("incorrectPassword", isUrdu)
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                                modifier = Modifier.testTag("login_submit_button")
                            ) {
                                Text(Translations.getString("login", isUrdu), color = Color.White)
                            }
                        }
                    }
                }
            }
        }
    }

    // --- HANDOVER DISPATCH RECEIPT DIALOG ---
    if (showReceiptDialog) {
        Dialog(onDismissRequest = { showReceiptDialog = false }) {
            Card(
                colors = CardDefaults.cardColors(containerColor = DarkSlateSurface),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(2.dp, GoldAccent),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
                    .testTag("receipt_dialog")
            ) {
                Column(
                    modifier = Modifier
                        .padding(24.dp)
                        .verticalScroll(androidx.compose.foundation.rememberScrollState()),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = Icons.Default.Check,
                        contentDescription = "Receipt Success",
                        tint = GoldAccent,
                        modifier = Modifier.size(44.dp)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = Translations.getString("handoverSuccess", isUrdu),
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextOffWhite,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(16.dp))

                    Surface(
                        color = Color(0xFF0F1610),
                        shape = RoundedCornerShape(8.dp),
                        border = BorderStroke(1.dp, TextMuted.copy(alpha = 0.2f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = receiptText,
                            fontSize = 12.sp,
                            color = Color.White,
                            fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                            modifier = Modifier.padding(14.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Card(
                        colors = CardDefaults.cardColors(containerColor = EmeraldDark),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = Translations.getString("newPasswordGenerated", isUrdu).format(generatedPassword),
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = GoldAccent,
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = Translations.getString("passwordInvalidated", isUrdu),
                                fontSize = 10.sp,
                                color = TextOffWhite.copy(alpha = 0.8f),
                                textAlign = TextAlign.Center
                            )
                        }
                    }

                    if (nextCustodianPhone.isNotBlank()) {
                        Spacer(modifier = Modifier.height(12.dp))
                        Button(
                            onClick = {
                                try {
                                    val cleanPhone = nextCustodianPhone.replace(Regex("[^0-9]"), "")
                                    val textMsg = if (isUrdu) {
                                        "نگران منتقلی: السلام علیکم $nextCustodianName، اب آپ تنظیم امانت تقسیم کے فعال نگران ہیں۔ آپ کا خفیہ ایڈمن پاس ورڈ یہ ہے: $generatedPassword"
                                    } else {
                                        "Custodian Handover: Hello $nextCustodianName, you are now the active Custodian for Tanzeem Amanat Taqseem. Your secure random admin password is: $generatedPassword"
                                    }
                                    val url = "https://wa.me/$cleanPhone?text=${java.net.URLEncoder.encode(textMsg, "UTF-8")}"
                                    uriHandler.openUri(url)
                                } catch (e: Exception) {
                                    e.printStackTrace()
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF25D366)), // WhatsApp Green
                            modifier = Modifier.fillMaxWidth().testTag("send_whatsapp_pw_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Share,
                                contentDescription = "WhatsApp",
                                tint = Color.White
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (isUrdu) "پاس ورڈ واٹس ایپ پر بھیجیں" else "Send Password via WhatsApp",
                                color = Color.White,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(24.dp))

                    Button(
                        onClick = {
                            showReceiptDialog = false
                            // After handover complete, switch back to read-only for security and return to welcome screen
                            viewModel.setAdminMode(false)
                            viewModel.setSuperAdminMode(false)
                            showWelcomeScreen = true
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("receipt_close_button")
                    ) {
                        Text(if (isUrdu) "اوکے / بند کریں" else "OK / Close", color = Color.White)
                    }
                }
            }
        }
    }
}

// ==========================================
// DASHBOARD TAB SCREEN
// ==========================================
@Composable
fun DashboardTabScreen(
    viewModel: TatViewModel,
    members: List<Member>,
    claims: List<Claim>,
    poolBalance: Double,
    isUrdu: Boolean,
    isAdminMode: Boolean,
    isSuperAdmin: Boolean
) {
    val uriHandler = androidx.compose.ui.platform.LocalUriHandler.current
    val scrollState = androidx.compose.foundation.rememberScrollState()
    val context = androidx.compose.ui.platform.LocalContext.current

    // Calculate details
    val totalMembers = members.size
    val activeQatar = members.count { it.status == "Active Qatar" }
    val onVacation = members.count { it.status == "On Vacation" }
    val leftQatar = members.count { it.status == "Left Qatar for Good" }

    // Contributions
    val totalPossibleYears = totalMembers * 3
    val year1PaidCount = members.count { it.year1Paid }
    val year2PaidCount = members.count { it.year2Paid }
    val year3PaidCount = members.count { it.year3Paid }
    val totalPaidYears = year1PaidCount + year2PaidCount + year3PaidCount
    val totalUnpaidYears = totalPossibleYears - totalPaidYears

    val year1Collected = year1PaidCount * 200.0
    val year2Collected = year2PaidCount * 200.0
    val year3Collected = year3PaidCount * 200.0
    val totalSurplusCollected = members.sumOf { it.surplusPaidAmount }
    val overallTotalCollected = (totalPaidYears * 200.0) + totalSurplusCollected

    val paidAmount = overallTotalCollected
    val unpaidAmount = totalUnpaidYears * 200.0
    val totalContributionsAmount = totalPossibleYears * 200.0

    val paidRatio = if (totalPossibleYears > 0) totalPaidYears.toFloat() / totalPossibleYears else 0f

    val totalClaimsCount = claims.size

    // Health state
    val healthLabelKey = when {
        poolBalance > 15000 -> "excellent"
        poolBalance > 5000 -> "stable"
        else -> "low"
    }
    val healthColor = when {
        poolBalance > 15000 -> EmeraldLight
        poolBalance > 5000 -> GoldAccent
        else -> RedForfeited
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // 2. Fund Health and Security Box
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .testTag("fund_pool_card"),
            colors = CardDefaults.cardColors(containerColor = DarkSlateSurface),
            border = BorderStroke(1.dp, EmeraldPrimary.copy(alpha = 0.5f)),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(
                modifier = Modifier.padding(12.dp)
            ) {
                Text(
                    text = Translations.getString("fundHealth", isUrdu),
                    color = TextMuted,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.5.sp
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = Translations.getString("totalPool", isUrdu),
                            color = TextOffWhite,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Medium
                        )
                        Row(
                            verticalAlignment = Alignment.Bottom,
                            modifier = Modifier.padding(top = 4.dp)
                        ) {
                            Text(
                                text = String.format(Locale.US, "%,.2f", poolBalance),
                                color = EmeraldLight,
                                fontSize = 28.sp,
                                fontWeight = FontWeight.Black,
                                maxLines = 1,
                                overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                            )
                            Text(
                                text = " QAR",
                                color = EmeraldLight,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(bottom = 4.dp, start = 2.dp)
                            )
                        }
                    }
                    // Fun Health Status Badge
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(20.dp))
                            .background(healthColor.copy(alpha = 0.15f))
                            .border(BorderStroke(1.dp, healthColor), RoundedCornerShape(20.dp))
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .background(healthColor, CircleShape)
                            )
                            Text(
                                text = Translations.getString(healthLabelKey, isUrdu),
                                color = if (isSystemInDarkTheme) Color.White else healthColor,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                softWrap = false
                            )
                        }
                    }
                }

                // Beautiful interactive meter/bar showing current pool versus overall collections
                Spacer(modifier = Modifier.height(16.dp))
                val meterProgress = if (totalContributionsAmount > 0) (poolBalance / totalContributionsAmount).toFloat().coerceIn(0f, 1f) else 0f
                Column(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = if (isUrdu) "ریزرو برقرار رکھنے کی شرح" else "Reserve Retention Rate",
                            color = TextMuted,
                            fontSize = 11.sp
                        )
                        Text(
                            text = "${(meterProgress * 100).toInt()}%",
                            color = TextOffWhite,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(10.dp)
                            .clip(CircleShape)
                            .background(DarkSlateSurfaceVariant)
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxHeight()
                                .fillMaxWidth(fraction = meterProgress)
                                .clip(CircleShape)
                                .background(
                                    brush = Brush.horizontalGradient(
                                        colors = listOf(healthColor.copy(alpha = 0.6f), healthColor)
                                    )
                                )
                        )
                    }
                }
            }
        }

        // 3. Mini Stat Grid (2 columns)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Total Registered Members
            Card(
                modifier = Modifier
                    .weight(1f)
                    .height(76.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSlateSurface),
                border = BorderStroke(1.dp, EmeraldPrimary.copy(alpha = 0.5f)),
                shape = RoundedCornerShape(8.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(10.dp),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Icon(
                        imageVector = Icons.Default.Group,
                        contentDescription = "Members count",
                        tint = GoldAccent,
                        modifier = Modifier.size(16.dp)
                    )
                    Column {
                        Text(
                            text = Translations.getString("activeMembers", isUrdu),
                            color = TextMuted,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Medium,
                            maxLines = 1
                        )
                        Text(
                            text = totalMembers.toString(),
                            color = TextOffWhite,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            // Claims processed
            Card(
                modifier = Modifier
                    .weight(1f)
                    .height(76.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSlateSurface),
                border = BorderStroke(1.dp, EmeraldPrimary.copy(alpha = 0.5f)),
                shape = RoundedCornerShape(8.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(10.dp),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = "Claims processed",
                        tint = EmeraldLight,
                        modifier = Modifier.size(16.dp)
                    )
                    Column {
                        Text(
                            text = if (isUrdu) "کل منظور شدہ کلیمز" else "Claims Settle",
                            color = TextMuted,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Medium,
                            maxLines = 1
                        )
                        Text(
                            text = totalClaimsCount.toString(),
                            color = TextOffWhite,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // 4. Collection Progress Chart (Circular + Legend)
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .testTag("collection_chart_card"),
            colors = CardDefaults.cardColors(containerColor = DarkSlateSurface),
            border = BorderStroke(1.dp, EmeraldPrimary.copy(alpha = 0.5f)),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp)
            ) {
                Text(
                    text = Translations.getString("contributionProgress", isUrdu),
                    color = TextOffWhite,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(16.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(20.dp)
                ) {
                    val circleBgColor = DarkSlateSurfaceVariant
                    val circleProgressColor = EmeraldLight
                    // Custom Draw Circular Progress Ring
                    Box(
                        modifier = Modifier
                            .size(100.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        androidx.compose.foundation.Canvas(modifier = Modifier.size(90.dp)) {
                            // Background circle
                            drawCircle(
                                color = circleBgColor,
                                radius = size.minDimension / 2,
                                style = androidx.compose.ui.graphics.drawscope.Stroke(width = 12.dp.toPx())
                            )
                            // Filled arc
                            drawArc(
                                color = circleProgressColor,
                                startAngle = -90f,
                                sweepAngle = paidRatio * 360f,
                                useCenter = false,
                                style = androidx.compose.ui.graphics.drawscope.Stroke(
                                    width = 12.dp.toPx(),
                                    cap = androidx.compose.ui.graphics.StrokeCap.Round
                                )
                            )
                        }
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = "${(paidRatio * 100).toInt()}%",
                                color = TextOffWhite,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Black
                            )
                            Text(
                                text = if (isUrdu) "وصول شدہ" else "Paid",
                                color = TextMuted,
                                fontSize = 8.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    // Labels & ledger details
                    Column(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // Paid Key
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Box(modifier = Modifier.size(10.dp).background(EmeraldLight, RoundedCornerShape(2.dp)))
                            Column {
                                Text(
                                    text = Translations.getString("paidContribution", isUrdu),
                                    color = TextMuted,
                                    fontSize = 9.sp
                                )
                                Text(
                                    text = "${String.format(Locale.US, "%,d", paidAmount.toInt())} QAR",
                                    color = TextOffWhite,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        // Unpaid Key
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Box(modifier = Modifier.size(10.dp).background(DarkSlateSurfaceVariant, RoundedCornerShape(2.dp)))
                            Column {
                                Text(
                                    text = Translations.getString("unpaidContribution", isUrdu),
                                    color = TextMuted,
                                    fontSize = 9.sp
                                )
                                Text(
                                    text = "${String.format(Locale.US, "%,d", unpaidAmount.toInt())} QAR",
                                    color = TextOffWhite.copy(alpha = 0.7f),
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }

                // Annual Breakdown and Overall Total
                Spacer(modifier = Modifier.height(16.dp))
                androidx.compose.material3.HorizontalDivider(color = DarkSlateSurfaceVariant, thickness = 1.dp)
                Spacer(modifier = Modifier.height(16.dp))
                
                Text(
                    text = if (isUrdu) "سالانہ وصولی کی تفصیلات" else "Annual Collection Breakdown",
                    color = TextOffWhite,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.5.sp,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
                
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // First Year Card
                    Card(
                        modifier = Modifier.weight(1f),
                        colors = CardDefaults.cardColors(containerColor = DarkSlateSurfaceVariant.copy(alpha = 0.5f)),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text(
                                text = if (isUrdu) "پہلا سال" else "1st Year",
                                color = TextMuted,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "${String.format(Locale.US, "%,d", year1Collected.toInt())} QAR",
                                color = TextOffWhite,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Black
                            )
                        }
                    }

                    // Second Year Card
                    Card(
                        modifier = Modifier.weight(1f),
                        colors = CardDefaults.cardColors(containerColor = DarkSlateSurfaceVariant.copy(alpha = 0.5f)),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text(
                                text = if (isUrdu) "دوسرا سال" else "2nd Year",
                                color = TextMuted,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "${String.format(Locale.US, "%,d", year2Collected.toInt())} QAR",
                                color = TextOffWhite,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Black
                            )
                        }
                    }

                    // Third Year Card
                    Card(
                        modifier = Modifier.weight(1f),
                        colors = CardDefaults.cardColors(containerColor = DarkSlateSurfaceVariant.copy(alpha = 0.5f)),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text(
                                text = if (isUrdu) "تیسرا سال" else "3rd Year",
                                color = TextMuted,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "${String.format(Locale.US, "%,d", year3Collected.toInt())} QAR",
                                color = TextOffWhite,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Black
                            )
                        }
                    }
                }
                
                Spacer(modifier = Modifier.height(12.dp))
                // Overall Total Card
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = EmeraldPrimary.copy(alpha = 0.1f)),
                    border = BorderStroke(1.dp, EmeraldLight.copy(alpha = 0.3f)),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.TrendingUp,
                                contentDescription = "Total Collected",
                                tint = EmeraldLight,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (isUrdu) "کل وصول شدہ رقم" else "Overall Total Collected",
                                color = TextOffWhite,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Text(
                            text = "${String.format(Locale.US, "%,d", overallTotalCollected.toInt())} QAR",
                            color = EmeraldLight,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Black
                        )
                    }
                }
            }
        }

        // 5. Resident Status Distribution Chart
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .testTag("residence_chart_card"),
            colors = CardDefaults.cardColors(containerColor = DarkSlateSurface),
            border = BorderStroke(1.dp, EmeraldPrimary.copy(alpha = 0.5f)),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp)
            ) {
                Text(
                    text = Translations.getString("memberStatusBreakdown", isUrdu),
                    color = TextOffWhite,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(16.dp))

                // Stacked segmented horizontal bar
                val totalWithStatus = (activeQatar + onVacation + leftQatar).toFloat()
                val activeRatio = if (totalWithStatus > 0) activeQatar / totalWithStatus else 0f
                val vacationRatio = if (totalWithStatus > 0) onVacation / totalWithStatus else 0f
                val leftRatio = if (totalWithStatus > 0) leftQatar / totalWithStatus else 0f

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(16.dp)
                        .clip(CircleShape)
                ) {
                    if (activeRatio > 0) {
                        Box(
                            modifier = Modifier
                                .weight(activeRatio)
                                .fillMaxHeight()
                                .background(EmeraldLight)
                        )
                    }
                    if (vacationRatio > 0) {
                        Box(
                            modifier = Modifier
                                .weight(vacationRatio)
                                .fillMaxHeight()
                                .background(BlueVacation)
                        )
                    }
                    if (leftRatio > 0) {
                        Box(
                            modifier = Modifier
                                .weight(leftRatio)
                                .fillMaxHeight()
                                .background(RedForfeited)
                        )
                    }
                    if (totalWithStatus == 0f) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .fillMaxHeight()
                                .background(DarkSlateSurfaceVariant)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Interactive styled detail legends
                Column(
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Active Qatar
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Box(modifier = Modifier.size(8.dp).background(EmeraldLight, CircleShape))
                            Text(
                                text = Translations.getString("statusActive", isUrdu),
                                color = TextOffWhite,
                                fontSize = 11.sp
                            )
                        }
                        Text(
                            text = "$activeQatar (${if (totalWithStatus > 0) (activeRatio * 100).toInt() else 0}%)",
                            color = TextOffWhite,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    // On Vacation
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Box(modifier = Modifier.size(8.dp).background(BlueVacation, CircleShape))
                            Text(
                                text = Translations.getString("statusVacation", isUrdu),
                                color = TextOffWhite,
                                fontSize = 11.sp
                            )
                        }
                        Text(
                            text = "$onVacation (${if (totalWithStatus > 0) (vacationRatio * 100).toInt() else 0}%)",
                            color = TextOffWhite,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    // Left Qatar
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Box(modifier = Modifier.size(8.dp).background(RedForfeited, CircleShape))
                            Text(
                                text = Translations.getString("statusLeft", isUrdu),
                                color = TextOffWhite,
                                fontSize = 11.sp
                            )
                        }
                        Text(
                            text = "$leftQatar (${if (totalWithStatus > 0) (leftRatio * 100).toInt() else 0}%)",
                            color = TextOffWhite,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // --- NEW FEATURES: DATA PORTABILITY EXPORT & CHRONOLOGICAL PAYMENT LEDGER ---
        Spacer(modifier = Modifier.height(16.dp))

        // 5. Data Portability & CSV Export Card
        val custodiansList by viewModel.custodians.collectAsStateWithLifecycle()

        Card(
            modifier = Modifier
                .fillMaxWidth()
                .testTag("data_portability_card"),
            colors = CardDefaults.cardColors(containerColor = DarkSlateSurface),
            border = BorderStroke(1.dp, EmeraldPrimary.copy(alpha = 0.5f)),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .background(GoldAccent.copy(alpha = 0.15f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Share,
                            contentDescription = "Export Icon",
                            tint = GoldAccent,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = Translations.getString("exportTitle", isUrdu),
                            color = TextOffWhite,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = Translations.getString("exportDesc", isUrdu),
                            color = TextMuted,
                            fontSize = 11.sp,
                            lineHeight = 15.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Export Members Button
                    Button(
                        onClick = {
                            val file = exportMembersPdf(context, members, isUrdu)
                            sharePdfFile(context, file)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                        modifier = Modifier
                            .weight(1f)
                            .defaultMinSize(minHeight = 48.dp)
                            .testTag("export_members_pdf_button"),
                        contentPadding = PaddingValues(horizontal = 4.dp, vertical = 4.dp),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Receipt,
                                contentDescription = "Members PDF",
                                tint = Color.White,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = Translations.getString("exportMembersBtn", isUrdu),
                                color = Color.White,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Center
                            )
                        }
                    }

                    // Export Custodians Button
                    Button(
                        onClick = {
                            val file = exportCustodiansPdf(context, custodiansList, isUrdu)
                            sharePdfFile(context, file)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                        modifier = Modifier
                            .weight(1f)
                            .defaultMinSize(minHeight = 48.dp)
                            .testTag("export_custodians_pdf_button"),
                        contentPadding = PaddingValues(horizontal = 4.dp, vertical = 4.dp),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.History,
                                contentDescription = "Custodians PDF",
                                tint = Color.White,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = Translations.getString("exportCustodiansBtn", isUrdu),
                                color = Color.White,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))
                
                var showCheckpointsDialog by remember { mutableStateOf(false) }
                
                // Cloud Checkpoints Buttons (Super Admin Only)

                
                if (isSuperAdmin) {

                
                    var isBackingUp by remember { mutableStateOf(false) }

                
                    Row(

                
                        modifier = Modifier.fillMaxWidth(),

                
                        horizontalArrangement = Arrangement.spacedBy(8.dp)

                
                    ) {

                
                        Button(

                
                            onClick = { 

                
                                isBackingUp = true

                
                                viewModel.createManualBackup { success ->
                                    isBackingUp = false
                                    if (success) {
                                        Toast.makeText(context, if (isUrdu) "بیک اپ مکمل ہو گیا" else "Backup created successfully", Toast.LENGTH_SHORT).show()
                                    } else {
                                        Toast.makeText(context, if (isUrdu) "بیک اپ ناکام ہو گیا (کیا فائر بیس ترتیب دیا گیا ہے؟)" else "Backup failed (Firebase not configured?)", Toast.LENGTH_LONG).show()
                                    }
                                }

                
                            },

                
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF6366F1)), // Indigo Accent

                
                            modifier = Modifier

                
                                .weight(1f)

                
                                .height(40.dp)

                
                                .testTag("cloud_checkpoints_backup_button"),

                
                            shape = RoundedCornerShape(8.dp),

                
                            enabled = !isBackingUp

                
                        ) {

                
                            Row(

                
                                verticalAlignment = Alignment.CenterVertically,

                
                                horizontalArrangement = Arrangement.Center

                
                            ) {

                
                                if (isBackingUp) {

                
                                    CircularProgressIndicator(color = Color.White, modifier = Modifier.size(16.dp), strokeWidth = 2.dp)

                
                                } else {

                
                                    Icon(

                
                                        imageVector = Icons.Default.CloudUpload,

                
                                        contentDescription = "Backup",

                
                                        tint = Color.White,

                
                                        modifier = Modifier.size(16.dp)

                
                                    )

                
                                }

                
                                Spacer(modifier = Modifier.width(4.dp))

                
                                Text(

                
                                    text = if (isUrdu) "چیک پوائنٹس (بیک اپ)" else "Check Points (Backup)",

                
                                    color = Color.White,

                
                                    fontSize = 10.sp,

                
                                    fontWeight = FontWeight.Bold,

                
                                    maxLines = 1

                
                                )

                
                            }

                
                        }

                
                        

                
                        Button(

                
                            onClick = { showCheckpointsDialog = true },

                
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF6366F1)), // Indigo Accent

                
                            modifier = Modifier

                
                                .weight(1f)

                
                                .height(40.dp)

                
                                .testTag("cloud_checkpoints_restore_button"),

                
                            shape = RoundedCornerShape(8.dp)

                
                        ) {

                
                            Row(

                
                                verticalAlignment = Alignment.CenterVertically,

                
                                horizontalArrangement = Arrangement.Center

                
                            ) {

                
                                Icon(

                
                                    imageVector = Icons.Default.CloudDownload,

                
                                    contentDescription = "Restore",

                
                                    tint = Color.White,

                
                                    modifier = Modifier.size(16.dp)

                
                                )

                
                                Spacer(modifier = Modifier.width(4.dp))

                
                                Text(

                
                                    text = if (isUrdu) "چیک پوائنٹس (ریسٹور)" else "Check Points (Restore)",

                
                                    color = Color.White,

                
                                    fontSize = 10.sp,

                
                                    fontWeight = FontWeight.Bold,

                
                                    maxLines = 1

                
                                )

                
                            }

                
                        }

                
                    }

                
                }
                
                if (showCheckpointsDialog) {
                    CloudCheckpointsDialog(
                        viewModel = viewModel,
                        isUrdu = isUrdu,
                        onDismiss = { showCheckpointsDialog = false }
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // 6. Chronological Payment Ledger Card
        var transSearchQuery by remember { mutableStateOf("") }
        val allTransactions = remember(members) { getPaymentChronologicalList(members) }
        val filteredTransactions = remember(allTransactions, transSearchQuery) {
            if (transSearchQuery.isBlank()) {
                allTransactions
            } else {
                allTransactions.filter {
                    it.memberName.contains(transSearchQuery, ignoreCase = true)
                }
            }
        }

        Card(
            modifier = Modifier
                .fillMaxWidth()
                .testTag("transaction_ledger_card"),
            colors = CardDefaults.cardColors(containerColor = DarkSlateSurface),
            border = BorderStroke(1.dp, EmeraldPrimary.copy(alpha = 0.5f)),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp)
            ) {
                // Header row
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .background(EmeraldPrimary.copy(alpha = 0.15f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Receipt,
                            contentDescription = "Ledger Icon",
                            tint = EmeraldPrimary,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Column {
                        Text(
                            text = Translations.getString("transactionLog", isUrdu),
                            color = TextOffWhite,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = Translations.getString("paymentsLogDesc", isUrdu),
                            color = TextMuted,
                            fontSize = 11.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Search field
                OutlinedTextField(
                    value = transSearchQuery,
                    onValueChange = { transSearchQuery = it },
                    placeholder = {
                        Text(
                            text = Translations.getString("searchByMemberName", isUrdu),
                            color = TextMuted,
                            fontSize = 12.sp
                        )
                    },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = "Search",
                            tint = TextMuted,
                            modifier = Modifier.size(18.dp)
                        )
                    },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = EmeraldPrimary,
                        unfocusedBorderColor = DarkSlateSurfaceVariant,
                        focusedTextColor = TextOffWhite,
                        unfocusedTextColor = TextOffWhite
                    ),
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("transaction_search_input")
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Scrollable/structured list of transactions
                if (filteredTransactions.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = Translations.getString("noPaymentsFound", isUrdu),
                            color = TextMuted,
                            fontSize = 12.sp,
                            textAlign = TextAlign.Center
                        )
                    }
                } else {
                    var showAllTransactions by remember { mutableStateOf(false) }
                    val displayedTransactions = if (showAllTransactions) filteredTransactions else filteredTransactions.take(5)

                    Column(
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        displayedTransactions.forEach { trans ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(DarkSlateBackground.copy(alpha = 0.5f), RoundedCornerShape(10.dp))
                                    .border(BorderStroke(1.dp, DarkSlateSurfaceVariant.copy(alpha = 0.5f)), RoundedCornerShape(10.dp))
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    // Visual status circle
                                    Box(
                                        modifier = Modifier
                                            .size(32.dp)
                                            .background(EmeraldPrimary.copy(alpha = 0.12f), CircleShape),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.TrendingUp,
                                            contentDescription = "Paid icon",
                                            tint = EmeraldLight,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }

                                    Column {
                                        Text(
                                            text = trans.memberName,
                                            color = TextOffWhite,
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Spacer(modifier = Modifier.height(2.dp))
                                        Text(
                                            text = trans.memberPhone,
                                            color = TextMuted,
                                            fontSize = 11.sp
                                        )
                                    }
                                }

                                Column(
                                    horizontalAlignment = Alignment.End
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        // Badge for Year
                                        Box(
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(4.dp))
                                                .background(GoldAccent.copy(alpha = 0.15f))
                                                .padding(horizontal = 6.dp, vertical = 2.dp)
                                        ) {
                                            Text(
                                                text = if (isUrdu) {
                                                    when (trans.yearLabel) {
                                                        "Year 1" -> Translations.getString("year1", isUrdu)
                                                        "Year 2" -> Translations.getString("year2", isUrdu)
                                                        else -> Translations.getString("year3", isUrdu)
                                                    }
                                                } else {
                                                    trans.yearLabel
                                                },
                                                color = GoldAccent,
                                                fontSize = 9.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }

                                        Text(
                                            text = "+${trans.amount.toInt()} QAR",
                                            color = EmeraldLight,
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.Black
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = trans.dateStr,
                                        color = TextMuted,
                                        fontSize = 10.sp
                                    )
                                }
                            }
                        }

                        if (filteredTransactions.size > 5) {
                            TextButton(
                                onClick = { showAllTransactions = !showAllTransactions },
                                modifier = Modifier
                                    .align(Alignment.CenterHorizontally)
                                    .testTag("toggle_all_transactions_button")
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Text(
                                        text = if (showAllTransactions) {
                                            if (isUrdu) "کم دکھائیں" else "Show Less"
                                        } else {
                                            if (isUrdu) "تمام ادائیگیاں دکھائیں (${filteredTransactions.size})" else "Show All Payments (${filteredTransactions.size})"
                                        },
                                        color = GoldAccent,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Icon(
                                        imageVector = if (showAllTransactions) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                                        contentDescription = "Arrow",
                                        tint = GoldAccent,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// MEMBERS TAB SCREEN
// ==========================================
@Composable
fun MembersTabScreen(
    viewModel: TatViewModel,
    members: List<Member>,
    isAdminMode: Boolean,
    isUrdu: Boolean
) {
    var showAddDialog by remember { mutableStateOf(false) }
    var showEditDialog by remember { mutableStateOf<Member?>(null) }
    var searchQuery by remember { mutableStateOf("") }
    
    val custodians by viewModel.custodians.collectAsStateWithLifecycle()
    val activeCustodianName = custodians.firstOrNull { it.isCurrent }?.name ?: "No Custodian"

    val filteredMembers = remember(members, searchQuery) {
        if (searchQuery.isBlank()) {
            members
        } else {
            val query = searchQuery.trim().lowercase(Locale.getDefault())
            members.filter {
                it.name.lowercase(Locale.getDefault()).contains(query) ||
                it.qid.contains(query) ||
                it.phone.contains(query)
            }
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Screen Header Card
            Card(
                colors = CardDefaults.cardColors(containerColor = DarkSlateSurface),
                shape = RoundedCornerShape(0.dp, 0.dp, 16.dp, 16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = Translations.getString("membersTab", isUrdu),
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = GoldAccent
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = Translations.getString("activeMembers", isUrdu) + ": ${members.size}",
                        fontSize = 13.sp,
                        color = TextOffWhite
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = Translations.getString("allContributionsForfeited", isUrdu) + " " + Translations.getString("contributionCycle", isUrdu),
                        fontSize = 11.sp,
                        color = TextMuted
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        placeholder = { Text(if (isUrdu) "ممبر تلاش کریں..." else "Search members...", color = TextMuted, fontSize = 13.sp) },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search", tint = GoldAccent) },
                        trailingIcon = {
                            if (searchQuery.isNotEmpty()) {
                                IconButton(onClick = { searchQuery = "" }) {
                                    Icon(Icons.Default.Clear, contentDescription = "Clear", tint = TextMuted)
                                }
                            }
                        },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = GoldAccent,
                            unfocusedBorderColor = TextMuted.copy(alpha = 0.3f),
                            focusedContainerColor = if (isSystemInDarkTheme) Color.Black.copy(alpha = 0.2f) else DarkSlateSurfaceVariant.copy(alpha = 0.4f),
                            unfocusedContainerColor = if (isSystemInDarkTheme) Color.Black.copy(alpha = 0.2f) else DarkSlateSurfaceVariant.copy(alpha = 0.4f),
                            focusedTextColor = TextOffWhite,
                            unfocusedTextColor = TextOffWhite,
                            cursorColor = GoldAccent
                        ),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().height(52.dp),
                        shape = RoundedCornerShape(10.dp)
                    )
                }
            }

            // Members List
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(bottom = 80.dp)
            ) {
                items(filteredMembers) { member ->
                    MemberCard(
                        member = member,
                        isAdminMode = isAdminMode,
                        isUrdu = isUrdu,
                        activeCustodianName = activeCustodianName,
                        onCheckedChange = { yIdx, checked, selectedDate ->
                            val updated = when (yIdx) {
                                1 -> member.copy(year1Paid = checked, year1PaymentDate = if (checked) selectedDate else null)
                                2 -> member.copy(year2Paid = checked, year2PaymentDate = if (checked) selectedDate else null)
                                3 -> member.copy(year3Paid = checked, year3PaymentDate = if (checked) selectedDate else null)
                                else -> member.copy(
                                    surplusPaid = false, // Keep unchecked on paying
                                    surplusPaidAmount = if (checked) member.surplusPaidAmount + member.surplusOwed else member.surplusPaidAmount,
                                    surplusOwed = if (checked) 0.0 else member.surplusOwed
                                )
                            }
                            viewModel.updateMember(updated)
                        },
                        onEdit = { showEditDialog = member },
                        onDelete = { viewModel.deleteMember(member) }
                    )
                }
            }
        }

        // FAB to Add Member
        if (isAdminMode) {
            FloatingActionButton(
                onClick = { showAddDialog = true },
                containerColor = EmeraldPrimary,
                contentColor = Color.White,
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(16.dp)
                    .testTag("add_member_fab")
            ) {
                Icon(imageVector = Icons.Default.Add, contentDescription = "Add Member")
            }
        }
    }

    // ADD MEMBER DIALOG
    if (showAddDialog) {
        MemberFormDialog(
            title = Translations.getString("registration", isUrdu),
            isUrdu = isUrdu,
            onDismiss = { showAddDialog = false },
            onSave = { name, qid, phone, status, y1, y2, y3 ->
                viewModel.addMember(name, qid, phone, status, y1, y2, y3)
                showAddDialog = false
            }
        )
    }

    // EDIT MEMBER DIALOG
    if (showEditDialog != null) {
        val member = showEditDialog!!
        MemberFormDialog(
            title = Translations.getString("editMember", isUrdu),
            member = member,
            isUrdu = isUrdu,
            onDismiss = { showEditDialog = null },
            onSave = { name, qid, phone, status, y1, y2, y3 ->
                val today = SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date())
                viewModel.updateMember(
                    member.copy(
                        name = name,
                        qid = qid,
                        phone = phone,
                        status = status,
                        year1Paid = y1,
                        year2Paid = y2,
                        year3Paid = y3,
                        year1PaymentDate = if (y1) (member.year1PaymentDate ?: today) else null,
                        year2PaymentDate = if (y2) (member.year2PaymentDate ?: today) else null,
                        year3PaymentDate = if (y3) (member.year3PaymentDate ?: today) else null
                    )
                )
                showEditDialog = null
            }
        )
    }
}

@Composable
fun MemberCard(
    member: Member,
    isAdminMode: Boolean,
    isUrdu: Boolean,
    activeCustodianName: String,
    onCheckedChange: (yearIdx: Int, checked: Boolean, selectedDate: String?) -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    var showConfirmDelete by remember { mutableStateOf(false) }
    var showReceiptDialog by remember { mutableStateOf(false) }
    
    val context = androidx.compose.ui.platform.LocalContext.current
    var showDatePickerForYear by remember { mutableStateOf<Int?>(null) }

    if (showDatePickerForYear != null) {
        val calendar = java.util.Calendar.getInstance()
        val year = calendar.get(java.util.Calendar.YEAR)
        val month = calendar.get(java.util.Calendar.MONTH)
        val day = calendar.get(java.util.Calendar.DAY_OF_MONTH)

        android.app.DatePickerDialog(
            context,
            { _, selectedYear, selectedMonth, selectedDay ->
                val dateStr = String.format(Locale.getDefault(), "%02d %s %d", selectedDay, java.text.DateFormatSymbols().shortMonths[selectedMonth], selectedYear)
                onCheckedChange(showDatePickerForYear!!, true, dateStr)
                showDatePickerForYear = null
            },
            year,
            month,
            day
        ).apply {
            setOnCancelListener { showDatePickerForYear = null }
            show()
        }
    }

    if (showConfirmDelete) {
        androidx.compose.ui.window.Dialog(onDismissRequest = { showConfirmDelete = false }) {
            Card(
                colors = CardDefaults.cardColors(containerColor = DarkSlateSurface),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, GoldAccent),
                modifier = Modifier.padding(16.dp)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = if (isUrdu) "ممبر حذف کریں؟" else "Delete Member?",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = GoldAccent
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = if (isUrdu) 
                            "کیا آپ واقعی ممبر \"${member.name}\" کو مستقل طور پر حذف کرنا چاہتے ہیں؟"
                        else 
                            "Are you sure you want to permanently delete member \"${member.name}\"?",
                        fontSize = 14.sp,
                        color = TextOffWhite,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(20.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        TextButton(onClick = { showConfirmDelete = false }) {
                            Text(if (isUrdu) "منسوخ کریں" else "Cancel", color = TextMuted)
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Button(
                            onClick = {
                                onDelete()
                                showConfirmDelete = false
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = RedForfeited)
                        ) {
                            Text(if (isUrdu) "حذف کریں" else "Delete", color = Color.White)
                        }
                    }
                }
            }
        }
    }

    if (showReceiptDialog) {
        val coroutineScope = rememberCoroutineScope()
        androidx.compose.ui.window.Dialog(onDismissRequest = { showReceiptDialog = false }) {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        // Header
                    Text("RECEIPT", fontSize = 24.sp, fontWeight = FontWeight.ExtraBold, color = Color.Black, letterSpacing = 2.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("Tanzeem Amanat Taqseem", fontSize = 14.sp, color = Color.DarkGray)
                    Divider(color = Color.LightGray, modifier = Modifier.padding(vertical = 12.dp))
                    
                    // Member Info
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Member:", color = Color.Gray, fontSize = 12.sp)
                        Text(member.name, color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("QID:", color = Color.Gray, fontSize = 12.sp)
                        Text(member.qid, color = Color.Black, fontSize = 14.sp)
                    }
                    Divider(color = Color.LightGray, modifier = Modifier.padding(vertical = 12.dp))
                    
                    // Payments
                    var total = 0
                    if (member.year1Paid) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Year 1 (${member.year1PaymentDate ?: "Paid"})", color = Color.DarkGray, fontSize = 12.sp)
                            Text("200 QAR", color = Color.Black, fontSize = 12.sp)
                        }
                        total += 200
                        Spacer(modifier = Modifier.height(4.dp))
                    }
                    if (member.year2Paid) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Year 2 (${member.year2PaymentDate ?: "Paid"})", color = Color.DarkGray, fontSize = 12.sp)
                            Text("200 QAR", color = Color.Black, fontSize = 12.sp)
                        }
                        total += 200
                        Spacer(modifier = Modifier.height(4.dp))
                    }
                    if (member.year3Paid) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Year 3 (${member.year3PaymentDate ?: "Paid"})", color = Color.DarkGray, fontSize = 12.sp)
                            Text("200 QAR", color = Color.Black, fontSize = 12.sp)
                        }
                        total += 200
                        Spacer(modifier = Modifier.height(4.dp))
                    }
                    
                    Divider(color = Color.Black, modifier = Modifier.padding(vertical = 8.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("TOTAL PAID", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text("$total QAR", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }
                    
                    Divider(color = Color.LightGray, modifier = Modifier.padding(vertical = 12.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Custodian:", color = Color.Gray, fontSize = 12.sp)
                        Text(activeCustodianName, color = Color.Black, fontSize = 12.sp)
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                    
                    Text("Thank you for your contribution.", fontSize = 12.sp, color = Color.Gray, fontStyle = androidx.compose.ui.text.font.FontStyle.Italic)
                    Spacer(modifier = Modifier.height(24.dp))
                    
                    } // End of captured column
                    
                    // Share Button
                    Button(
                        onClick = {
                            coroutineScope.launch {
                                try {
                                    val bitmap = createReceiptBitmap(member, activeCustodianName)
                                    
                                    val contentValues = android.content.ContentValues().apply {
                                        put(android.provider.MediaStore.MediaColumns.DISPLAY_NAME, "Receipt_${member.name}.png")
                                        put(android.provider.MediaStore.MediaColumns.MIME_TYPE, "image/png")
                                        put(android.provider.MediaStore.MediaColumns.RELATIVE_PATH, android.os.Environment.DIRECTORY_PICTURES)
                                    }

                                    val resolver = context.contentResolver
                                    val uri = resolver.insert(android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues)
                                    
                                    uri?.let {
                                        resolver.openOutputStream(it)?.use { stream ->
                                            bitmap.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, stream)
                                        }
                                        
                                        val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                                            type = "image/png"
                                            putExtra(android.content.Intent.EXTRA_STREAM, it)
                                            putExtra(android.content.Intent.EXTRA_TEXT, "Receipt for ${member.name}")
                                        }
                                        context.startActivity(android.content.Intent.createChooser(intent, "Share Receipt Image"))
                                        showReceiptDialog = false
                                    }
                                } catch (e: Exception) {
                                    e.printStackTrace()
                                }
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(imageVector = Icons.Default.Share, contentDescription = "Share", tint = Color.White)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Share Receipt Image", color = Color.White)
                    }
                    
                    Spacer(modifier = Modifier.height(8.dp))
                    TextButton(onClick = { showReceiptDialog = false }) {
                        Text("Close", color = Color.Gray)
                    }
                }
            }
        }
    }

    Card(
        colors = CardDefaults.cardColors(containerColor = DarkSlateSurface),
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, TextMuted.copy(alpha = if (isSystemInDarkTheme) 0.15f else 0.4f)),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("member_card_${member.id}")
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Top Row: Name and Edit/Delete controls
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = member.name,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = GoldAccent
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "QID: ${member.qid} • ${member.phone}",
                        fontSize = 11.sp,
                        color = TextMuted
                    )
                }

                // Status Badge
                val (badgeColor, labelKey) = when (member.status) {
                    "Active Qatar" -> GreenActive to "statusActive"
                    "On Vacation" -> BlueVacation to "statusVacation"
                    else -> RedForfeited to "statusLeft"
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(badgeColor.copy(alpha = 0.2f))
                        .border(1.dp, badgeColor, RoundedCornerShape(4.dp))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = Translations.getString(labelKey, isUrdu),
                        fontSize = 9.sp,
                        color = TextOffWhite,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Checkboxes Row (Year 1, 2, 3 Ledger)
            Text(
                text = Translations.getString("contributionCycle", isUrdu),
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = TextMuted,
                modifier = Modifier.padding(bottom = 6.dp)
            )

            val hasSurplus = member.surplusOwed > 0.0
            val isSurplusPaid = member.surplusPaidAmount > 0.0
            val canClickYearCheckboxes = isAdminMode && !hasSurplus

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf(
                    Translations.getString("year1", isUrdu) to member.year1Paid to 1,
                    Translations.getString("year2", isUrdu) to member.year2Paid to 2,
                    Translations.getString("year3", isUrdu) to member.year3Paid to 3
                ).forEach { (pair, yearIdx) ->
                    val (label, checked) = pair
                    Surface(
                        color = if (checked) EmeraldPrimary.copy(alpha = 0.15f) else Color.Transparent,
                        border = BorderStroke(1.dp, if (checked) EmeraldPrimary.copy(alpha = 0.8f) else TextMuted.copy(alpha = 0.25f)),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(8.dp))
                            .clickable(enabled = canClickYearCheckboxes) {
                                if (!checked) {
                                    showDatePickerForYear = yearIdx
                                } else {
                                    onCheckedChange(yearIdx, false, null)
                                }
                            }
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Start
                        ) {
                            Checkbox(
                                checked = checked,
                                onCheckedChange = if (canClickYearCheckboxes) { {
                                    if (it) {
                                        showDatePickerForYear = yearIdx
                                    } else {
                                        onCheckedChange(yearIdx, false, null)
                                    }
                                } } else null,
                                colors = CheckboxDefaults.colors(
                                    checkedColor = EmeraldPrimary,
                                    uncheckedColor = TextMuted.copy(alpha = 0.5f)
                                ),
                                modifier = Modifier
                                    .size(16.dp)
                                    .testTag("member_${member.id}_y${yearIdx}_checkbox")
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Column(verticalArrangement = Arrangement.Center) {
                                Text(
                                    text = label,
                                    fontSize = 10.sp,
                                    color = if (checked) TextOffWhite else TextMuted,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1
                                )
                                val paymentDate = when (yearIdx) {
                                    1 -> member.year1PaymentDate
                                    2 -> member.year2PaymentDate
                                    else -> member.year3PaymentDate
                                }
                                if (checked) {
                                    Text(
                                        text = paymentDate ?: (if (isUrdu) "ادا شدہ" else "Paid"),
                                        fontSize = 8.sp,
                                        color = EmeraldLight,
                                        fontWeight = FontWeight.Bold,
                                        maxLines = 1
                                    )
                                } else {
                                    Text(
                                        text = if (isUrdu) "بقایا" else "Unpaid",
                                        fontSize = 8.sp,
                                        color = TextMuted.copy(alpha = 0.5f),
                                        fontWeight = FontWeight.Normal,
                                        maxLines = 1
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Pay Surplus Option row
            Surface(
                color = when {
                    isSurplusPaid -> EmeraldPrimary.copy(alpha = 0.15f)
                    hasSurplus -> GoldAccent.copy(alpha = 0.1f)
                    else -> Color.Transparent
                },
                border = BorderStroke(
                    1.dp,
                    when {
                        isSurplusPaid -> EmeraldPrimary.copy(alpha = 0.8f)
                        hasSurplus -> GoldAccent.copy(alpha = 0.8f)
                        else -> TextMuted.copy(alpha = 0.15f)
                    }
                ),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .clickable(enabled = isAdminMode && hasSurplus) {
                        onCheckedChange(4, true, null)
                    }
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(
                            checked = member.surplusPaid,
                            onCheckedChange = if (isAdminMode && hasSurplus) { { onCheckedChange(4, it, null) } } else null,
                            colors = CheckboxDefaults.colors(
                                checkedColor = EmeraldPrimary,
                                uncheckedColor = if (hasSurplus) GoldAccent else TextMuted.copy(alpha = 0.3f)
                            ),
                            modifier = Modifier
                                .size(18.dp)
                                .testTag("member_${member.id}_surplus_checkbox")
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = if (isUrdu) "زائد رقم ادا کریں" else "Pay Surplus",
                                fontSize = 11.sp,
                                color = if (hasSurplus) GoldAccent else if (isSurplusPaid) TextOffWhite else TextMuted,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = when {
                                    isSurplusPaid -> if (isUrdu) "اضافی فنڈ ادا کیا گیا: ${member.surplusPaidAmount.toInt()} QAR" else "Paid extra: ${member.surplusPaidAmount.toInt()} QAR"
                                    hasSurplus -> if (isUrdu) "شراکت کی ضرورت ہے: ${member.surplusOwed.toInt()} QAR" else "Contribution needed: ${member.surplusOwed.toInt()} QAR"
                                    else -> if (isUrdu) "کوئی بقایا اضافی فنڈ نہیں ہے" else "No active surplus contribution needed"
                                },
                                fontSize = 9.sp,
                                color = if (hasSurplus) GoldAccent else if (isSurplusPaid) EmeraldLight else TextMuted
                            )
                        }
                    }
                    
                    if (hasSurplus) {
                        Text(
                            text = if (isUrdu) "درکار ہے" else "REQUIRED",
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            color = GoldAccent,
                            modifier = Modifier
                                .background(GoldAccent.copy(alpha = 0.2f), RoundedCornerShape(4.dp))
                                .border(1.dp, GoldAccent, RoundedCornerShape(4.dp))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
            }

            // Edit / Delete for Custodian
            if (isAdminMode) {
                Spacer(modifier = Modifier.height(12.dp))
                Divider(color = TextMuted.copy(alpha = 0.1f))
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = { showReceiptDialog = true },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Receipt,
                            contentDescription = "Receipt",
                            tint = EmeraldPrimary,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    IconButton(
                        onClick = onEdit,
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Edit,
                            contentDescription = "Edit Member",
                            tint = GoldAccent,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    IconButton(
                        onClick = { showConfirmDelete = true },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = "Delete Member",
                            tint = RedForfeited,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun MemberFormDialog(
    title: String,
    member: Member? = null,
    isUrdu: Boolean,
    onDismiss: () -> Unit,
    onSave: (name: String, qid: String, phone: String, status: String, y1: Boolean, y2: Boolean, y3: Boolean) -> Unit
) {
    var name by remember { mutableStateOf(member?.name ?: "") }
    var qid by remember { mutableStateOf(member?.qid ?: "") }
    var phone by remember { mutableStateOf(member?.phone ?: "") }
    var status by remember { mutableStateOf(member?.status ?: "Active Qatar") }
    var y1 by remember { mutableStateOf(member?.year1Paid ?: false) }
    var y2 by remember { mutableStateOf(member?.year2Paid ?: false) }
    var y3 by remember { mutableStateOf(member?.year3Paid ?: false) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            colors = CardDefaults.cardColors(containerColor = DarkSlateSurface),
            shape = RoundedCornerShape(16.dp),
            border = BorderStroke(1.dp, GoldAccent),
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .testTag("member_form_dialog")
        ) {
            LazyColumn(
                modifier = Modifier.padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                item {
                    Text(
                        text = title,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = GoldAccent
                    )
                }

                item {
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text(Translations.getString("fullName", isUrdu), color = TextMuted) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = GoldAccent,
                            unfocusedBorderColor = TextMuted.copy(alpha = 0.5f),
                            focusedTextColor = TextOffWhite,
                            unfocusedTextColor = TextOffWhite
                        ),
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("member_name_input")
                    )
                }

                item {
                    OutlinedTextField(
                        value = qid,
                        onValueChange = { qid = it },
                        label = { Text(Translations.getString("qid", isUrdu), color = TextMuted) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = GoldAccent,
                            unfocusedBorderColor = TextMuted.copy(alpha = 0.5f),
                            focusedTextColor = TextOffWhite,
                            unfocusedTextColor = TextOffWhite
                        ),
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("member_qid_input")
                    )
                }

                item {
                    OutlinedTextField(
                        value = phone,
                        onValueChange = { phone = it },
                        label = { Text(Translations.getString("phone", isUrdu), color = TextMuted) },
                        supportingText = {
                            Text(
                                text = Translations.getString("whatsappMandatory", isUrdu),
                                color = GoldAccent,
                                fontSize = 10.sp
                            )
                        },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = GoldAccent,
                            unfocusedBorderColor = TextMuted.copy(alpha = 0.5f),
                            focusedTextColor = TextOffWhite,
                            unfocusedTextColor = TextOffWhite
                        ),
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("member_phone_input")
                    )
                }

                item {
                    Text(
                        text = Translations.getString("residencyStatus", isUrdu),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextMuted
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    listOf("Active Qatar", "On Vacation", "Left Qatar for Good").forEach { statusOption ->
                        val optionLabelKey = when (statusOption) {
                            "Active Qatar" -> "statusActive"
                            "On Vacation" -> "statusVacation"
                            else -> "statusLeft"
                        }

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { status = statusOption }
                                .padding(vertical = 4.dp)
                        ) {
                            RadioButton(
                                selected = status == statusOption,
                                onClick = { status = statusOption },
                                colors = RadioButtonDefaults.colors(selectedColor = GoldAccent)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = Translations.getString(optionLabelKey, isUrdu),
                                color = TextOffWhite,
                                fontSize = 13.sp
                            )
                        }
                    }
                }

                item {
                    Text(
                        text = Translations.getString("contributionCycle", isUrdu),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextMuted
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        listOf(
                            Translations.getString("year1", isUrdu) to y1 to { v: Boolean -> y1 = v },
                            Translations.getString("year2", isUrdu) to y2 to { v: Boolean -> y2 = v },
                            Translations.getString("year3", isUrdu) to y3 to { v: Boolean -> y3 = v }
                        ).forEach { (pair, setter) ->
                            val (label, checked) = pair
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .weight(1f)
                                    .border(1.dp, TextMuted.copy(alpha = 0.15f), RoundedCornerShape(4.dp))
                                    .clickable { setter(!checked) }
                                    .padding(horizontal = 4.dp, vertical = 2.dp)
                            ) {
                                Checkbox(
                                    checked = checked,
                                    onCheckedChange = { setter(it) },
                                    colors = CheckboxDefaults.colors(checkedColor = EmeraldPrimary),
                                    modifier = Modifier.size(24.dp)
                                )
                                Spacer(modifier = Modifier.width(1.dp))
                                Text(label, color = TextOffWhite, fontSize = 8.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                            }
                        }
                    }
                }

                item {
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        TextButton(onClick = onDismiss) {
                            Text(Translations.getString("cancel", isUrdu), color = TextMuted)
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Button(
                            enabled = name.isNotBlank() && qid.isNotBlank() && phone.isNotBlank() && phone.length >= 7,
                            onClick = {
                                onSave(name, qid, phone, status, y1, y2, y3)
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = EmeraldPrimary,
                                disabledContainerColor = EmeraldPrimary.copy(alpha = 0.3f)
                            ),
                            modifier = Modifier.testTag("save_member_button")
                        ) {
                            Text(Translations.getString("save", isUrdu), color = Color.White)
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// CUSTODIANS TAB SCREEN
// ==========================================
@Composable
fun CustodiansTabScreen(
    viewModel: TatViewModel,
    custodians: List<Custodian>,
    members: List<Member>,
    poolBalance: Double,
    isAdminMode: Boolean,
    isUrdu: Boolean,
    onHandoverTriggered: (receipt: String, newPassword: String, name: String, phone: String) -> Unit
) {
    var showHandoverModal by remember { mutableStateOf(false) }
    var handoverCheckConfirmed by remember { mutableStateOf(false) }
    var showAssignModal by remember { mutableStateOf(false) }
    var showEditCustodianDialog by remember { mutableStateOf<Custodian?>(null) }

    val activeCustodian = custodians.firstOrNull { it.isCurrent }
    val nextInLine = custodians.filter { !it.isCurrent && it.startDate > (activeCustodian?.endDate ?: 0L) }
        .minByOrNull { it.orderIndex }
        ?: custodians.firstOrNull { !it.isCurrent }

    val df = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 80.dp)
    ) {
        // Cash Pool Summary Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = EmeraldPrimary),
                shape = RoundedCornerShape(16.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = Translations.getString("totalPool", isUrdu),
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White.copy(alpha = 0.85f)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "${String.format(Locale.US, "%,.2f", poolBalance)} QAR",
                        fontSize = 32.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = GoldAccent
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Divider(color = Color.White.copy(alpha = 0.15f))
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(Translations.getString("currentHolder", isUrdu), fontSize = 10.sp, color = Color.White.copy(alpha = 0.7f), maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
                            Text(activeCustodian?.name ?: "No Custodian", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
                        }
                        Column(horizontalAlignment = Alignment.End, modifier = Modifier.weight(1f)) {
                            Text(if (isUrdu) "واٹس ایپ نمبر" else "WhatsApp Number", fontSize = 10.sp, color = Color.White.copy(alpha = 0.7f), maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
                            Text(activeCustodian?.phone ?: "N/A", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
                        }
                    }
                    if (activeCustodian?.password?.isNotEmpty() == true) {
                        Spacer(modifier = Modifier.height(12.dp))
                        Card(
                            colors = CardDefaults.cardColors(containerColor = EmeraldDark),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(8.dp).fillMaxWidth(),
                                horizontalArrangement = Arrangement.Center,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(imageVector = Icons.Default.Info, contentDescription = "Demo Info", tint = GoldAccent, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Demo Password: ${activeCustodian.password}", fontSize = 12.sp, color = Color.White, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }

        // Active Trust Banner
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = DarkSlateSurface),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, GoldAccent.copy(alpha = 0.3f))
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = "Pillar AMANAT",
                        tint = GoldAccent,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = if (isUrdu) {
                            "ستون امانت: فنڈ کے کیش کی جسمانی تحویل 3 ماہ کی باری کے ساتھ امانت دار نگران کے پاس رہتی ہے۔ کوئی بینک اکاؤنٹ استعمال نہیں ہوتا۔"
                        } else {
                            "Pillar AMANAT: Physical cash is strictly held by trusted community custodians on 3-month rotations. No bank account used."
                        },
                        fontSize = 11.sp,
                        color = TextOffWhite
                    )
                }
            }
        }

        // Handover Buttons (Only for Administrators)
        if (isAdminMode) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth().height(androidx.compose.foundation.layout.IntrinsicSize.Min),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = { showHandoverModal = true },
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .testTag("handover_pool_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "Handover",
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = Translations.getString("handoverPool", isUrdu),
                            color = Color.White,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            lineHeight = 12.sp,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                    }

                    Button(
                        onClick = { showAssignModal = true },
                        colors = ButtonDefaults.buttonColors(containerColor = DarkSlateSurfaceVariant),
                        border = BorderStroke(1.dp, GoldAccent),
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .testTag("assign_custodian_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = "Assign Future",
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = Translations.getString("futureCustodian", isUrdu),
                            color = TextOffWhite,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            lineHeight = 12.sp,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                    }
                }
            }
        }

        // Custodian Queue header
        item {
            Text(
                text = Translations.getString("rotationSchedule", isUrdu),
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = GoldAccent,
                modifier = Modifier.padding(top = 8.dp)
            )
        }

        // Rotation hierarchy
        items(custodians) { custodian ->
            val isCurrent = custodian.isCurrent
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = if (isCurrent) DarkSlateSurfaceVariant else DarkSlateSurface
                ),
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(1.dp, if (isCurrent) GoldAccent else TextMuted.copy(alpha = 0.1f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(14.dp).fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .background(
                                    if (isCurrent) EmeraldPrimary else DarkSlateSurfaceVariant,
                                    CircleShape
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = (custodian.orderIndex + 1).toString(),
                                color = if (isCurrent) GoldAccent else TextMuted,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = custodian.name,
                                color = if (isCurrent) GoldAccent else TextOffWhite,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "${df.format(Date(custodian.startDate))} - ${df.format(Date(custodian.endDate))}",
                                color = TextMuted,
                                fontSize = 10.sp
                            )
                        }
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {

                        if (isAdminMode) {
                            val idx = custodians.indexOf(custodian)
                            if (idx > 0) {
                                IconButton(
                                    onClick = {
                                        val prevCust = custodians[idx - 1]
                                        val tempOrder = custodian.orderIndex
                                        viewModel.updateCustodian(custodian.copy(orderIndex = prevCust.orderIndex))
                                        viewModel.updateCustodian(prevCust.copy(orderIndex = tempOrder))
                                    },
                                    modifier = Modifier.size(24.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.ArrowUpward,
                                        contentDescription = "Move Up",
                                        tint = GoldAccent,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(4.dp))
                            }

                            if (idx < custodians.size - 1) {
                                IconButton(
                                    onClick = {
                                        val nextCust = custodians[idx + 1]
                                        val tempOrder = custodian.orderIndex
                                        viewModel.updateCustodian(custodian.copy(orderIndex = nextCust.orderIndex))
                                        viewModel.updateCustodian(nextCust.copy(orderIndex = tempOrder))
                                    },
                                    modifier = Modifier.size(24.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.ArrowDownward,
                                        contentDescription = "Move Down",
                                        tint = GoldAccent,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(4.dp))
                            }

                            IconButton(
                                onClick = { showEditCustodianDialog = custodian },
                                modifier = Modifier
                                    .size(24.dp)
                                    .testTag("edit_custodian_${custodian.id}")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Edit,
                                    contentDescription = "Edit Custodian",
                                    tint = GoldAccent,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(4.dp))

                            var showDeleteConfirm by remember { mutableStateOf(false) }
                            IconButton(
                                onClick = { showDeleteConfirm = true },
                                modifier = Modifier
                                    .size(24.dp)
                                    .testTag("delete_custodian_${custodian.id}")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Delete,
                                    contentDescription = "Delete Custodian",
                                    tint = RedForfeited,
                                    modifier = Modifier.size(16.dp)
                                )
                            }

                            if (showDeleteConfirm) {
                                Dialog(onDismissRequest = { showDeleteConfirm = false }) {
                                    Card(
                                        colors = CardDefaults.cardColors(containerColor = DarkSlateSurface),
                                        shape = RoundedCornerShape(12.dp),
                                        border = BorderStroke(1.dp, RedForfeited.copy(alpha = 0.5f)),
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(16.dp)
                                    ) {
                                        Column(
                                            modifier = Modifier.padding(16.dp),
                                            horizontalAlignment = Alignment.CenterHorizontally
                                        ) {
                                            Text(
                                                text = Translations.getString("deleteCustodianTitle", isUrdu),
                                                color = RedForfeited,
                                                fontSize = 16.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                            Spacer(modifier = Modifier.height(10.dp))
                                            Text(
                                                text = Translations.getString("confirmDeleteCustodian", isUrdu),
                                                color = TextOffWhite,
                                                fontSize = 13.sp,
                                                textAlign = TextAlign.Center
                                            )
                                            Spacer(modifier = Modifier.height(16.dp))
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.End
                                            ) {
                                                TextButton(onClick = { showDeleteConfirm = false }) {
                                                    Text(Translations.getString("cancel", isUrdu), color = TextMuted)
                                                }
                                                Spacer(modifier = Modifier.width(12.dp))
                                                Button(
                                                    onClick = {
                                                        viewModel.deleteCustodian(custodian)
                                                        showDeleteConfirm = false
                                                    },
                                                    colors = ButtonDefaults.buttonColors(containerColor = RedForfeited)
                                                ) {
                                                    Text(Translations.getString("delete", isUrdu), color = Color.White)
                                                }
                                            }
                        if (isCurrent) {
                            Spacer(modifier = Modifier.width(8.dp))
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(EmeraldPrimary)
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = Translations.getString("currentHolder", isUrdu),
                                    fontSize = 8.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            }
                        }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // --- HANDOVER POOL CONFIRMATION DIALOG ---
    if (showHandoverModal && activeCustodian != null && nextInLine != null) {
        Dialog(onDismissRequest = { showHandoverModal = false }) {
            Card(
                colors = CardDefaults.cardColors(containerColor = DarkSlateSurface),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(2.dp, GoldAccent),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
                    .testTag("handover_confirm_dialog")
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = "Handover",
                        tint = GoldAccent,
                        modifier = Modifier.size(36.dp)
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                    Text(
                        text = Translations.getString("confirmHandover", isUrdu),
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextOffWhite
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = if (isUrdu) {
                            "آپ امانت فنڈ کی چابی نگران ${activeCustodian.name} سے نگران ${nextInLine.name} کو منتقل کر رہے ہیں۔"
                        } else {
                            "You are passing the sacred fund custody from ${activeCustodian.name} to the incoming custodian ${nextInLine.name}."
                        },
                        fontSize = 12.sp,
                        color = TextOffWhite.copy(alpha = 0.9f),
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Card(
                        colors = CardDefaults.cardColors(containerColor = EmeraldDark),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = "${Translations.getString("totalPool", isUrdu)}: ${String.format(Locale.US, "%,.2f", poolBalance)} QAR",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = GoldAccent,
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Confirmation Checkbox
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { handoverCheckConfirmed = !handoverCheckConfirmed },
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(
                            checked = handoverCheckConfirmed,
                            onCheckedChange = { handoverCheckConfirmed = it },
                            colors = CheckboxDefaults.colors(checkedColor = EmeraldPrimary),
                            modifier = Modifier.testTag("handover_checkbox_confirm")
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = Translations.getString("handoverConfirmCheck", isUrdu)
                                .format(String.format(Locale.US, "%,.2f", poolBalance), nextInLine.name),
                            fontSize = 10.sp,
                            color = TextOffWhite
                        )
                    }

                    Spacer(modifier = Modifier.height(24.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        TextButton(onClick = {
                            showHandoverModal = false
                            handoverCheckConfirmed = false
                        }) {
                            Text(Translations.getString("cancel", isUrdu), color = TextMuted)
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Button(
                            enabled = handoverCheckConfirmed,
                            onClick = {
                                viewModel.performHandover(poolBalance) { receipt, newPass, name, phone ->
                                    onHandoverTriggered(receipt, newPass, name, phone)
                                    showHandoverModal = false
                                    handoverCheckConfirmed = false
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                            modifier = Modifier.testTag("complete_handover_submit")
                        ) {
                            Text(Translations.getString("handoverPool", isUrdu).substringBefore(" "), color = Color.White)
                        }
                    }
                }
            }
        }
    }

    // --- ASSIGN FUTURE CUSTODIAN DIALOG ---
    if (showAssignModal) {
        var selectedMember by remember { mutableStateOf<Member?>(null) }
        var dropdownExpanded by remember { mutableStateOf(false) }

        var startDateMs by remember { mutableStateOf(System.currentTimeMillis()) }
        var endDateMs by remember {
            mutableStateOf(
                Calendar.getInstance().apply {
                    timeInMillis = System.currentTimeMillis()
                    add(Calendar.MONTH, 3)
                }.timeInMillis
            )
        }

        val context = LocalContext.current
        val dfShow = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())

        Dialog(onDismissRequest = { showAssignModal = false }) {
            Card(
                colors = CardDefaults.cardColors(containerColor = DarkSlateSurface),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, GoldAccent),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
                    .testTag("assign_custodian_dialog")
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = Translations.getString("futureCustodian", isUrdu),
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = GoldAccent
                    )
                    Spacer(modifier = Modifier.height(16.dp))

                    // Simulated Select Member Trigger
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, TextMuted.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                            .clickable { dropdownExpanded = true }
                            .padding(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = selectedMember?.name ?: Translations.getString("membersTab", isUrdu),
                                color = if (selectedMember != null) TextOffWhite else TextMuted
                            )
                            Icon(imageVector = Icons.Default.KeyboardArrowDown, contentDescription = "Dropdown", tint = GoldAccent)
                        }
                    }

                    if (dropdownExpanded) {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = DarkSlateSurfaceVariant),
                            border = BorderStroke(1.dp, TextMuted.copy(alpha = 0.2f)),
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(max = 150.dp)
                                .padding(vertical = 4.dp)
                        ) {
                            LazyColumn {
                                items(members.filter { it.status != "Left Qatar for Good" }) { mem ->
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable {
                                                selectedMember = mem
                                                dropdownExpanded = false
                                            }
                                            .padding(12.dp)
                                    ) {
                                        Text(text = mem.name, color = TextOffWhite, fontSize = 13.sp)
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // From Date Selector
                    Text(
                        text = Translations.getString("fromDate", isUrdu),
                        color = GoldAccent,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.align(Alignment.Start)
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, TextMuted.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                            .clickable {
                                val cal = Calendar.getInstance().apply { timeInMillis = startDateMs }
                                android.app.DatePickerDialog(
                                    context,
                                    { _, year, month, dayOfMonth ->
                                        val newCal = Calendar.getInstance()
                                        newCal.set(year, month, dayOfMonth)
                                        startDateMs = newCal.timeInMillis
                                    },
                                    cal.get(Calendar.YEAR),
                                    cal.get(Calendar.MONTH),
                                    cal.get(Calendar.DAY_OF_MONTH)
                                ).show()
                            }
                            .padding(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(text = dfShow.format(Date(startDateMs)), color = TextOffWhite)
                            Icon(imageVector = Icons.Default.DateRange, contentDescription = "Calendar", tint = GoldAccent)
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // To Date Selector
                    Text(
                        text = Translations.getString("toDate", isUrdu),
                        color = GoldAccent,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.align(Alignment.Start)
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, TextMuted.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                            .clickable {
                                val cal = Calendar.getInstance().apply { timeInMillis = endDateMs }
                                android.app.DatePickerDialog(
                                    context,
                                    { _, year, month, dayOfMonth ->
                                        val newCal = Calendar.getInstance()
                                        newCal.set(year, month, dayOfMonth)
                                        endDateMs = newCal.timeInMillis
                                    },
                                    cal.get(Calendar.YEAR),
                                    cal.get(Calendar.MONTH),
                                    cal.get(Calendar.DAY_OF_MONTH)
                                ).show()
                            }
                            .padding(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(text = dfShow.format(Date(endDateMs)), color = TextOffWhite)
                            Icon(imageVector = Icons.Default.DateRange, contentDescription = "Calendar", tint = GoldAccent)
                        }
                    }

                    Spacer(modifier = Modifier.height(24.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        TextButton(onClick = { showAssignModal = false }) {
                            Text(Translations.getString("cancel", isUrdu), color = TextMuted)
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Button(
                            enabled = selectedMember != null,
                            onClick = {
                                val m = selectedMember!!
                                val nextIndex = custodians.size

                                viewModel.addCustodian(
                                    name = m.name,
                                    phone = m.phone,
                                    startDate = startDateMs,
                                    endDate = endDateMs,
                                    orderIndex = nextIndex,
                                    password = ""
                                )
                                showAssignModal = false
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                            modifier = Modifier.testTag("submit_assign_custodian")
                        ) {
                            Text(Translations.getString("assign", isUrdu), color = Color.White)
                        }
                    }
                }
            }
        }
    }

    if (showEditCustodianDialog != null) {
        val custodianToEdit = showEditCustodianDialog!!
        var editName by remember(custodianToEdit) { mutableStateOf(custodianToEdit.name) }
        var editStartDateMs by remember(custodianToEdit) { mutableStateOf(custodianToEdit.startDate) }
        var editEndDateMs by remember(custodianToEdit) { mutableStateOf(custodianToEdit.endDate) }

        val context = LocalContext.current
        val dfShow = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())

        Dialog(onDismissRequest = { showEditCustodianDialog = null }) {
            Card(
                colors = CardDefaults.cardColors(containerColor = DarkSlateSurface),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, GoldAccent),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = if (isUrdu) "نگران کی معلومات تبدیل کریں" else "Edit Custodian",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = GoldAccent
                    )
                    Spacer(modifier = Modifier.height(16.dp))

                    OutlinedTextField(
                        value = editName,
                        onValueChange = { editName = it },
                        label = { Text(if (isUrdu) "نگران کا نام" else "Custodian Name", color = TextMuted) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = GoldAccent,
                            unfocusedBorderColor = TextMuted.copy(alpha = 0.4f),
                            focusedTextColor = TextOffWhite,
                            unfocusedTextColor = TextOffWhite
                        ),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // From Date Selector
                    Text(
                        text = Translations.getString("fromDate", isUrdu),
                        color = GoldAccent,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.align(Alignment.Start)
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, TextMuted.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                            .clickable {
                                val cal = Calendar.getInstance().apply { timeInMillis = editStartDateMs }
                                android.app.DatePickerDialog(
                                    context,
                                    { _, year, month, dayOfMonth ->
                                        val newCal = Calendar.getInstance()
                                        newCal.set(year, month, dayOfMonth)
                                        editStartDateMs = newCal.timeInMillis
                                    },
                                    cal.get(Calendar.YEAR),
                                    cal.get(Calendar.MONTH),
                                    cal.get(Calendar.DAY_OF_MONTH)
                                ).show()
                            }
                            .padding(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(text = dfShow.format(Date(editStartDateMs)), color = TextOffWhite)
                            Icon(imageVector = Icons.Default.DateRange, contentDescription = "Calendar", tint = GoldAccent)
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // To Date Selector
                    Text(
                        text = Translations.getString("toDate", isUrdu),
                        color = GoldAccent,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.align(Alignment.Start)
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, TextMuted.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                            .clickable {
                                val cal = Calendar.getInstance().apply { timeInMillis = editEndDateMs }
                                android.app.DatePickerDialog(
                                    context,
                                    { _, year, month, dayOfMonth ->
                                        val newCal = Calendar.getInstance()
                                        newCal.set(year, month, dayOfMonth)
                                        editEndDateMs = newCal.timeInMillis
                                    },
                                    cal.get(Calendar.YEAR),
                                    cal.get(Calendar.MONTH),
                                    cal.get(Calendar.DAY_OF_MONTH)
                                ).show()
                            }
                            .padding(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(text = dfShow.format(Date(editEndDateMs)), color = TextOffWhite)
                            Icon(imageVector = Icons.Default.DateRange, contentDescription = "Calendar", tint = GoldAccent)
                        }
                    }

                    Spacer(modifier = Modifier.height(24.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        TextButton(onClick = { showEditCustodianDialog = null }) {
                            Text(Translations.getString("cancel", isUrdu), color = TextMuted)
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Button(
                            enabled = editName.isNotBlank(),
                            onClick = {
                                val updated = custodianToEdit.copy(
                                    name = editName,
                                    startDate = editStartDateMs,
                                    endDate = editEndDateMs
                                )
                                viewModel.updateCustodian(updated)
                                showEditCustodianDialog = null
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
                        ) {
                            Text(if (isUrdu) "محفوظ کریں" else "Save", color = Color.White)
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// CLAIMS TAB SCREEN
// ==========================================
@Composable
fun ClaimsTabScreen(
    viewModel: TatViewModel,
    claims: List<Claim>,
    members: List<Member>,
    isAdminMode: Boolean,
    isUrdu: Boolean
) {
    val lastFullyCheckedYearAmount = remember(members) {
        val totalMembers = members.size
        if (totalMembers == 0) 0.0
        else {
            val year3FullyPaid = members.isNotEmpty() && members.all { it.year3Paid }
            val year2FullyPaid = members.isNotEmpty() && members.all { it.year2Paid }
            val year1FullyPaid = members.isNotEmpty() && members.all { it.year1Paid }
            when {
                year3FullyPaid -> members.count { it.year3Paid } * 200.0
                year2FullyPaid -> members.count { it.year2Paid } * 200.0
                year1FullyPaid -> members.count { it.year1Paid } * 200.0
                else -> totalMembers * 200.0
            }
        }
    }

    var deceasedName by remember { mutableStateOf("") }
    var deceasedQid by remember { mutableStateOf("") }
    var residencyStatus by remember { mutableStateOf("Active Qatar") }
    var dropdownExpanded by remember { mutableStateOf(false) }
    val initialScenario = "Scenario A: Burial in Qatar (Cap ${String.format(Locale.US, "%,d", lastFullyCheckedYearAmount.toInt())} QAR)"
    var selectedScenario by remember(lastFullyCheckedYearAmount) { mutableStateOf(initialScenario) }
    var actualExpensesStr by remember { mutableStateOf("") }

    var auditTextResult by remember { mutableStateOf<String?>(null) }
    var auditingActiveClaim by remember { mutableStateOf<Claim?>(null) }

    val isAuditorLoading by viewModel.isAuditorLoading.collectAsStateWithLifecycle()

    val currentCap = when {
        selectedScenario.contains("Scenario A") -> lastFullyCheckedYearAmount
        selectedScenario.contains("Scenario B") -> lastFullyCheckedYearAmount
        selectedScenario.contains("Scenario C") -> lastFullyCheckedYearAmount
        else -> 0.0
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 80.dp)
    ) {
        // Taqseem Pillar Header
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = DarkSlateSurface),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, GoldAccent.copy(alpha = 0.3f))
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = "Pillar TAQSEEM",
                        tint = GoldAccent,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = if (isUrdu) {
                            "ستون تقسیم: تجہیز و تکفین کے اخراجات پہلے ادا کیے جاتے ہیں۔ قطع نظر اس کے کہ کتنے سال کے فنڈز جمع کیے گئے ہوں، کلیم کی ادائیگی متعلقہ منظر نامے کے صرف ایک سال کی حد (ون ٹائم بینیفٹ کیپ) تک محدود رہے گی۔ بچ جانے والا بقایا فوت شدہ کے خاندان کو ملتا ہے، اور خسارہ اگلے سال کے فنڈ سے پورا کیا جاتا ہے۔"
                        } else {
                            "Pillar TAQSEEM: Actual funeral costs are covered first against benefit caps. Regardless of the number of contribution years collected (e.g. 3 years), the benefit payout is strictly capped at one year's worth of the corresponding scenario cap. Remaining surplus is paid to family; deficit is recovered next year."
                        },
                        fontSize = 11.sp,
                        color = TextOffWhite
                    )
                }
            }
        }

        if (isAdminMode) {
            // Form to log a Claim
            item {
                Card(
                colors = CardDefaults.cardColors(containerColor = DarkSlateSurface),
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(1.dp, TextMuted.copy(alpha = 0.15f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = Translations.getString("claimFormTitle", isUrdu),
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = GoldAccent
                    )
                    Spacer(modifier = Modifier.height(12.dp))



                    Box(modifier = Modifier.fillMaxWidth()) {
                        OutlinedTextField(
                            value = deceasedName,
                            onValueChange = {},
                            readOnly = true,
                            enabled = isAdminMode,
                            label = { Text(Translations.getString("deceasedName", isUrdu), color = TextMuted) },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = GoldAccent,
                                unfocusedBorderColor = TextMuted.copy(alpha = 0.4f),
                                disabledTextColor = TextOffWhite,
                                disabledBorderColor = TextMuted.copy(alpha = 0.4f),
                                disabledLabelColor = TextMuted,
                                focusedTextColor = TextOffWhite,
                                unfocusedTextColor = TextOffWhite
                            ),
                            singleLine = true,
                            trailingIcon = {
                                if (isAdminMode) {
                                    IconButton(onClick = { dropdownExpanded = true }) {
                                        Icon(imageVector = Icons.Default.ArrowDropDown, contentDescription = "Dropdown", tint = GoldAccent)
                                    }
                                }
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable(enabled = isAdminMode) { dropdownExpanded = true }
                                .testTag("deceased_name_input")
                        )

                        DropdownMenu(
                            expanded = dropdownExpanded && isAdminMode,
                            onDismissRequest = { dropdownExpanded = false },
                            modifier = Modifier
                                .fillMaxWidth(0.85f)
                                .background(DarkSlateSurface)
                                .border(1.dp, GoldAccent.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                        ) {
                            val sortedMembers = members.sortedBy { it.name }
                            if (sortedMembers.isEmpty()) {
                                DropdownMenuItem(
                                    text = { Text(if (isUrdu) "کوئی ممبر دستیاب نہیں" else "No members available", color = TextMuted) },
                                    onClick = {}
                                )
                            } else {
                                sortedMembers.forEach { mem ->
                                    DropdownMenuItem(
                                        text = {
                                            Column {
                                                Text(text = mem.name, color = TextOffWhite, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                                Text(text = "QID: ${mem.qid} | ${mem.status}", color = TextMuted, fontSize = 11.sp)
                                            }
                                        },
                                        onClick = {
                                            deceasedName = mem.name
                                            deceasedQid = mem.qid
                                            residencyStatus = mem.status
                                            dropdownExpanded = false
                                        }
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        enabled = false, // Automatically filled based on member selection
                        value = deceasedQid,
                        onValueChange = {},
                        label = { Text(Translations.getString("qid", isUrdu), color = TextMuted) },
                        colors = OutlinedTextFieldDefaults.colors(
                            disabledTextColor = TextOffWhite,
                            disabledBorderColor = TextMuted.copy(alpha = 0.2f),
                            disabledLabelColor = TextMuted
                        ),
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("deceased_qid_input")
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(Translations.getString("residencyStatus", isUrdu), fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextMuted)
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf("Active Qatar", "On Vacation", "Left Qatar for Good").forEach { opt ->
                            val isSel = residencyStatus == opt
                            Surface(
                                onClick = { residencyStatus = opt },
                                enabled = isAdminMode,
                                color = if (isSel) EmeraldPrimary.copy(alpha = 0.2f) else Color.Transparent,
                                border = BorderStroke(1.dp, if (isSel) EmeraldPrimary else TextMuted.copy(alpha = 0.3f)),
                                shape = RoundedCornerShape(6.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(
                                    text = when (opt) {
                                        "Active Qatar" -> Translations.getString("statusActive", isUrdu)
                                        "On Vacation" -> Translations.getString("statusVacation", isUrdu)
                                        else -> Translations.getString("statusLeft", isUrdu)
                                    },
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isSel) TextOffWhite else TextMuted,
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.padding(vertical = 8.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(Translations.getString("selectScenario", isUrdu), fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextMuted)
                    Spacer(modifier = Modifier.height(4.dp))

                    val lastFullyCheckedYearAmountStr = String.format(Locale.US, "%,d", lastFullyCheckedYearAmount.toInt())
                    listOf(
                        "Scenario A: Burial in Qatar (Cap $lastFullyCheckedYearAmountStr QAR)" to (if (isUrdu) "منظر نامہ A: قطر میں تدفین (حد $lastFullyCheckedYearAmountStr ریال)" else "Scenario A: Burial in Qatar (Cap $lastFullyCheckedYearAmountStr QAR)"),
                        "Scenario B: Repatriation to Pakistan (Cap $lastFullyCheckedYearAmountStr QAR)" to (if (isUrdu) "منظر نامہ B: پاکستان واپسی (حد $lastFullyCheckedYearAmountStr ریال)" else "Scenario B: Repatriation to Pakistan (Cap $lastFullyCheckedYearAmountStr QAR)"),
                        "Scenario C: Vacation Death in Pakistan (Cap $lastFullyCheckedYearAmountStr QAR)" to (if (isUrdu) "منظر نامہ C: پاکستان میں چھٹی کے دوران انتقال (حد $lastFullyCheckedYearAmountStr ریال)" else "Scenario C: Vacation Death in Pakistan (Cap $lastFullyCheckedYearAmountStr QAR)"),
                        "Scenario D: Permanent Exit / Left Qatar (Cap 0 QAR)" to (if (isUrdu) "منظر نامہ D: مستقل خروج / قطر چھوڑ دیا (حد 0 ریال)" else "Scenario D: Permanent Exit / Left Qatar (Cap 0 QAR)")
                    ).forEach { (valStr, dispStr) ->
                        val isSel = selectedScenario == valStr
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable(enabled = isAdminMode) { selectedScenario = valStr }
                                .padding(vertical = 3.dp)
                        ) {
                            RadioButton(
                                enabled = isAdminMode,
                                selected = isSel,
                                onClick = { selectedScenario = valStr },
                                colors = RadioButtonDefaults.colors(selectedColor = GoldAccent)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(text = dispStr, fontSize = 11.sp, color = TextOffWhite)
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        enabled = isAdminMode,
                        value = actualExpensesStr,
                        onValueChange = { actualExpensesStr = it },
                        label = { Text(Translations.getString("actualExpenses", isUrdu), color = TextMuted) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = GoldAccent,
                            unfocusedBorderColor = TextMuted.copy(alpha = 0.4f),
                            focusedTextColor = TextOffWhite,
                            unfocusedTextColor = TextOffWhite
                        ),
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("expenses_input")
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    if (isAdminMode) {
                        Button(
                            onClick = {
                                val exp = actualExpensesStr.toDoubleOrNull() ?: 0.0
                                viewModel.auditClaimWithGemini(
                                    deceasedName = deceasedName,
                                    deceasedQid = deceasedQid,
                                    residencyStatus = residencyStatus,
                                    scenario = selectedScenario,
                                    allocatedCap = currentCap,
                                    actualExpenses = exp
                                ) { auditedClaim ->
                                    auditingActiveClaim = auditedClaim
                                    auditTextResult = auditedClaim.auditRuling
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                            enabled = deceasedName.isNotBlank() && deceasedQid.isNotBlank() && !isAuditorLoading,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("run_audit_button")
                        ) {
                            if (isAuditorLoading) {
                                CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp, color = Color.White)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(Translations.getString("auditingInProgress", isUrdu), color = Color.White, fontSize = 12.sp)
                            } else {
                                Icon(imageVector = Icons.Default.Check, contentDescription = "Audit")
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(Translations.getString("executeAudit", isUrdu), color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }

        // Audit Result Area (If generated)
            if (auditTextResult != null && auditingActiveClaim != null) {
                item {
                    Card(
                    colors = CardDefaults.cardColors(containerColor = DarkSlateSurfaceVariant),
                    border = BorderStroke(2.dp, GoldAccent),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = Translations.getString("auditResult", isUrdu),
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = GoldAccent
                            )
                            IconButton(onClick = {
                                auditTextResult = null
                                auditingActiveClaim = null
                            }) {
                                Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = RedForfeited)
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = auditTextResult!!,
                            fontSize = 12.sp,
                            color = TextOffWhite,
                            lineHeight = 18.sp
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        // Save Claim to History button
                        Button(
                            onClick = {
                                viewModel.addClaim(auditingActiveClaim!!)
                                // Reset form
                                deceasedName = ""
                                deceasedQid = ""
                                actualExpensesStr = ""
                                auditTextResult = null
                                auditingActiveClaim = null
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("save_claim_history_button")
                        ) {
                            Text(Translations.getString("save", isUrdu), color = Color.White)
                        }
                    }
                }
            }
        }
        }

        // Historical Claims Header
        item {
            Text(
                text = Translations.getString("viewHistory", isUrdu),
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = GoldAccent,
                modifier = Modifier.padding(top = 12.dp)
            )
        }

        if (claims.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = Translations.getString("noClaims", isUrdu), color = TextMuted, fontSize = 13.sp)
                }
            }
        } else {
            items(claims) { claim ->
                HistoricalClaimCard(
                    claim = claim,
                    isAdminMode = isAdminMode,
                    isUrdu = isUrdu,
                    onDelete = { viewModel.deleteClaim(claim) }
                )
            }
        }
    }
}

@Composable
fun HistoricalClaimCard(
    claim: Claim,
    isAdminMode: Boolean,
    isUrdu: Boolean,
    onDelete: () -> Unit
) {
    var expanded by remember { mutableStateOf(false) }
    val df = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())
    var showConfirmDelete by remember { mutableStateOf(false) }

    if (showConfirmDelete) {
        androidx.compose.ui.window.Dialog(onDismissRequest = { showConfirmDelete = false }) {
            Card(
                colors = CardDefaults.cardColors(containerColor = DarkSlateSurface),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, GoldAccent),
                modifier = Modifier.padding(16.dp)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = if (isUrdu) "کلیم حذف کریں؟" else "Delete Claim?",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = GoldAccent
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = if (isUrdu) 
                            "کیا آپ واقعی کلیم \"${claim.deceasedName}\" کو مستقل طور پر حذف کرنا چاہتے ہیں؟"
                        else 
                            "Are you sure you want to permanently delete claim \"${claim.deceasedName}\"?",
                        fontSize = 14.sp,
                        color = TextOffWhite,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(20.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        TextButton(onClick = { showConfirmDelete = false }) {
                            Text(if (isUrdu) "منسوخ کریں" else "Cancel", color = TextMuted)
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Button(
                            onClick = {
                                onDelete()
                                showConfirmDelete = false
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = RedForfeited)
                        ) {
                            Text(if (isUrdu) "حذف کریں" else "Delete", color = Color.White)
                        }
                    }
                }
            }
        }
    }

    Card(
        colors = CardDefaults.cardColors(containerColor = DarkSlateSurface),
        border = BorderStroke(1.dp, TextMuted.copy(alpha = if (isSystemInDarkTheme) 0.15f else 0.4f)),
        shape = RoundedCornerShape(10.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("historical_claim_${claim.id}")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = claim.deceasedName,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextOffWhite
                    )
                    Text(
                        text = "QID: ${claim.deceasedQid} • ${df.format(Date(claim.dateLogged))}",
                        fontSize = 10.sp,
                        color = TextMuted
                    )
                }

                // Delete button for Admin
                if (isAdminMode) {
                    IconButton(
                        onClick = { showConfirmDelete = true },
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Delete, contentDescription = "Delete claim", tint = RedForfeited, modifier = Modifier.size(16.dp))
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = claim.scenario,
                fontSize = 11.sp,
                color = GoldAccent,
                fontWeight = FontWeight.Medium
            )

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .background(DarkSlateSurfaceVariant, RoundedCornerShape(6.dp))
                        .padding(8.dp)
                ) {
                    Text("Cap", fontSize = 9.sp, color = TextMuted)
                    Text("${String.format(Locale.US, "%,.0f", claim.allocatedCap)} QAR", fontSize = 12.sp, color = TextOffWhite, fontWeight = FontWeight.Bold)
                }

                Column(
                    modifier = Modifier
                        .weight(1f)
                        .background(DarkSlateSurfaceVariant, RoundedCornerShape(6.dp))
                        .padding(8.dp)
                ) {
                    Text("Expenses", fontSize = 9.sp, color = TextMuted)
                    Text("${String.format(Locale.US, "%,.0f", claim.actualExpenses)} QAR", fontSize = 12.sp, color = TextOffWhite, fontWeight = FontWeight.Bold)
                }

                if (claim.surplusHandover > 0) {
                    Column(
                        modifier = Modifier
                            .weight(1.2f)
                            .background(EmeraldPrimary.copy(alpha = 0.15f), RoundedCornerShape(6.dp))
                            .border(1.dp, EmeraldPrimary.copy(alpha = 0.3f), RoundedCornerShape(6.dp))
                            .padding(8.dp)
                    ) {
                        Text(Translations.getString("surplusToFamily", isUrdu), fontSize = 8.sp, color = EmeraldLight, fontWeight = FontWeight.Bold)
                        Text("${String.format(Locale.US, "%,.0f", claim.surplusHandover)} QAR", fontSize = 12.sp, color = TextOffWhite, fontWeight = FontWeight.Bold)
                    }
                } else if (claim.deficitRecoupment > 0) {
                    Column(
                        modifier = Modifier
                            .weight(1.2f)
                            .background(RedForfeited.copy(alpha = 0.15f), RoundedCornerShape(6.dp))
                            .border(1.dp, RedForfeited.copy(alpha = 0.3f), RoundedCornerShape(6.dp))
                            .padding(8.dp)
                    ) {
                        Text(Translations.getString("deficitRecoup", isUrdu), fontSize = 8.sp, color = RedForfeited, fontWeight = FontWeight.Bold)
                        Text("${String.format(Locale.US, "%,.0f", claim.deficitRecoupment)} QAR", fontSize = 12.sp, color = TextOffWhite, fontWeight = FontWeight.Bold)
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Ruling text expander
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { expanded = !expanded }
                    .padding(vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Text(
                    text = if (expanded) "Hide AI Ruling" else "View Official AI Ruling",
                    fontSize = 11.sp,
                    color = GoldAccent,
                    fontWeight = FontWeight.Bold
                )
                Icon(
                    imageVector = if (expanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                    contentDescription = "Expand",
                    tint = GoldAccent,
                    modifier = Modifier.size(16.dp)
                )
            }

            AnimatedVisibility(
                visible = expanded,
                enter = expandVertically() + fadeIn(),
                exit = shrinkVertically() + fadeOut()
            ) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = DarkSlateSurfaceVariant),
                    border = BorderStroke(1.dp, GoldAccent.copy(alpha = 0.3f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp)
                ) {
                    Text(
                        text = claim.auditRuling,
                        fontSize = 11.sp,
                        color = TextOffWhite,
                        lineHeight = 16.sp,
                        modifier = Modifier.padding(12.dp)
                    )
                }
            }
        }
    }
}

// ==========================================
// AI ADVISOR TAB SCREEN
// ==========================================
@Composable
fun AIAdvisorTabScreen(
    viewModel: TatViewModel,
    isUrdu: Boolean,
    speakText: (String, Boolean) -> Unit,
    stopSpeaking: () -> Unit
) {
    val chatHistory by viewModel.chatHistory.collectAsStateWithLifecycle()
    val isAdvisorLoading by viewModel.isAdvisorLoading.collectAsStateWithLifecycle()
    var inputQuery by remember { mutableStateOf("") }
    val context = LocalContext.current

    var shouldSpeakNextReply by remember { mutableStateOf(false) }

    // Launcher for Speech to Text activity
    val speechRecognizerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == android.app.Activity.RESULT_OK) {
            val data = result.data
            val results = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            val spokenText = results?.firstOrNull()
            if (!spokenText.isNullOrBlank()) {
                shouldSpeakNextReply = true
                viewModel.sendChatMessage(spokenText)
            }
        }
    }

    // Launcher for Record Audio runtime permission
    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            try {
                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, if (isUrdu) "ur-PK" else "en-US")
                    putExtra(RecognizerIntent.EXTRA_PROMPT, if (isUrdu) "بات چیت شروع کریں..." else "Start speaking...")
                }
                speechRecognizerLauncher.launch(intent)
            } catch (e: Exception) {
                Toast.makeText(context, "Speech Recognition not supported on this device: ${e.message}", Toast.LENGTH_LONG).show()
            }
        } else {
            Toast.makeText(context, if (isUrdu) "مائیکروفون کی اجازت درکار ہے" else "Microphone permission is required for voice input", Toast.LENGTH_SHORT).show()
        }
    }

    var lastSpokenMessageId by remember { mutableStateOf<String?>(null) }
    var isMuted by remember { mutableStateOf(false) }

    // Observe when AI responds, read out loud automatically in a calm soothing voice
    LaunchedEffect(chatHistory.size) {
        if (chatHistory.isNotEmpty()) {
            val lastMessage = chatHistory.last()
            if (!lastMessage.isUser && lastMessage.id != lastSpokenMessageId) {
                if (!isMuted) {
                    speakText(lastMessage.text, isUrdu)
                }
                lastSpokenMessageId = lastMessage.id
            }
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        // Chat Header with share option
        Card(
            colors = CardDefaults.cardColors(containerColor = DarkSlateSurface),
            shape = RoundedCornerShape(0.dp, 0.dp, 16.dp, 16.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = Translations.getString("advisorTab", isUrdu),
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        color = GoldAccent
                    )
                    Text(
                        text = "Powered by Gemini 3.5 Flash",
                        fontSize = 11.sp,
                        color = TextMuted
                    )
                }
                IconButton(onClick = {
                    isMuted = !isMuted
                    if (isMuted) {
                        stopSpeaking()
                    }
                }) {
                    Icon(
                        imageVector = if (isMuted) Icons.Default.VolumeOff else Icons.Default.VolumeUp,
                        contentDescription = "Mute Toggle",
                        tint = GoldAccent
                    )
                }
            }
        }

        // Messages area
        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            contentPadding = PaddingValues(vertical = 12.dp)
        ) {
            items(chatHistory) { message ->
                ChatBubble(message = message, onSpeakClick = { speakText(message.text, isUrdu) })
            }

            val lastIsUser = chatHistory.lastOrNull()?.isUser == true
            if (isAdvisorLoading && lastIsUser) {
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Start
                    ) {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = DarkSlateSurfaceVariant),
                            shape = RoundedCornerShape(12.dp, 12.dp, 12.dp, 0.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(16.dp),
                                    strokeWidth = 2.dp,
                                    color = GoldAccent
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("AI is thinking...", color = TextMuted, fontSize = 11.sp)
                            }
                        }
                    }
                }
            }
        }

        // Quick action buttons
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            val suggestions = if (isUrdu) {
                listOf("فنڈ کے قواعد", "قسط کی رقم", "کفن دفن کا کلیم")
            } else {
                listOf("What is Tanzeem?", "Benefit Caps", "Physical Custody")
            }

            suggestions.forEach { query ->
                Box(
                    modifier = Modifier
                        .background(DarkSlateSurface, RoundedCornerShape(8.dp))
                        .border(1.dp, TextMuted.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
                        .clickable {
                            inputQuery = if (query.contains("What is Tanzeem")) "Explain the core Three Pillars of Tanzeem Amanat Taqseem."
                            else if (query.contains("Benefit Caps")) "What are the allocated benefit caps for different claims scenarios?"
                            else if (query.contains("Physical Custody")) "How does the rotating physical custody work?"
                            else if (query.contains("قواعد")) "تنظیم کے تین بنیادی ستونوں کی وضاحت کریں۔"
                            else if (query.contains("رقم")) "سالانہ شراکت کی رقم اور دورانیہ کیا ہے؟"
                            else "کفن دفن کلیم کے اصول اور حد کیا ہیں؟"
                        }
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Text(text = query, fontSize = 10.sp, color = GoldAccent, fontWeight = FontWeight.Bold)
                }
            }
        }

        // Input Field Area
        Surface(
            color = DarkSlateSurface,
            tonalElevation = 6.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .navigationBarsPadding()
                    .padding(12.dp)
                    .fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = inputQuery,
                    onValueChange = { inputQuery = it },
                    placeholder = { Text(Translations.getString("aiAdvisorPrompt", isUrdu), color = TextMuted, fontSize = 13.sp) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = GoldAccent,
                        unfocusedBorderColor = TextMuted.copy(alpha = 0.3f),
                        focusedTextColor = TextOffWhite,
                        unfocusedTextColor = TextOffWhite
                    ),
                    shape = RoundedCornerShape(24.dp),
                    singleLine = true,
                    trailingIcon = {
                        IconButton(
                            onClick = {
                                val hasPermission = androidx.core.content.ContextCompat.checkSelfPermission(
                                    context,
                                    android.Manifest.permission.RECORD_AUDIO
                                ) == android.content.pm.PackageManager.PERMISSION_GRANTED

                                if (hasPermission) {
                                    try {
                                        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                                            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                                            putExtra(RecognizerIntent.EXTRA_LANGUAGE, if (isUrdu) "ur-PK" else "en-US")
                                            putExtra(RecognizerIntent.EXTRA_PROMPT, if (isUrdu) "بات چیت شروع کریں..." else "Start speaking...")
                                        }
                                        speechRecognizerLauncher.launch(intent)
                                    } catch (e: Exception) {
                                        Toast.makeText(context, "Speech Recognition not supported: ${e.message}", Toast.LENGTH_LONG).show()
                                    }
                                } else {
                                    permissionLauncher.launch(android.Manifest.permission.RECORD_AUDIO)
                                }
                            },
                            modifier = Modifier.testTag("mic_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Mic,
                                contentDescription = "Voice Input",
                                tint = GoldAccent
                            )
                        }
                    },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("chat_input_field")
                )

                Spacer(modifier = Modifier.width(8.dp))

                FloatingActionButton(
                    onClick = {
                        if (inputQuery.isNotBlank() && !isAdvisorLoading) {
                            viewModel.sendChatMessage(inputQuery)
                            inputQuery = ""
                        }
                    },
                    containerColor = EmeraldPrimary,
                    contentColor = Color.White,
                    shape = CircleShape,
                    modifier = Modifier
                        .size(48.dp)
                        .testTag("send_chat_button")
                ) {
                    Icon(imageVector = Icons.Default.Send, contentDescription = "Send Message", modifier = Modifier.size(20.dp))
                }
            }
        }
    }
}

@Composable
fun formatAndParseMarkdown(text: String, isUser: Boolean, accentColor: Color): androidx.compose.ui.text.AnnotatedString {
    var processed = text
    
    val termsToBold = listOf(
        "Assalamualaikum", "Assalam o Alaikum", "As-salamu alaykum", 
        "Respected Member", "Respected Custodian", "Custodian", 
        "Total Registered Members"
    )
    termsToBold.forEach { term ->
        val regex = Regex("(?<!\\*\\*)$term(?!\\*\\*)", RegexOption.IGNORE_CASE)
        processed = processed.replace(regex) { "**${it.value}**" }
    }
    
    return buildAnnotatedString {
        val lines = processed.split("\n")
        
        for (i in lines.indices) {
            var line = lines[i]
            val trimmedLine = line.trimStart()
            val indentSpaces = line.length - trimmedLine.length
            
            if (trimmedLine.startsWith("* ") || trimmedLine.startsWith("- ")) {
                if (indentSpaces > 0) {
                    append("    ".repeat(indentSpaces / 2 + 1))
                }
                withStyle(SpanStyle(color = if (isUser) Color.White else accentColor, fontWeight = FontWeight.Bold)) {
                    append("•  ")
                }
                line = trimmedLine.drop(2)
            }
            
            val parts = line.split("**")
            for (j in parts.indices) {
                if (j % 2 != 0 && parts.size > 1) { 
                    withStyle(SpanStyle(fontWeight = FontWeight.Bold)) {
                        append(parts[j])
                    }
                } else {
                    val italicParts = parts[j].split("*")
                    for (k in italicParts.indices) {
                        if (k % 2 != 0 && italicParts.size > 1) {
                            withStyle(SpanStyle(fontStyle = FontStyle.Italic)) {
                                append(italicParts[k])
                            }
                        } else {
                            append(italicParts[k])
                        }
                    }
                }
            }
            
            if (i < lines.lastIndex) {
                append("\n")
                // Increase line spacing for non-list items to reduce congestion
                if (line.isNotBlank() && lines[i+1].isNotBlank() && !trimmedLine.startsWith("*") && !trimmedLine.startsWith("-")) {
                   append("\n")
                }
            }
        }
    }
}

@Composable
fun ChatBubble(message: ChatMessage, onSpeakClick: (() -> Unit)? = null) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (message.isUser) Arrangement.End else Arrangement.Start,
        verticalAlignment = Alignment.Bottom
    ) {
        val bubbleColor = if (message.isUser) EmeraldPrimary else DarkSlateSurface
        val borderStroke = if (message.isUser) null else BorderStroke(1.dp, GoldAccent.copy(alpha = 0.3f))
        val shape = if (message.isUser) {
            RoundedCornerShape(12.dp, 12.dp, 0.dp, 12.dp)
        } else {
            RoundedCornerShape(12.dp, 12.dp, 12.dp, 0.dp)
        }

        if (!message.isUser && onSpeakClick != null) {
            IconButton(
                onClick = onSpeakClick,
                modifier = Modifier
                    .padding(end = 4.dp, bottom = 2.dp)
                    .size(28.dp)
                    .testTag("chat_speak_button")
            ) {
                Icon(
                    imageVector = Icons.Default.VolumeUp,
                    contentDescription = "Speak Response",
                    tint = GoldAccent,
                    modifier = Modifier.size(16.dp)
                )
            }
        }

        Surface(
            color = bubbleColor,
            border = borderStroke,
            shape = shape,
            modifier = Modifier
                .widthIn(max = 280.dp)
                .testTag("chat_bubble_${if (message.isUser) "user" else "advisor"}")
        ) {
            Text(
                text = formatAndParseMarkdown(message.text, message.isUser, GoldAccent),
                fontSize = 13.sp,
                color = if (message.isUser) Color.White else TextOffWhite,
                lineHeight = 22.sp,
                modifier = Modifier.padding(16.dp)
            )
        }
    }
}

// --- Helper Models and Methods for CSV Export and Transaction Log ---

data class MemberPayment(
    val id: String,
    val memberName: String,
    val memberPhone: String,
    val yearLabel: String,
    val dateStr: String,
    val dateMs: Long,
    val amount: Double = 200.0
)

fun getPaymentChronologicalList(members: List<Member>): List<MemberPayment> {
    val list = mutableListOf<MemberPayment>()
    val df = java.text.SimpleDateFormat("dd MMM yyyy", java.util.Locale.US)
    for (m in members) {
        if (m.year1Paid) {
            val dStr = m.year1PaymentDate ?: "01 Jan 2026"
            val t = try { df.parse(dStr)?.time ?: 0L } catch (e: Exception) { 0L }
            list.add(MemberPayment("${m.id}_1", m.name, m.phone, "Year 1", dStr, t))
        }
        if (m.year2Paid) {
            val dStr = m.year2PaymentDate ?: "01 Jan 2026"
            val t = try { df.parse(dStr)?.time ?: 0L } catch (e: Exception) { 0L }
            list.add(MemberPayment("${m.id}_2", m.name, m.phone, "Year 2", dStr, t))
        }
        if (m.year3Paid) {
            val dStr = m.year3PaymentDate ?: "01 Jan 2026"
            val t = try { df.parse(dStr)?.time ?: 0L } catch (e: Exception) { 0L }
            list.add(MemberPayment("${m.id}_3", m.name, m.phone, "Year 3", dStr, t))
        }
    }
    return list.sortedByDescending { it.dateMs }
}

fun exportMembersPdf(context: android.content.Context, members: List<Member>, isUrdu: Boolean): java.io.File {
    val title = if (isUrdu) "رپورٹ ممبران" else "Member Ledger"
    val headers = listOf("ID", "Name", "QID", "Phone", "Status", "Year 1", "Year 2", "Year 3")
    val colWeights = listOf(0.05f, 0.2f, 0.15f, 0.2f, 0.1f, 0.1f, 0.1f, 0.1f)
    val df = java.text.SimpleDateFormat("dd MMM yy", java.util.Locale.US)
    val data = members.map { m ->
        val y1Date = if (m.year1Paid && m.year1PaymentDate != null) m.year1PaymentDate else ""
        val y2Date = if (m.year2Paid && m.year2PaymentDate != null) m.year2PaymentDate else ""
        val y3Date = if (m.year3Paid && m.year3PaymentDate != null) m.year3PaymentDate else ""
        
        listOf(
            m.id.toString(),
            m.name,
            m.qid,
            m.phone,
            when(m.status) {
                "Active Qatar" -> "Active"
                "On Vacation" -> "Vacation"
                else -> "Left"
            },
            if (m.year1Paid) "Yes${if (y1Date.isNotEmpty()) "\n$y1Date" else ""}" else "No",
            if (m.year2Paid) "Yes${if (y2Date.isNotEmpty()) "\n$y2Date" else ""}" else "No",
            if (m.year3Paid) "Yes${if (y3Date.isNotEmpty()) "\n$y3Date" else ""}" else "No"
        )
    }
    return generatePdf(context, "TAT_Members_Payment_Summary.pdf", title, headers, data, "orange", colWeights)
}

fun exportCustodiansPdf(context: android.content.Context, custodians: List<Custodian>, isUrdu: Boolean): java.io.File {
    val title = if (isUrdu) "رپورٹ نگران" else "Custodian History"
    val headers = listOf("Index", "Name", "Phone", "Start Date", "End Date", "Status")
    val colWeights = listOf(0.1f, 0.25f, 0.2f, 0.15f, 0.15f, 0.15f)
    val df = java.text.SimpleDateFormat("dd MMM yy", java.util.Locale.US)
    val data = custodians.map { c ->
        val statusStr = when {
            c.isCurrent -> "Active"
            c.startDate > System.currentTimeMillis() -> "Next in line"
            else -> "Past"
        }
        listOf(
            c.orderIndex.toString(),
            c.name,
            c.phone,
            df.format(java.util.Date(c.startDate)),
            df.format(java.util.Date(c.endDate)),
            statusStr
        )
    }
    return generatePdf(context, "TAT_Custodian_Rotation_History.pdf", title, headers, data, "blue", colWeights)
}

fun generatePdf(context: android.content.Context, filename: String, title: String, headers: List<String>, data: List<List<String>>, theme: String, colWeights: List<Float>? = null): java.io.File {
    val pdfDocument = android.graphics.pdf.PdfDocument()
    // Landscape
    val pageWidth = 842
    val pageHeight = 595
    val pageInfo = android.graphics.pdf.PdfDocument.PageInfo.Builder(pageWidth, pageHeight, 1).create()
    var page = pdfDocument.startPage(pageInfo)
    var canvas = page.canvas
    
    // Theme Colors
    val isOrange = theme == "orange"
    val primaryColor = if (isOrange) android.graphics.Color.parseColor("#F97316") else android.graphics.Color.parseColor("#0284C7") // Orange vs SkyBlue
    val secondaryColor = if (isOrange) android.graphics.Color.parseColor("#FDBA74") else android.graphics.Color.parseColor("#0369A1") 
    
    val paintPrimary = android.graphics.Paint().apply { color = primaryColor; isAntiAlias = true }
    val paintSecondary = android.graphics.Paint().apply { color = secondaryColor; isAntiAlias = true }
    
    val paintTitle = android.graphics.Paint().apply {
        color = primaryColor
        textSize = 28f
        typeface = android.graphics.Typeface.create(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD)
        isAntiAlias = true
    }
    val paintMottoEn = android.graphics.Paint().apply {
        color = android.graphics.Color.parseColor("#0F172A")
        textSize = 16f
        typeface = android.graphics.Typeface.create(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD)
        isAntiAlias = true
    }
    val paintMottoUr = android.graphics.Paint().apply {
        color = android.graphics.Color.parseColor("#475569")
        textSize = 16f
        typeface = android.graphics.Typeface.create(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.NORMAL)
        isAntiAlias = true
    }
    val paintDate = android.graphics.Paint().apply {
        color = android.graphics.Color.parseColor("#64748B")
        textSize = 12f
        isAntiAlias = true
    }
    val paintHeaderText = android.graphics.Paint().apply {
        color = android.graphics.Color.WHITE
        textSize = 12f
        typeface = android.graphics.Typeface.create(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD)
        isAntiAlias = true
    }
    val paintCellText = android.graphics.Paint().apply {
        color = android.graphics.Color.parseColor("#1E293B")
        textSize = 11f
        typeface = android.graphics.Typeface.create(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.NORMAL)
        isAntiAlias = true
    }
    val paintRowBgAlt = android.graphics.Paint().apply {
        color = android.graphics.Color.parseColor("#F8FAFC")
    }
    val paintBorder = android.graphics.Paint().apply {
        color = android.graphics.Color.parseColor("#E2E8F0")
        style = android.graphics.Paint.Style.STROKE
        strokeWidth = 1f
    }
    

    
    val marginLeft = 40f
    val marginRight = 40f
    val marginBottom = 40f
    val contentWidth = pageWidth - marginLeft - marginRight
    
    fun drawHeader(c: android.graphics.Canvas): Float {
        // Decorative top elements
        if (isOrange) {
            // Orange abstract waves top right
            val path = android.graphics.Path()
            path.moveTo(pageWidth.toFloat(), 0f)
            path.lineTo(pageWidth - 250f, 0f)
            path.quadTo(pageWidth - 150f, 80f, pageWidth.toFloat(), 150f)
            path.close()
            c.drawPath(path, paintSecondary)
            
            val path2 = android.graphics.Path()
            path2.moveTo(pageWidth.toFloat(), 0f)
            path2.lineTo(pageWidth - 150f, 0f)
            path2.quadTo(pageWidth - 50f, 50f, pageWidth.toFloat(), 100f)
            path2.close()
            c.drawPath(path2, paintPrimary)
        } else {
            // Blue geometric polygons top left
            val path = android.graphics.Path()
            path.moveTo(0f, 0f)
            path.lineTo(250f, 0f)
            path.lineTo(0f, 150f)
            path.close()
            c.drawPath(path, paintSecondary)
            
            val path2 = android.graphics.Path()
            path2.moveTo(0f, 0f)
            path2.lineTo(150f, 0f)
            path2.lineTo(0f, 100f)
            path2.close()
            c.drawPath(path2, paintPrimary)
        }
        
        var currentY = 50f
        
        // Logo & Motto (Avoid shapes based on theme)
        var leftContentX = marginLeft
        if (!isOrange) { leftContentX = marginLeft + 60f } // Push right if blue shape is there

        c.drawText("Tanzeem Amanat Taqseem", leftContentX, currentY + 15f, paintMottoEn)
        c.drawText("تنظیم امانت تقسیم", leftContentX, currentY + 35f, paintMottoUr)
        
        // Title & Date
        var rightContentX = pageWidth - marginRight
        if (isOrange) { rightContentX = pageWidth - marginRight - 60f }
        
        val titleText = title.uppercase()
        val titleWidth = paintTitle.measureText(titleText)
        c.drawText(titleText, rightContentX - titleWidth, currentY + 15f, paintTitle)
        
        val dateText = "Date: ${java.text.SimpleDateFormat("MMM dd, yyyy", java.util.Locale.getDefault()).format(java.util.Date())}"
        val dateWidth = paintDate.measureText(dateText)
        c.drawText(dateText, rightContentX - dateWidth, currentY + 35f, paintDate)
        
        // Divider line
        currentY += 80f
        c.drawLine(marginLeft, currentY, pageWidth - marginRight, currentY, paintPrimary)
        return currentY + 20f
    }
    
    var currentY = drawHeader(canvas)
    
    // Column widths
    val colWidths = FloatArray(headers.size)
    val columnWidth = contentWidth / headers.size.toFloat()
    for (i in headers.indices) colWidths[i] = columnWidth
    
    val headerRowHeight = 35f
    canvas.drawRect(marginLeft, currentY, pageWidth - marginRight, currentY + headerRowHeight, paintPrimary)
    for ((index, header) in headers.withIndex()) {
        val cellX = marginLeft + (index * columnWidth)
        canvas.drawText(header, cellX + 10f, currentY + 22f, paintHeaderText)
        if (index > 0) canvas.drawLine(cellX, currentY, cellX, currentY + headerRowHeight, paintBorder)
    }
    canvas.drawRect(marginLeft, currentY, pageWidth - marginRight, currentY + headerRowHeight, paintBorder)
    
    currentY += headerRowHeight
    
    val rowHeight = 30f
    for ((rowIndex, row) in data.withIndex()) {
        if (currentY + rowHeight > pageHeight - marginBottom) {
            pdfDocument.finishPage(page)
            page = pdfDocument.startPage(pageInfo)
            canvas = page.canvas
            currentY = drawHeader(canvas)
            
            canvas.drawRect(marginLeft, currentY, pageWidth - marginRight, currentY + headerRowHeight, paintPrimary)
            for ((index, header) in headers.withIndex()) {
                val cellX = marginLeft + (index * columnWidth)
                canvas.drawText(header, cellX + 10f, currentY + 22f, paintHeaderText)
                if (index > 0) canvas.drawLine(cellX, currentY, cellX, currentY + headerRowHeight, paintBorder)
            }
            canvas.drawRect(marginLeft, currentY, pageWidth - marginRight, currentY + headerRowHeight, paintBorder)
            currentY += headerRowHeight
        }
        
        if (rowIndex % 2 != 0) {
            canvas.drawRect(marginLeft, currentY, pageWidth - marginRight, currentY + rowHeight, paintRowBgAlt)
        }
        
        for ((colIndex, cell) in row.withIndex()) {
            var text = cell
            val maxTextWidth = columnWidth - 20f
            val measured = paintCellText.measureText(text)
            if (measured > maxTextWidth) {
                val charsToKeep = (maxTextWidth / (measured / text.length)).toInt()
                if (charsToKeep > 0 && charsToKeep < text.length) {
                    text = text.substring(0, charsToKeep - 2) + ".."
                }
            }
            
            val cellX = marginLeft + (colIndex * columnWidth)
            canvas.drawText(text, cellX + 10f, currentY + 20f, paintCellText)
            if (colIndex > 0) canvas.drawLine(cellX, currentY, cellX, currentY + rowHeight, paintBorder)
        }
        canvas.drawRect(marginLeft, currentY, pageWidth - marginRight, currentY + rowHeight, paintBorder)
        currentY += rowHeight
    }
    
    // Bottom decorative elements
    if (isOrange) {
        val path = android.graphics.Path()
        path.moveTo(0f, pageHeight.toFloat())
        path.lineTo(250f, pageHeight.toFloat())
        path.quadTo(150f, pageHeight - 80f, 0f, pageHeight - 150f)
        path.close()
        canvas.drawPath(path, paintSecondary)
    } else {
        val path = android.graphics.Path()
        path.moveTo(pageWidth.toFloat(), pageHeight.toFloat())
        path.lineTo(pageWidth - 250f, pageHeight.toFloat())
        path.lineTo(pageWidth.toFloat(), pageHeight - 150f)
        path.close()
        canvas.drawPath(path, paintSecondary)
    }
    
    pdfDocument.finishPage(page)
    val file = java.io.File(context.externalCacheDir, filename)
    pdfDocument.writeTo(java.io.FileOutputStream(file))
    pdfDocument.close()
    
    return file
}

fun sharePdfFile(context: android.content.Context, file: java.io.File) {
    try {
        val uri = androidx.core.content.FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )
        val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(android.content.Intent.EXTRA_SUBJECT, file.name.replace(".pdf", " Report"))
            putExtra(android.content.Intent.EXTRA_STREAM, uri)
            addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(android.content.Intent.createChooser(intent, "Export PDF Report"))
    } catch (e: Exception) {
        e.printStackTrace()
        android.widget.Toast.makeText(context, "Export failed. Please check permissions.", android.widget.Toast.LENGTH_LONG).show()
    }
}



@Composable
fun AppleLogoIcon(
    modifier: androidx.compose.ui.Modifier = androidx.compose.ui.Modifier,
    tint: androidx.compose.ui.graphics.Color = androidx.compose.ui.graphics.Color.White
) {
    androidx.compose.foundation.Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        
        val path = androidx.compose.ui.graphics.Path().apply {
            moveTo(w * 0.5f, h * 0.28f)
            cubicTo(w * 0.45f, h * 0.24f, w * 0.35f, h * 0.24f, w * 0.28f, h * 0.32f)
            cubicTo(w * 0.18f, h * 0.42f, w * 0.16f, h * 0.62f, w * 0.26f, h * 0.74f)
            cubicTo(w * 0.32f, h * 0.82f, w * 0.42f, h * 0.82f, w * 0.48f, h * 0.78f)
            cubicTo(w * 0.49f, h * 0.77f, w * 0.51f, h * 0.77f, w * 0.52f, h * 0.78f)
            cubicTo(w * 0.58f, h * 0.82f, w * 0.68f, h * 0.82f, w * 0.74f, h * 0.74f)
            cubicTo(w * 0.82f, h * 0.65f, w * 0.80f, h * 0.52f, w * 0.74f, h * 0.48f)
            cubicTo(w * 0.75f, h * 0.45f, w * 0.76f, h * 0.42f, w * 0.74f, h * 0.39f)
            cubicTo(w * 0.68f, h * 0.26f, w * 0.55f, h * 0.28f, w * 0.5f, h * 0.28f)
            close()
        }
        
        val leafPath = androidx.compose.ui.graphics.Path().apply {
            moveTo(w * 0.52f, h * 0.23f)
            cubicTo(w * 0.55f, h * 0.15f, w * 0.65f, h * 0.10f, w * 0.65f, h * 0.10f)
            cubicTo(w * 0.65f, h * 0.10f, w * 0.60f, h * 0.22f, w * 0.55f, h * 0.25f)
            cubicTo(w * 0.53f, h * 0.26f, w * 0.51f, h * 0.25f, w * 0.52f, h * 0.23f)
            close()
        }
        
        drawPath(path = path, color = tint)
        drawPath(path = leafPath, color = tint)
    }
}

@Composable
fun LanguagePickerDialog(
    isUrdu: Boolean,
    onDismiss: () -> Unit,
    onLanguageSelected: (Boolean) -> Unit
) {
    androidx.compose.ui.window.Dialog(onDismissRequest = onDismiss) {
        androidx.compose.material3.Card(
            modifier = androidx.compose.ui.Modifier
                .fillMaxWidth(0.85f)
                .clip(androidx.compose.foundation.shape.RoundedCornerShape(16.dp))
                .border(androidx.compose.foundation.BorderStroke(1.dp, GoldAccent.copy(alpha = 0.4f)), androidx.compose.foundation.shape.RoundedCornerShape(16.dp)),
            colors = androidx.compose.material3.CardDefaults.cardColors(containerColor = DarkSlateSurface)
        ) {
            Column(
                modifier = androidx.compose.ui.Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                horizontalAlignment = androidx.compose.ui.Alignment.CenterHorizontally,
                verticalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(16.dp)
            ) {
                Text(
                    text = if (isUrdu) "زبان منتخب کریں" else "Select Language",
                    color = TextOffWhite,
                    fontSize = 16.sp,
                    fontWeight = androidx.compose.ui.text.font.FontWeight.Bold
                )
                
                // English option button
                androidx.compose.material3.Button(
                    onClick = {
                        onLanguageSelected(false)
                        onDismiss()
                    },
                    modifier = androidx.compose.ui.Modifier.fillMaxWidth().height(44.dp),
                    colors = androidx.compose.material3.ButtonDefaults.buttonColors(
                        containerColor = if (!isUrdu) EmeraldPrimary else DarkSlateBackground
                    ),
                    shape = androidx.compose.foundation.shape.RoundedCornerShape(8.dp),
                    border = if (isUrdu) androidx.compose.foundation.BorderStroke(1.dp, DarkSlateSurfaceVariant) else null
                ) {
                    Text(
                        text = "English",
                        color = if (!isUrdu) Color.White else TextOffWhite,
                        fontSize = 14.sp,
                        fontWeight = androidx.compose.ui.text.font.FontWeight.Bold
                    )
                }

                // Urdu option button
                androidx.compose.material3.Button(
                    onClick = {
                        onLanguageSelected(true)
                        onDismiss()
                    },
                    modifier = androidx.compose.ui.Modifier.fillMaxWidth().height(44.dp),
                    colors = androidx.compose.material3.ButtonDefaults.buttonColors(
                        containerColor = if (isUrdu) EmeraldPrimary else DarkSlateBackground
                    ),
                    shape = androidx.compose.foundation.shape.RoundedCornerShape(8.dp),
                    border = if (!isUrdu) androidx.compose.foundation.BorderStroke(1.dp, DarkSlateSurfaceVariant) else null
                ) {
                    Text(
                        text = "اردو (Urdu)",
                        color = if (isUrdu) Color.White else TextOffWhite,
                        fontSize = 14.sp,
                        fontWeight = androidx.compose.ui.text.font.FontWeight.Bold
                    )
                }
                
                androidx.compose.material3.TextButton(
                    onClick = onDismiss
                ) {
                    Text(
                        text = if (isUrdu) "بند کریں" else "Close",
                        color = TextMuted,
                        fontSize = 13.sp
                    )
                }
            }
        }
    }
}

@Composable
fun CloudCheckpointsDialog(
    viewModel: TatViewModel,
    isUrdu: Boolean,
    onDismiss: () -> Unit
) {
    var checkpoints by remember { mutableStateOf<List<String>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }
    
    LaunchedEffect(Unit) {
        viewModel.fetchCheckpoints { result ->
            checkpoints = result
            isLoading = false
        }
    }
    
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = DarkSlateSurface,
        title = {
            Text(
                text = if (isUrdu) "چیک پوائنٹس (ریسٹور)" else "Check Points (Restore)",
                color = Color.White,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            if (isLoading) {
                Box(modifier = Modifier.fillMaxWidth().padding(16.dp), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = GoldAccent)
                }
            } else if (checkpoints.isEmpty()) {
                Text(
                    text = if (isUrdu) "کوئی چیک پوائنٹ دستیاب نہیں ہے۔" else "No checkpoints available yet.",
                    color = TextMuted,
                    fontSize = 14.sp
                )
            } else {
                LazyColumn(modifier = Modifier.heightIn(max = 300.dp)) {
                    items(checkpoints) { dateStr ->
                        var isConfirming by remember { mutableStateOf(false) }
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            colors = CardDefaults.cardColors(containerColor = DarkSlateBackground),
                            border = BorderStroke(1.dp, if (isConfirming) Color.Red else DarkSlateSurfaceVariant)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text(
                                        text = dateStr,
                                        color = TextOffWhite,
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    if (!isConfirming) {
                                        Button(
                                            onClick = { isConfirming = true },
                                            colors = ButtonDefaults.buttonColors(containerColor = GoldAccent)
                                        ) {
                                            Text(if (isUrdu) "ریسٹور" else "Restore", color = DarkSlateBackground)
                                        }
                                    }
                                }
                                if (isConfirming) {
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text(
                                        text = if (isUrdu) "انتباہ: یہ موجودہ ڈیٹا کو منسوخ کر دے گا! کیا آپ کو یقین ہے؟" else "WARNING: This will overwrite current data! Are you sure?",
                                        color = Color.Red,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Row(
                                        horizontalArrangement = Arrangement.End,
                                        modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
                                    ) {
                                        TextButton(onClick = { isConfirming = false }) {
                                            Text(if (isUrdu) "منسوخ" else "Cancel", color = TextMuted)
                                        }
                                        Button(
                                            onClick = {
                                                viewModel.restoreCheckpoint(dateStr)
                                                onDismiss()
                                            },
                                            colors = ButtonDefaults.buttonColors(containerColor = Color.Red)
                                        ) {
                                            Text(if (isUrdu) "ہاں، ریسٹور کریں" else "Yes, Restore", color = Color.White)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text(text = if (isUrdu) "بند کریں" else "Close", color = TextOffWhite)
            }
        }
    )
}

fun createReceiptBitmap(member: Member, activeCustodianName: String): android.graphics.Bitmap {
    val width = 800
    val height = 1200
    val bitmap = android.graphics.Bitmap.createBitmap(width, height, android.graphics.Bitmap.Config.ARGB_8888)
    val canvas = android.graphics.Canvas(bitmap)
    
    // Background
    canvas.drawColor(android.graphics.Color.WHITE)
    
    val textPaint = android.graphics.Paint().apply {
        color = android.graphics.Color.BLACK
        textSize = 36f
        isAntiAlias = true
    }
    val boldPaint = android.graphics.Paint(textPaint).apply {
        typeface = android.graphics.Typeface.create(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD)
    }
    val titlePaint = android.graphics.Paint(boldPaint).apply {
        textSize = 60f
    }
    val subtitlePaint = android.graphics.Paint(textPaint).apply {
        color = android.graphics.Color.DKGRAY
        textSize = 30f
    }
    
    var y = 100f
    
    // Header
    val title = "RECEIPT"
    val titleWidth = titlePaint.measureText(title)
    canvas.drawText(title, (width - titleWidth) / 2, y, titlePaint)
    y += 60f
    
    val subtitle = "Tanzeem Amanat Taqseem"
    val subtitleWidth = subtitlePaint.measureText(subtitle)
    canvas.drawText(subtitle, (width - subtitleWidth) / 2, y, subtitlePaint)
    y += 100f
    
    // Divider
    val dividerPaint = android.graphics.Paint().apply { color = android.graphics.Color.LTGRAY; strokeWidth = 2f }
    canvas.drawLine(50f, y, width - 50f, y, dividerPaint)
    y += 80f
    
    // Member Info
    canvas.drawText("Member:", 50f, y, subtitlePaint)
    canvas.drawText(member.name, width - 50f - boldPaint.measureText(member.name), y, boldPaint)
    y += 60f
    
    canvas.drawText("QID:", 50f, y, subtitlePaint)
    canvas.drawText(member.qid, width - 50f - textPaint.measureText(member.qid), y, textPaint)
    y += 80f
    
    canvas.drawLine(50f, y, width - 50f, y, dividerPaint)
    y += 80f
    
    // Payments
    var total = 0
    if (member.year1Paid) {
        val label = "Year 1 (${member.year1PaymentDate ?: "Paid"})"
        canvas.drawText(label, 50f, y, textPaint)
        canvas.drawText("200 QAR", width - 50f - textPaint.measureText("200 QAR"), y, textPaint)
        y += 60f
        total += 200
    }
    if (member.year2Paid) {
        val label = "Year 2 (${member.year2PaymentDate ?: "Paid"})"
        canvas.drawText(label, 50f, y, textPaint)
        canvas.drawText("200 QAR", width - 50f - textPaint.measureText("200 QAR"), y, textPaint)
        y += 60f
        total += 200
    }
    if (member.year3Paid) {
        val label = "Year 3 (${member.year3PaymentDate ?: "Paid"})"
        canvas.drawText(label, 50f, y, textPaint)
        canvas.drawText("200 QAR", width - 50f - textPaint.measureText("200 QAR"), y, textPaint)
        y += 60f
        total += 200
    }
    
    y += 20f
    dividerPaint.color = android.graphics.Color.BLACK
    canvas.drawLine(50f, y, width - 50f, y, dividerPaint)
    y += 80f
    
    // Total
    canvas.drawText("TOTAL PAID", 50f, y, boldPaint)
    val totalStr = "${total} QAR"
    canvas.drawText(totalStr, width - 50f - boldPaint.measureText(totalStr), y, boldPaint)
    y += 80f
    
    dividerPaint.color = android.graphics.Color.LTGRAY
    canvas.drawLine(50f, y, width - 50f, y, dividerPaint)
    y += 80f
    
    // Custodian
    canvas.drawText("Custodian:", 50f, y, subtitlePaint)
    canvas.drawText(activeCustodianName, width - 50f - textPaint.measureText(activeCustodianName), y, textPaint)
    y += 120f
    
    // Footer
    val footerPaint = android.graphics.Paint(subtitlePaint).apply {
        typeface = android.graphics.Typeface.create(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.ITALIC)
    }
    val footer = "Thank you for your contribution."
    canvas.drawText(footer, (width - footerPaint.measureText(footer)) / 2, y, footerPaint)
    
    return bitmap
}
