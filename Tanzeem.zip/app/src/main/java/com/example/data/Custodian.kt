package com.example.data

import androidx.room.Entity
import androidx.room.Ignore
import androidx.room.PrimaryKey
import com.google.firebase.firestore.PropertyName

@Entity(tableName = "custodians")
data class Custodian(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val name: String = "",
    val phone: String = "",
    val startDate: Long = 0L,
    val endDate: Long = 0L,
    @get:PropertyName("isCurrent") @set:PropertyName("isCurrent") var isCurrent: Boolean = false,
    @get:PropertyName("orderIndex") @set:PropertyName("orderIndex") var orderIndex: Int = 0, // Used to maintain the queue hierarchy
    val password: String = "", // Secure password for admin access
    val tempPassword: String = "", // Temporary password used during handover
    @get:PropertyName("isPast") @set:PropertyName("isPast") var isPast: Boolean = false
) {
    // Firestore reflection fallback: maps document field "current" to isCurrent
    @get:androidx.room.Ignore
    @get:PropertyName("current")
    @set:PropertyName("current")
    var current: Boolean
        @JvmName("getFirestoreCurrent")
        get() = isCurrent
        @JvmName("setFirestoreCurrent")
        set(value) {
            isCurrent = value
        }

    // Firestore reflection fallback: maps document field "past" to isPast
    @get:androidx.room.Ignore
    @get:PropertyName("past")
    @set:PropertyName("past")
    var past: Boolean
        @JvmName("getFirestorePast")
        get() = isPast
        @JvmName("setFirestorePast")
        set(value) {
            isPast = value
        }
}
