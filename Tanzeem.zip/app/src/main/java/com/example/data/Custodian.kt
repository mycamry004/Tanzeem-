package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "custodians")
data class Custodian(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val phone: String,
    val startDate: Long,
    val endDate: Long,
    val isCurrent: Boolean = false,
    val orderIndex: Int = 0, // Used to maintain the queue hierarchy (Current first, then 2nd, 3rd...)
    val password: String = "" // Secure password for admin access
)
