package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.Calendar

@Database(entities = [Member::class, Custodian::class, Claim::class], version = 6, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {

    abstract fun tanzeemDao(): TanzeemDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "tanzeem_database"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }

        suspend fun populateDatabase(dao: TanzeemDao) {
            if (dao.getMembersCount() > 0) return
            // Populate initial members
            val members = listOf(
                Member(name = "Abbas", qid = "29012345001", phone = "+974 5511 0001", status = "Active Qatar", year1Paid = true, year2Paid = true, year3Paid = false, year1PaymentDate = "12 Jan 2026", year2PaymentDate = "18 Feb 2026"),
                Member(name = "Abdullah (Manzoor)", qid = "29012345002", phone = "+974 5511 0002", status = "Active Qatar", year1Paid = true, year2Paid = true, year3Paid = false, year1PaymentDate = "15 Jan 2026", year2PaymentDate = "20 Feb 2026"),
                Member(name = "Adil Zaib", qid = "29012345003", phone = "+974 5511 0003", status = "Active Qatar", year1Paid = true, year2Paid = false, year3Paid = false, year1PaymentDate = "18 Jan 2026"),
                Member(name = "Adnan", qid = "29012345004", phone = "+974 5511 0004", status = "On Vacation", year1Paid = true, year2Paid = true, year3Paid = false, year1PaymentDate = "22 Jan 2026", year2PaymentDate = "25 Feb 2026"),
                Member(name = "Abdul Samad", qid = "29012345005", phone = "+974 5511 0005", status = "Active Qatar", year1Paid = true, year2Paid = true, year3Paid = false, year1PaymentDate = "05 Jan 2026", year2PaymentDate = "10 Feb 2026"),
                Member(name = "Abdul Majeed", qid = "29012345006", phone = "+974 5511 0006", status = "Active Qatar", year1Paid = true, year2Paid = true, year3Paid = false, year1PaymentDate = "08 Jan 2026", year2PaymentDate = "12 Feb 2026"),
                Member(name = "Abu Bakar", qid = "29012345007", phone = "+974 5511 0007", status = "Active Qatar", year1Paid = true, year2Paid = true, year3Paid = false, year1PaymentDate = "14 Jan 2026", year2PaymentDate = "16 Feb 2026"),
                Member(name = "Farhan", qid = "29012345008", phone = "+974 5511 0008", status = "On Vacation", year1Paid = true, year2Paid = true, year3Paid = false, year1PaymentDate = "19 Jan 2026", year2PaymentDate = "22 Feb 2026"),
                Member(name = "Fayyaz", qid = "29012345009", phone = "+974 5511 0009", status = "Active Qatar", year1Paid = true, year2Paid = false, year3Paid = false, year1PaymentDate = "21 Jan 2026"),
                Member(name = "Imran Janla", qid = "29012345010", phone = "+974 5511 0010", status = "Active Qatar", year1Paid = true, year2Paid = true, year3Paid = false, year1PaymentDate = "11 Jan 2026", year2PaymentDate = "15 Feb 2026"),
                Member(name = "Imran Khan", qid = "29012345011", phone = "+974 5511 0011", status = "Active Qatar", year1Paid = true, year2Paid = true, year3Paid = false, year1PaymentDate = "02 Jan 2026", year2PaymentDate = "05 Feb 2026"),
                Member(name = "Inamullah", qid = "29012345012", phone = "+974 5511 0012", status = "Active Qatar", year1Paid = true, year2Paid = true, year3Paid = false, year1PaymentDate = "03 Jan 2026", year2PaymentDate = "07 Feb 2026"),
                Member(name = "Majeedullah", qid = "29012345013", phone = "+974 5511 0013", status = "Left Qatar for Good", year1Paid = true, year2Paid = true, year3Paid = false, year1PaymentDate = "04 Jan 2026", year2PaymentDate = "08 Feb 2026"),
                Member(name = "Manzoor", qid = "29012345014", phone = "+974 5511 0014", status = "Active Qatar", year1Paid = true, year2Paid = true, year3Paid = false, year1PaymentDate = "01 Jan 2026", year2PaymentDate = "01 Feb 2026"),
                Member(name = "Najeeb", qid = "29012345015", phone = "+974 5511 0015", status = "Active Qatar", year1Paid = true, year2Paid = true, year3Paid = false, year1PaymentDate = "06 Jan 2026", year2PaymentDate = "11 Feb 2026"),
                Member(name = "Qaseem", qid = "29012345016", phone = "+974 5511 0016", status = "Active Qatar", year1Paid = true, year2Paid = true, year3Paid = false, year1PaymentDate = "07 Jan 2026", year2PaymentDate = "13 Feb 2026"),
                Member(name = "Usman Ali", qid = "29012345017", phone = "+974 5511 0017", status = "On Vacation", year1Paid = true, year2Paid = true, year3Paid = false, year1PaymentDate = "09 Jan 2026", year2PaymentDate = "14 Feb 2026"),
                Member(name = "Waqas", qid = "29012345018", phone = "+974 5511 0018", status = "Active Qatar", year1Paid = true, year2Paid = true, year3Paid = false, year1PaymentDate = "10 Jan 2026", year2PaymentDate = "17 Feb 2026"),
                Member(name = "Ziaullah", qid = "29012345019", phone = "+974 5511 0019", status = "Active Qatar", year1Paid = true, year2Paid = true, year3Paid = false, year1PaymentDate = "12 Jan 2026", year2PaymentDate = "19 Feb 2026"),
                Member(name = "Arif", qid = "29012345020", phone = "+974 5511 0020", status = "Active Qatar", year1Paid = true, year2Paid = true, year3Paid = false, year1PaymentDate = "13 Jan 2026", year2PaymentDate = "20 Feb 2026"),
                Member(name = "Wajid", qid = "29012345021", phone = "+974 5511 0021", status = "Active Qatar", year1Paid = true, year2Paid = true, year3Paid = false, year1PaymentDate = "15 Jan 2026", year2PaymentDate = "22 Feb 2026"),
                Member(name = "Sikandar", qid = "29012345022", phone = "+974 5511 0022", status = "Left Qatar for Good", year1Paid = true, year2Paid = true, year3Paid = false, year1PaymentDate = "16 Jan 2026", year2PaymentDate = "23 Feb 2026"),
                Member(name = "Ali Khan", qid = "29012345023", phone = "+974 5511 0023", status = "Active Qatar", year1Paid = true, year2Paid = true, year3Paid = false, year1PaymentDate = "17 Jan 2026", year2PaymentDate = "24 Feb 2026"),
                Member(name = "Naveed", qid = "29012345024", phone = "+974 5511 0024", status = "Active Qatar", year1Paid = true, year2Paid = true, year3Paid = false, year1PaymentDate = "18 Jan 2026", year2PaymentDate = "25 Feb 2026"),
                Member(name = "Umair", qid = "29012345025", phone = "+974 5511 0025", status = "Active Qatar", year1Paid = true, year2Paid = true, year3Paid = false, year1PaymentDate = "20 Jan 2026", year2PaymentDate = "26 Feb 2026")
            )
            for (m in members) {
                dao.insertMember(m)
            }

            // Populate initial custodians (3-month rotations starting from today)
            val cal = Calendar.getInstance()
            val now = cal.timeInMillis

            cal.add(Calendar.MONTH, 3)
            val threeMonths = cal.timeInMillis

            cal.add(Calendar.MONTH, 3)
            val sixMonths = cal.timeInMillis

            val custodians = listOf(
                Custodian(
                    name = "Manzoor",
                    phone = "+974 5511 0014",
                    startDate = now,
                    endDate = threeMonths,
                    isCurrent = true,
                    orderIndex = 0,
                    password = "tat123" // easy default password
                ),
                Custodian(
                    name = "Abdul Samad",
                    phone = "+974 5511 0005",
                    startDate = threeMonths,
                    endDate = sixMonths,
                    isCurrent = false,
                    orderIndex = 1,
                    password = "tat456"
                )
            )
            for (c in custodians) {
                dao.insertCustodian(c)
            }

            // Populate 1 initial claim as history
            dao.insertClaim(
                Claim(
                    deceasedName = "Shakeel Ahmed",
                    deceasedQid = "28211224455",
                    residencyStatus = "Active Qatar",
                    scenario = "Repatriation to Pakistan (Scenario B)",
                    allocatedCap = 15000.0,
                    actualExpenses = 13500.0,
                    auditRuling = "AUDIT RULING\n---\nSTATUS: APPROVED\n\nUnder the Sacred Pillars of Tanzeem Amanat Taqseem, the deceased Shakeel Ahmed was verified as a fully covered active resident of Qatar. The repatriation expenses of 13,500 QAR are under the 15,000 QAR allocation cap, which is fully approved for payment from the cash pool held by the custodian. \n\nTAQSEEM DISTRIBUTION RULE: The surplus of 1,500 QAR (15,000 QAR cap - 13,500 QAR actuals) has been officially disbursed to the immediate family of the deceased.",
                    surplusHandover = 1500.0,
                    deficitRecoupment = 0.0,
                    dateLogged = now - (15 * 24 * 3600 * 1000L) // 15 days ago
                )
            )
        }
    }

    private class AppDatabaseCallback(
        private val scope: CoroutineScope,
        private val databaseProvider: () -> AppDatabase
    ) : RoomDatabase.Callback() {

        override fun onCreate(db: SupportSQLiteDatabase) {
            super.onCreate(db)
            scope.launch(Dispatchers.IO) {
                populateDatabase(databaseProvider().tanzeemDao())
            }
        }
    }
}
