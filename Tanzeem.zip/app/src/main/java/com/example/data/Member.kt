package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "members")
data class Member(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val name: String = "",
    val qid: String = "",
    val phone: String = "",
    val status: String = "", // "Active Qatar", "On Vacation", "Left Qatar for Good"
    val year1Paid: Boolean = false,
    val year2Paid: Boolean = false,
    val year3Paid: Boolean = false,
    val year1PaymentDate: String? = null,
    val year2PaymentDate: String? = null,
    val year3PaymentDate: String? = null,
    val surplusOwed: Double = 0.0,
    val surplusPaid: Boolean = false,
    val surplusPaidAmount: Double = 0.0
)
