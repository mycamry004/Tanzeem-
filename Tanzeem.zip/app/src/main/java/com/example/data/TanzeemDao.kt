package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface TanzeemDao {

    // --- Members ---
    @Query("SELECT * FROM members ORDER BY name ASC")
    fun getAllMembers(): Flow<List<Member>>

    @Query("SELECT COUNT(*) FROM members")
    suspend fun getMembersCount(): Int

    @Query("SELECT * FROM members")
    suspend fun getAllMembersList(): List<Member>

    @Query("DELETE FROM members")
    suspend fun deleteAllMembers()

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMember(member: Member): Long

    @Update
    suspend fun updateMember(member: Member)

    @Delete
    suspend fun deleteMember(member: Member)

    @Query("SELECT * FROM members WHERE id = :id")
    suspend fun getMemberById(id: Long): Member?

    // --- Custodians ---
    @Query("SELECT * FROM custodians ORDER BY orderIndex ASC")
    fun getAllCustodians(): Flow<List<Custodian>>

    @Query("SELECT * FROM custodians")
    suspend fun getAllCustodiansList(): List<Custodian>

    @Query("DELETE FROM custodians")
    suspend fun deleteAllCustodians()

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCustodian(custodian: Custodian): Long

    @Update
    suspend fun updateCustodian(custodian: Custodian)

    @Delete
    suspend fun deleteCustodian(custodian: Custodian)

    @Query("SELECT * FROM custodians WHERE isCurrent = 1 LIMIT 1")
    suspend fun getCurrentCustodian(): Custodian?

    // --- Claims ---
    @Query("SELECT * FROM claims ORDER BY dateLogged DESC")
    fun getAllClaims(): Flow<List<Claim>>

    @Query("SELECT * FROM claims")
    suspend fun getAllClaimsList(): List<Claim>

    @Query("DELETE FROM claims")
    suspend fun deleteAllClaims()

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertClaim(claim: Claim): Long

    @Update
    suspend fun updateClaim(claim: Claim)

    @Delete
    suspend fun deleteClaim(claim: Claim)
}
