package com.example.data

data class AppDevice(
    val deviceId: String = "",
    val deviceModel: String = "",
    val osVersion: String = "",
    val locale: String = "",
    val lastActive: Long = 0L,
    val isBlocked: Boolean = false
)
