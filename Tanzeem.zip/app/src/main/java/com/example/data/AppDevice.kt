package com.example.data

import com.google.firebase.firestore.PropertyName

data class AppDevice(
    val deviceId: String = "",
    val deviceModel: String = "",
    val osVersion: String = "",
    val locale: String = "",
    val lastActive: Long = 0L,
    @get:PropertyName("isBlocked") @set:PropertyName("isBlocked") var isBlocked: Boolean = false
) {
    @get:PropertyName("blocked")
    @set:PropertyName("blocked")
    var blocked: Boolean
        @JvmName("getFirestoreBlocked")
        get() = isBlocked
        @JvmName("setFirestoreBlocked")
        set(value) {
            if (value) isBlocked = true
        }
}
