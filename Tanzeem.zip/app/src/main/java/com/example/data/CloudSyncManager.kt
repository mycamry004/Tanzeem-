package com.example.data

import android.util.Log
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.tasks.await
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class CloudBackup(
    val timestamp: Long = 0L,
    val members: List<Member> = emptyList(),
    val claims: List<Claim> = emptyList(),
    val custodians: List<Custodian> = emptyList()
)

object CloudSyncManager {
    private val db: FirebaseFirestore? by lazy { 
        try {
            FirebaseFirestore.getInstance()
        } catch (e: Exception) {
            null
        }
    }
    private const val COLLECTION_DATA = "community_data"
    private const val DOC_CURRENT = "current_state"
    private const val COLLECTION_BACKUPS = "daily_backups"

    // Upload current state to cloud
    suspend fun syncToCloud(
        members: List<Member>,
        claims: List<Claim>,
        custodians: List<Custodian>
    ): Boolean {
        try {
            val state = CloudBackup(
                timestamp = System.currentTimeMillis(),
                members = members,
                claims = claims,
                custodians = custodians
            )
            // Update current state
            db?.collection(COLLECTION_DATA)?.document(DOC_CURRENT)?.set(state)?.await()

            // Handle Daily Backup (only 1 per day)
            if (db == null) return false
            val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
            val todayStr = sdf.format(Date())
            
            db?.collection(COLLECTION_DATA)
                ?.document(DOC_CURRENT)
                ?.collection(COLLECTION_BACKUPS)
                ?.document(todayStr)
                ?.set(state, SetOptions.merge())
                ?.await()

            // Cleanup old backups (keep only last 30)
            cleanupOldBackups()
            return true
        } catch (e: Exception) {
            Log.d("CloudSync", "Error syncing to cloud: ${e.message}")
            return false
        }
    }

    // Fetch the current state from cloud on fresh install/update
    suspend fun fetchCurrentState(): CloudBackup? {
        return try {
            val snapshot = db?.collection(COLLECTION_DATA)?.document(DOC_CURRENT)?.get()?.await()
            if (snapshot != null && snapshot.exists()) {
                snapshot.toObject(CloudBackup::class.java)
            } else {
                null
            }
        } catch (e: Exception) {
            Log.d("CloudSync", "Error fetching from cloud: ${e.message}")
            null
        }
    }

    // Fetch available checkpoints (backups)
    suspend fun fetchCheckpoints(): List<String> {
        return try {
            val snapshot = db?.collection(COLLECTION_DATA)
                ?.document(DOC_CURRENT)
                ?.collection(COLLECTION_BACKUPS)
                ?.orderBy("timestamp", Query.Direction.DESCENDING)
                ?.get()
                ?.await()
            snapshot?.documents?.map { it.id } ?: emptyList()
        } catch (e: Exception) {
            Log.d("CloudSync", "Error fetching checkpoints: ${e.message}")
            emptyList()
        }
    }

    // Restore a specific checkpoint
    suspend fun restoreCheckpoint(dateStr: String): CloudBackup? {
        return try {
            val snapshot = db?.collection(COLLECTION_DATA)
                ?.document(DOC_CURRENT)
                ?.collection(COLLECTION_BACKUPS)
                ?.document(dateStr)
                ?.get()
                ?.await()
            if (snapshot != null && snapshot.exists()) {
                snapshot.toObject(CloudBackup::class.java)
            } else {
                null
            }
        } catch (e: Exception) {
            Log.d("CloudSync", "Error restoring checkpoint: ${e.message}")
            null
        }
    }

    private suspend fun cleanupOldBackups() {
        try {
            val snapshot = db?.collection(COLLECTION_DATA)
                ?.document(DOC_CURRENT)
                ?.collection(COLLECTION_BACKUPS)
                ?.orderBy("timestamp", Query.Direction.DESCENDING)
                ?.get()
                ?.await()
            
            if (snapshot != null && snapshot.size() > 30) {
                // Delete everything older than the 30th document
                for (i in 30 until snapshot.size()) {
                    snapshot.documents[i].reference.delete().await()
                }
            }
        } catch (e: Exception) {
            Log.d("CloudSync", "Error cleaning up: ${e.message}")
        }
    }
}
