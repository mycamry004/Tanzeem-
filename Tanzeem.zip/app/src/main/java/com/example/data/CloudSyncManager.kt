package com.example.data

import android.util.Log
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withTimeoutOrNull
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class CloudBackup(
    val timestamp: Long = 0L,
    val backupName: String = "Auto",
    val members: List<Member> = emptyList(),
    val claims: List<Claim> = emptyList(),
    val custodians: List<Custodian> = emptyList(),
    val notifications: List<AppNotification> = emptyList(),
    val devices: List<AppDevice> = emptyList()
)

object CloudSyncManager {
    private val db: FirebaseFirestore? by lazy { 
        try {
            FirebaseFirestore.getInstance()
        } catch (e: Exception) {
            null
        }
    }
    private const val COLLECTION_DATA = "community_data"
    private const val DOC_CURRENT = "current_state"
    private const val COLLECTION_BACKUPS = "daily_backups"

    // Upload current state to cloud
    suspend fun syncToCloud(
        members: List<Member>,
        claims: List<Claim>,
        custodians: List<Custodian>,
        notifications: List<AppNotification> = emptyList(),
        devices: List<AppDevice> = emptyList(),
        backupName: String = "Auto",
        isManualBackup: Boolean = false
    ): Pair<Boolean, String> {
        try {
            val state = CloudBackup(
                timestamp = System.currentTimeMillis(),
                backupName = backupName,
                members = members,
                claims = claims,
                custodians = custodians,
                notifications = notifications,
                devices = devices
            )
            val firestore = db ?: return Pair(false, "Firebase database not initialized")

            // Update current state with timeout
            try {
                kotlinx.coroutines.withTimeoutOrNull(6000L) {
                    firestore.collection(COLLECTION_DATA).document(DOC_CURRENT).set(state).await()
                }
            } catch (e: Exception) {
                Log.w("CloudSync", "Non-fatal current_state update error: ${e.message}")
            }

            val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
            val cleanBackupName = backupName.replace("/", "-").trim().ifBlank { "Backup" }
            val docId = if (isManualBackup) {
                "${sdf.format(Date())} - $cleanBackupName"
            } else {
                SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date()) + " - Auto"
            }

            try {
                kotlinx.coroutines.withTimeoutOrNull(8000L) {
                    firestore.collection(COLLECTION_DATA)
                        ?.document(DOC_CURRENT)
                        ?.collection(COLLECTION_BACKUPS)
                        ?.document(docId)
                        ?.set(state, SetOptions.merge())
                        ?.await()
                }
            } catch (e: Exception) {
                Log.w("CloudSync", "Backup doc write notice: ${e.message}")
            }

            // Cleanup old backups asynchronously without blocking backup completion
            kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.IO).launch {
                try {
                    cleanupOldBackups()
                } catch (e: Exception) {
                    Log.w("CloudSync", "Cleanup failed: ${e.message}")
                }
            }

            return Pair(true, "Success")
        } catch (e: Exception) {
            Log.e("CloudSync", "Error syncing to cloud: ${e.message}", e)
            return Pair(false, e.message ?: "Unknown error")
        }
    }

    // Fetch the current state from cloud on fresh install/update
    suspend fun fetchCurrentState(): CloudBackup? {
        return try {
            val snapshot = db?.collection(COLLECTION_DATA)?.document(DOC_CURRENT)?.get()?.await()
            if (snapshot != null && snapshot.exists()) {
                snapshot.toObject(CloudBackup::class.java)
            } else {
                val backups = db?.collection(COLLECTION_DATA)?.document(DOC_CURRENT)
                    ?.collection(COLLECTION_BACKUPS)
                    ?.get()?.await()
                if (backups != null && !backups.isEmpty) {
                    val sorted = backups.documents.sortedWith(
                        compareByDescending<com.google.firebase.firestore.DocumentSnapshot> { 
                            it.getLong("timestamp") ?: 0L 
                        }.thenByDescending { it.id }
                    )
                    sorted.firstOrNull()?.toObject(CloudBackup::class.java)
                } else {
                    null
                }
            }
        } catch (e: Exception) {
            Log.d("CloudSync", "Error fetching from cloud: ${e.message}")
            null
        }
    }

    // Fetch available checkpoints (backups)
    suspend fun fetchCheckpoints(): List<String> {
        return try {
            val firestore = db ?: return emptyList()
            val snapshot = kotlinx.coroutines.withTimeoutOrNull(12000L) {
                firestore.collection(COLLECTION_DATA)
                    .document(DOC_CURRENT)
                    .collection(COLLECTION_BACKUPS)
                    .get()
                    .await()
            }
            if (snapshot != null && !snapshot.isEmpty) {
                val sorted = snapshot.documents.sortedWith(
                    compareByDescending<com.google.firebase.firestore.DocumentSnapshot> { 
                        it.getLong("timestamp") ?: 0L 
                    }.thenByDescending { it.id }
                )
                sorted.map { it.id }
            } else {
                emptyList()
            }
        } catch (e: Exception) {
            Log.e("CloudSync", "Error fetching checkpoints: ${e.message}", e)
            emptyList()
        }
    }

    // Restore a specific checkpoint
    suspend fun restoreCheckpoint(dateStr: String): CloudBackup? {
        return try {
            val firestore = db ?: return null
            val snapshot = kotlinx.coroutines.withTimeoutOrNull(10000L) {
                firestore.collection(COLLECTION_DATA)
                    .document(DOC_CURRENT)
                    .collection(COLLECTION_BACKUPS)
                    .document(dateStr)
                    .get()
                    .await()
            }
            if (snapshot != null && snapshot.exists()) {
                snapshot.toObject(CloudBackup::class.java)
            } else {
                null
            }
        } catch (e: Exception) {
            Log.e("CloudSync", "Error restoring checkpoint: ${e.message}", e)
            null
        }
    }

    private suspend fun cleanupOldBackups() {
        try {
            val firestore = db ?: return
            val snapshot = kotlinx.coroutines.withTimeoutOrNull(10000L) {
                firestore.collection(COLLECTION_DATA)
                    .document(DOC_CURRENT)
                    .collection(COLLECTION_BACKUPS)
                    .get()
                    .await()
            }
            if (snapshot != null && snapshot.size() > 180) {
                val sorted = snapshot.documents.sortedWith(
                    compareByDescending<com.google.firebase.firestore.DocumentSnapshot> { 
                        it.getLong("timestamp") ?: 0L 
                    }.thenByDescending { it.id }
                )
                for (i in 180 until sorted.size) {
                    try {
                        sorted[i].reference.delete()
                    } catch (e: Exception) {
                        // ignore
                    }
                }
            }
        } catch (e: Exception) {
            Log.w("CloudSync", "Error cleaning up: ${e.message}")
        }
    }
}
