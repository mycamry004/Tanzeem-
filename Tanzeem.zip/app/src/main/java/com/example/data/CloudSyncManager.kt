package com.example.data

import android.util.Log
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withTimeoutOrNull
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class CloudBackup(
    val timestamp: Long = 0L,
    val backupName: String = "Auto",
    val members: List<Member> = emptyList(),
    val claims: List<Claim> = emptyList(),
    val custodians: List<Custodian> = emptyList(),
    val notifications: List<AppNotification> = emptyList(),
    val devices: List<AppDevice> = emptyList()
)

object CloudSyncManager {
    private val db: FirebaseFirestore? by lazy { 
        try {
            FirebaseFirestore.getInstance()
        } catch (e: Exception) {
            null
        }
    }
    private const val COLLECTION_DATA = "community_data"
    private const val DOC_CURRENT = "current_state"
    private const val COLLECTION_BACKUPS = "daily_backups"

    // Upload current state to cloud
    suspend fun syncToCloud(
        members: List<Member>,
        claims: List<Claim>,
        custodians: List<Custodian>,
        notifications: List<AppNotification> = emptyList(),
        devices: List<AppDevice> = emptyList(),
        backupName: String = "Auto",
        isManualBackup: Boolean = false
    ): Pair<Boolean, String> {
        try {
            val state = CloudBackup(
                timestamp = System.currentTimeMillis(),
                backupName = backupName,
                members = members,
                claims = claims,
                custodians = custodians,
                notifications = notifications,
                devices = devices
            )
            // Update current state with timeout
            kotlinx.coroutines.withTimeoutOrNull(8000L) {
                db?.collection(COLLECTION_DATA)?.document(DOC_CURRENT)?.set(state)?.await()
            }

            // Handle Daily Backup (only 1 per day)
            if (db == null) return Pair(false, "Firebase database not initialized")
            val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
            
            val docId = if (isManualBackup) {
                "${sdf.format(Date())} - $backupName"
            } else {
                SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date()) + " - Auto"
            }
            
            kotlinx.coroutines.withTimeoutOrNull(8000L) {
                db?.collection(COLLECTION_DATA)
                    ?.document(DOC_CURRENT)
                    ?.collection(COLLECTION_BACKUPS)
                    ?.document(docId)
                    ?.set(state, SetOptions.merge())
                    ?.await()
            }

            // Cleanup old backups (keep only last 180 (6 months))
            cleanupOldBackups()
            return Pair(true, "Success")
        } catch (e: Exception) {
            Log.d("CloudSync", "Error syncing to cloud: ${e.message}")
            return Pair(false, e.message ?: "Unknown error")
        }
    }

    // Fetch the current state from cloud on fresh install/update
    suspend fun fetchCurrentState(): CloudBackup? {
        return try {
            val snapshot = db?.collection(COLLECTION_DATA)?.document(DOC_CURRENT)?.get()?.await()
            if (snapshot != null && snapshot.exists()) {
                snapshot.toObject(CloudBackup::class.java)
            } else {
                // Fallback to latest backup if DOC_CURRENT is missing
                val backups = db?.collection(COLLECTION_DATA)?.document(DOC_CURRENT)
                    ?.collection(COLLECTION_BACKUPS)
                    ?.orderBy("timestamp", Query.Direction.DESCENDING)
                    ?.limit(1)
                    ?.get()?.await()
                if (backups != null && !backups.isEmpty) {
                    backups.documents[0].toObject(CloudBackup::class.java)
                } else {
                    null
                }
            }
        } catch (e: Exception) {
            Log.d("CloudSync", "Error fetching from cloud: ${e.message}")
            null
        }
    }

    // Fetch available checkpoints (backups)
    suspend fun fetchCheckpoints(): List<String> {
        return try {
            val snapshot = kotlinx.coroutines.withTimeoutOrNull(5000L) {
                db?.collection(COLLECTION_DATA)
                    ?.document(DOC_CURRENT)
                    ?.collection(COLLECTION_BACKUPS)
                    ?.orderBy("timestamp", Query.Direction.DESCENDING)
                    ?.get()
                    ?.await()
            }
            snapshot?.documents?.map { it.id } ?: emptyList()
        } catch (e: Exception) {
            Log.d("CloudSync", "Error fetching checkpoints: ${e.message}")
            emptyList()
        }
    }

    // Restore a specific checkpoint
    suspend fun restoreCheckpoint(dateStr: String): CloudBackup? {
        return try {
            val snapshot = kotlinx.coroutines.withTimeoutOrNull(8000L) {
                db?.collection(COLLECTION_DATA)
                    ?.document(DOC_CURRENT)
                    ?.collection(COLLECTION_BACKUPS)
                    ?.document(dateStr)
                    ?.get()
                    ?.await()
            }
            if (snapshot != null && snapshot.exists()) {
                snapshot.toObject(CloudBackup::class.java)
            } else {
                null
            }
        } catch (e: Exception) {
            Log.d("CloudSync", "Error restoring checkpoint: ${e.message}")
            null
        }
    }

    private suspend fun cleanupOldBackups() {
        try {
            val snapshot = db?.collection(COLLECTION_DATA)
                ?.document(DOC_CURRENT)
                ?.collection(COLLECTION_BACKUPS)
                ?.orderBy("timestamp", Query.Direction.DESCENDING)
                ?.get()
                ?.await()
            
            if (snapshot != null && snapshot.size() > 180) {
                // Delete everything older than the 180th document
                for (i in 180 until snapshot.size()) {
                    snapshot.documents[i].reference.delete().await()
                }
            }
        } catch (e: Exception) {
            Log.d("CloudSync", "Error cleaning up: ${e.message}")
        }
    }
}
