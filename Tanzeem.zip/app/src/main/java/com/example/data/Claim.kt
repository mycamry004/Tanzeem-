package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "claims")
data class Claim(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val deceasedName: String,
    val deceasedQid: String,
    val residencyStatus: String, // "Active Qatar", "On Vacation", "Left Qatar for Good"
    val scenario: String, // "Burial in Qatar (Scenario A)", "Repatriation (Scenario B)", "Vacation (Scenario C)", "Permanently Left (Scenario D)"
    val allocatedCap: Double,
    val actualExpenses: Double,
    val auditRuling: String = "", // Response text from Gemini AI Auditor
    val surplusHandover: Double = 0.0, // Surplus handed over to family (QAR)
    val deficitRecoupment: Double = 0.0, // Deficit recovered from next year's collective pool (QAR)
    val dateLogged: Long = System.currentTimeMillis()
)
