package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.google.firebase.firestore.PropertyName
import java.util.UUID

@Entity(tableName = "notifications")
data class AppNotification(
    @PrimaryKey var id: String = UUID.randomUUID().toString(),
    var timestamp: Long = System.currentTimeMillis(),
    var messageEng: String = "",
    var messageUrdu: String = "",
    var category: String = "General", // "Member", "Payment", "Custodian", "Claim", "System"
    var actorName: String = "",
    @get:PropertyName("isAdminAction") @set:PropertyName("isAdminAction") var isAdminAction: Boolean = false
)
