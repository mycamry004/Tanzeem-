package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.UUID

@Entity(tableName = "notifications")
data class AppNotification(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val timestamp: Long = System.currentTimeMillis(),
    val messageEng: String = "",
    val messageUrdu: String = "",
    val category: String = "General", // "Member", "Payment", "Custodian", "Claim", "System"
    val actorName: String = ""
)
