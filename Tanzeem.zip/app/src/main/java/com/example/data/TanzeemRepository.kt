package com.example.data

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class TanzeemRepository(private val dao: TanzeemDao) {

    val allMembers: Flow<List<Member>> = dao.getAllMembers()
    val allCustodians: Flow<List<Custodian>> = dao.getAllCustodians()
    val allClaims: Flow<List<Claim>> = dao.getAllClaims()

    private fun triggerSync() {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val members = dao.getAllMembersList()
                val claims = dao.getAllClaimsList()
                val custodians = dao.getAllCustodiansList()
                CloudSyncManager.syncToCloud(members, claims, custodians)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    suspend fun getMembersCount(): Int {
        return dao.getMembersCount()
    }

    suspend fun insertMember(member: Member) {
        dao.insertMember(member)
        triggerSync()
    }

    suspend fun updateMember(member: Member) {
        dao.updateMember(member)
        triggerSync()
    }

    suspend fun deleteMember(member: Member) {
        dao.deleteMember(member)
        triggerSync()
    }

    suspend fun insertCustodian(custodian: Custodian) {
        dao.insertCustodian(custodian)
        triggerSync()
    }

    suspend fun updateCustodian(custodian: Custodian) {
        dao.updateCustodian(custodian)
        triggerSync()
    }

    suspend fun deleteCustodian(custodian: Custodian) {
        dao.deleteCustodian(custodian)
        triggerSync()
    }

    suspend fun getCurrentCustodian(): Custodian? {
        return dao.getCurrentCustodian()
    }

    suspend fun insertClaim(claim: Claim) {
        dao.insertClaim(claim)
        triggerSync()
    }

    suspend fun updateClaim(claim: Claim) {
        dao.updateClaim(claim)
        triggerSync()
    }

    suspend fun deleteClaim(claim: Claim) {
        dao.deleteClaim(claim)
        triggerSync()
    }
}
