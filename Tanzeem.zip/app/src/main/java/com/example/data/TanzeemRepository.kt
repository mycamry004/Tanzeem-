package com.example.data

import kotlinx.coroutines.flow.Flow

class TanzeemRepository(private val dao: TanzeemDao) {

    val allMembers: Flow<List<Member>> = dao.getAllMembers()
    val allCustodians: Flow<List<Custodian>> = dao.getAllCustodians()
    val allClaims: Flow<List<Claim>> = dao.getAllClaims()

    suspend fun getMembersCount(): Int {
        return dao.getMembersCount()
    }

    suspend fun insertMember(member: Member) {
        dao.insertMember(member)
    }

    suspend fun updateMember(member: Member) {
        dao.updateMember(member)
    }

    suspend fun deleteMember(member: Member) {
        dao.deleteMember(member)
    }

    suspend fun insertCustodian(custodian: Custodian) {
        dao.insertCustodian(custodian)
    }

    suspend fun updateCustodian(custodian: Custodian) {
        dao.updateCustodian(custodian)
    }

    suspend fun deleteCustodian(custodian: Custodian) {
        dao.deleteCustodian(custodian)
    }

    suspend fun getCurrentCustodian(): Custodian? {
        return dao.getCurrentCustodian()
    }

    suspend fun insertClaim(claim: Claim) {
        dao.insertClaim(claim)
    }

    suspend fun updateClaim(claim: Claim) {
        dao.updateClaim(claim)
    }

    suspend fun deleteClaim(claim: Claim) {
        dao.deleteClaim(claim)
    }
}
