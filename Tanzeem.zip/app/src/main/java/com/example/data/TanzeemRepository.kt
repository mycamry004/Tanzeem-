package com.example.data

import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await

class TanzeemRepository(private val dao: TanzeemDao) { // dao kept for signature compatibility but unused
    private val db = FirebaseFirestore.getInstance()
    private val docRef = db.collection("community_data").document("current_state")

    val allMembers: Flow<List<Member>> = callbackFlow {
        val listener = docRef.addSnapshotListener { snapshot, error ->
            if (snapshot != null && snapshot.exists()) {
                val backup = snapshot.toObject(CloudBackup::class.java)
                trySend(backup?.members ?: emptyList())
            } else {
                trySend(emptyList())
            }
        }
        awaitClose { listener.remove() }
    }

    val allCustodians: Flow<List<Custodian>> = callbackFlow {
        val listener = docRef.addSnapshotListener { snapshot, error ->
            if (snapshot != null && snapshot.exists()) {
                val backup = snapshot.toObject(CloudBackup::class.java)
                trySend(backup?.custodians ?: emptyList())
            } else {
                trySend(emptyList())
            }
        }
        awaitClose { listener.remove() }
    }

    val allClaims: Flow<List<Claim>> = callbackFlow {
        val listener = docRef.addSnapshotListener { snapshot, error ->
            if (snapshot != null && snapshot.exists()) {
                val backup = snapshot.toObject(CloudBackup::class.java)
                trySend(backup?.claims ?: emptyList())
            } else {
                trySend(emptyList())
            }
        }
        awaitClose { listener.remove() }
    }

    val allNotifications: Flow<List<AppNotification>> = callbackFlow {
        val listener = docRef.addSnapshotListener { snapshot, error ->
            if (snapshot != null && snapshot.exists()) {
                val backup = snapshot.toObject(CloudBackup::class.java)
                trySend(backup?.notifications ?: emptyList())
            } else {
                trySend(emptyList())
            }
        }
        awaitClose { listener.remove() }
    }

    suspend fun getMembersCount(): Int {
        val snapshot = docRef.get().await()
        return if (snapshot.exists()) {
            snapshot.toObject(CloudBackup::class.java)?.members?.size ?: 0
        } else {
            0
        }
    }

    suspend fun insertMember(member: Member) {
        db.runTransaction { transaction ->
            val snapshot = transaction.get(docRef)
            val backup = if (snapshot.exists()) snapshot.toObject(CloudBackup::class.java) ?: CloudBackup() else CloudBackup()
            val newMembers = backup.members + member
            transaction.set(docRef, backup.copy(members = newMembers))
        }.await()
    }

    suspend fun updateMember(member: Member) {
        db.runTransaction { transaction ->
            val snapshot = transaction.get(docRef)
            val backup = if (snapshot.exists()) snapshot.toObject(CloudBackup::class.java) ?: CloudBackup() else CloudBackup()
            val newMembers = backup.members.map { if (it.id == member.id) member else it }
            transaction.set(docRef, backup.copy(members = newMembers))
        }.await()
    }

    suspend fun deleteMember(member: Member) {
        db.runTransaction { transaction ->
            val snapshot = transaction.get(docRef)
            val backup = if (snapshot.exists()) snapshot.toObject(CloudBackup::class.java) ?: CloudBackup() else CloudBackup()
            val newMembers = backup.members.filterNot { it.id == member.id }
            transaction.set(docRef, backup.copy(members = newMembers))
        }.await()
    }

    suspend fun insertCustodian(custodian: Custodian) {
        db.runTransaction { transaction ->
            val snapshot = transaction.get(docRef)
            val backup = if (snapshot.exists()) snapshot.toObject(CloudBackup::class.java) ?: CloudBackup() else CloudBackup()
            val newCustodians = backup.custodians + custodian
            transaction.set(docRef, backup.copy(custodians = newCustodians))
        }.await()
    }

    suspend fun updateCustodian(custodian: Custodian) {
        db.runTransaction { transaction ->
            val snapshot = transaction.get(docRef)
            val backup = if (snapshot.exists()) snapshot.toObject(CloudBackup::class.java) ?: CloudBackup() else CloudBackup()
            val newCustodians = backup.custodians.map { if (it.id == custodian.id) custodian else it }
            transaction.set(docRef, backup.copy(custodians = newCustodians))
        }.await()
    }

    suspend fun deleteCustodian(custodian: Custodian) {
        db.runTransaction { transaction ->
            val snapshot = transaction.get(docRef)
            val backup = if (snapshot.exists()) snapshot.toObject(CloudBackup::class.java) ?: CloudBackup() else CloudBackup()
            val newCustodians = backup.custodians.filterNot { it.id == custodian.id }
            transaction.set(docRef, backup.copy(custodians = newCustodians))
        }.await()
    }

    suspend fun getCurrentCustodian(): Custodian? {
        val snapshot = docRef.get().await()
        return if (snapshot.exists()) {
            val backup = snapshot.toObject(CloudBackup::class.java)
            backup?.custodians?.find { it.isCurrent }
        } else {
            null
        }
    }

    suspend fun insertClaim(claim: Claim) {
        db.runTransaction { transaction ->
            val snapshot = transaction.get(docRef)
            val backup = if (snapshot.exists()) snapshot.toObject(CloudBackup::class.java) ?: CloudBackup() else CloudBackup()
            val newClaims = backup.claims + claim
            transaction.set(docRef, backup.copy(claims = newClaims))
        }.await()
    }

    suspend fun updateClaim(claim: Claim) {
        db.runTransaction { transaction ->
            val snapshot = transaction.get(docRef)
            val backup = if (snapshot.exists()) snapshot.toObject(CloudBackup::class.java) ?: CloudBackup() else CloudBackup()
            val newClaims = backup.claims.map { if (it.id == claim.id) claim else it }
            transaction.set(docRef, backup.copy(claims = newClaims))
        }.await()
    }

    suspend fun deleteClaim(claim: Claim) {
        db.runTransaction { transaction ->
            val snapshot = transaction.get(docRef)
            val backup = if (snapshot.exists()) snapshot.toObject(CloudBackup::class.java) ?: CloudBackup() else CloudBackup()
            val newClaims = backup.claims.filterNot { it.id == claim.id }
            transaction.set(docRef, backup.copy(claims = newClaims))
        }.await()
    }

    suspend fun insertNotification(notification: AppNotification) {
        db.runTransaction { transaction ->
            val snapshot = transaction.get(docRef)
            val backup = if (snapshot.exists()) snapshot.toObject(CloudBackup::class.java) ?: CloudBackup() else CloudBackup()
            val newNotifications = backup.notifications + notification
            // Keep only last 100 notifications to prevent document getting too large
            val limitedNotifications = newNotifications.sortedByDescending { it.timestamp }.take(100)
            transaction.set(docRef, backup.copy(notifications = limitedNotifications))
        }.await()
    }
}
