package com.example.data

import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow

class TanzeemRepository(private val dao: TanzeemDao) {
    private val db = FirebaseFirestore.getInstance()
    private val docRef = db.collection("community_data").document("current_state")

    private var currentBackup: CloudBackup = CloudBackup()
    private var isLoaded = false
    
    private val _allMembers = MutableStateFlow<List<Member>>(emptyList())
    val allMembers: Flow<List<Member>> = _allMembers
    
    private val _allCustodians = MutableStateFlow<List<Custodian>>(emptyList())
    val allCustodians: Flow<List<Custodian>> = _allCustodians
    
    private val _allClaims = MutableStateFlow<List<Claim>>(emptyList())
    val allClaims: Flow<List<Claim>> = _allClaims
    
    private val _allNotifications = MutableStateFlow<List<AppNotification>>(emptyList())
    val allNotifications: Flow<List<AppNotification>> = _allNotifications
    
    private val _allDevices = MutableStateFlow<List<AppDevice>>(emptyList())
    val allDevices: Flow<List<AppDevice>> = _allDevices
    
    init {
        docRef.addSnapshotListener { snapshot, error ->
            if (snapshot != null && snapshot.exists()) {
                val backup = snapshot.toObject(CloudBackup::class.java) ?: CloudBackup()
                currentBackup = backup
                _allMembers.value = backup.members
                _allCustodians.value = backup.custodians
                _allClaims.value = backup.claims
                _allNotifications.value = backup.notifications
                _allDevices.value = backup.devices
            }
            isLoaded = true
        }
    }
    
    private suspend fun waitUntilLoaded() {
        while (!isLoaded) {
            kotlinx.coroutines.delay(100)
        }
    }

    private fun updateStateAndSync(newBackup: CloudBackup) {
        currentBackup = newBackup
        _allMembers.value = newBackup.members
        _allCustodians.value = newBackup.custodians
        _allClaims.value = newBackup.claims
        _allNotifications.value = newBackup.notifications
        _allDevices.value = newBackup.devices
        docRef.set(newBackup)
    }

    suspend fun registerOrUpdateDevice(device: AppDevice) {
        try {
            waitUntilLoaded()

            val mutableDevices = currentBackup.devices.toMutableList()
            val existingIdx = mutableDevices.indexOfFirst { it.deviceId == device.deviceId }
            
            if (existingIdx >= 0) {
                val existing = mutableDevices[existingIdx]
                mutableDevices[existingIdx] = device.copy(isBlocked = existing.isBlocked)
            } else {
                mutableDevices.add(device)
            }
            updateStateAndSync(currentBackup.copy(devices = mutableDevices))
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
    
    suspend fun toggleDeviceBlock(deviceId: String, block: Boolean) {
        try {
            waitUntilLoaded()

            val newDevices = currentBackup.devices.map { 
                if (it.deviceId == deviceId) it.copy(isBlocked = block) else it 
            }
            updateStateAndSync(currentBackup.copy(devices = newDevices))
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    suspend fun getMembersCount(): Int {
        return currentBackup.members.size
    }

    suspend fun insertMember(member: Member) {
        try {
            waitUntilLoaded()

            val finalMember = if (member.id == 0L) member.copy(id = System.currentTimeMillis() + currentBackup.members.size) else member
            val newMembers = currentBackup.members + finalMember
            updateStateAndSync(currentBackup.copy(members = newMembers))
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    suspend fun updateMember(member: Member) {
        try {
            waitUntilLoaded()

            val newMembers = currentBackup.members.map { 
                val matches = if (member.id != 0L) it.id == member.id else (it.name == member.name && it.qid == member.qid)
                if (matches) member else it 
            }
            updateStateAndSync(currentBackup.copy(members = newMembers))
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    suspend fun deleteMember(member: Member) {
        try {
            waitUntilLoaded()

            val newMembers = currentBackup.members.filterNot { 
                if (member.id != 0L) it.id == member.id else (it.name == member.name && it.qid == member.qid)
            }
            updateStateAndSync(currentBackup.copy(members = newMembers))
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    suspend fun insertCustodian(custodian: Custodian) {
        try {
            waitUntilLoaded()

            val finalCustodian = if (custodian.id == 0L) custodian.copy(id = System.currentTimeMillis() + currentBackup.custodians.size) else custodian
            val newCustodians = currentBackup.custodians + finalCustodian
            updateStateAndSync(currentBackup.copy(custodians = newCustodians))
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    
    
    suspend fun updateCustodiansList(newCustodians: List<Custodian>) {
        try {
            waitUntilLoaded()
            android.util.Log.d("TanzeemRepo", "updateCustodiansList called with ${newCustodians.size} items")
            newCustodians.forEach { c -> 
                android.util.Log.d("TanzeemRepo", "Custodian: ${c.name}, isCurrent=${c.isCurrent}, pass=${c.password}")
            }
            updateStateAndSync(currentBackup.copy(custodians = newCustodians))
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    
    suspend fun updateCustodian(custodian: Custodian) {
        try {
            waitUntilLoaded()

            val newCustodians = currentBackup.custodians.map { 
                val matches = if (custodian.id != 0L && it.id != 0L) it.id == custodian.id else it.name.trim().equals(custodian.name.trim(), ignoreCase = true)
                if (matches) custodian else it 
            }
            updateStateAndSync(currentBackup.copy(custodians = newCustodians))
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    suspend fun swapCustodiansOrder(c1: Custodian, c2: Custodian) {
        try {
            waitUntilLoaded()

            val newCustodians = currentBackup.custodians.map { 
                val matchesC1 = if (c1.id != 0L) it.id == c1.id else (it.name == c1.name && it.startDate == c1.startDate)
                val matchesC2 = if (c2.id != 0L) it.id == c2.id else (it.name == c2.name && it.startDate == c2.startDate)
                
                if (matchesC1) c1 
                else if (matchesC2) c2 
                else it 
            }
            updateStateAndSync(currentBackup.copy(custodians = newCustodians))
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    suspend fun deleteCustodian(custodian: Custodian) {
        try {
            waitUntilLoaded()

            val newCustodians = currentBackup.custodians.filterNot { 
                if (custodian.id != 0L && it.id != 0L) it.id == custodian.id else it.name.trim().equals(custodian.name.trim(), ignoreCase = true)
            }
            updateStateAndSync(currentBackup.copy(custodians = newCustodians))
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    suspend fun forceActiveCustodian(newActive: Custodian) {
        try {
            waitUntilLoaded()
            android.util.Log.d("TanzeemRepo", "forceActiveCustodian called for ${newActive.name}, id=${newActive.id}")
            val now = System.currentTimeMillis()
            val newCustodians = currentBackup.custodians.map {
                val matches = if (newActive.id != 0L && it.id != 0L) it.id == newActive.id else it.name.trim().equals(newActive.name.trim(), ignoreCase = true)
                android.util.Log.d("TanzeemRepo", "Checking ${it.name} id=${it.id}. Matches: $matches")
                if (matches) {
                    it.copy(isCurrent = true, isPast = false, tempPassword = "")
                } else if (it.isCurrent) {
                    // Old custodian who was active is now marked as past custodian
                    it.copy(
                        isCurrent = false,
                        isPast = true,
                        endDate = if (it.endDate > now) now else it.endDate
                    )
                } else {
                    it
                }
            }
            updateStateAndSync(currentBackup.copy(custodians = newCustodians))
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    suspend fun getCurrentCustodian(): Custodian? {
        return currentBackup.custodians.find { it.isCurrent }
    }

    suspend fun insertClaim(claim: Claim) {
        try {
            waitUntilLoaded()

            val finalClaim = if (claim.id == 0L) claim.copy(id = System.currentTimeMillis() + currentBackup.claims.size) else claim
            val newClaims = currentBackup.claims + finalClaim
            updateStateAndSync(currentBackup.copy(claims = newClaims))
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    suspend fun updateClaim(claim: Claim) {
        try {
            waitUntilLoaded()

            val newClaims = currentBackup.claims.map { 
                val matches = if (claim.id != 0L) it.id == claim.id else (it.deceasedName == claim.deceasedName && it.dateLogged == claim.dateLogged)
                if (matches) claim else it 
            }
            updateStateAndSync(currentBackup.copy(claims = newClaims))
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    suspend fun deleteClaim(claim: Claim) {
        try {
            waitUntilLoaded()

            val newClaims = currentBackup.claims.filterNot { 
                if (claim.id != 0L) it.id == claim.id else (it.deceasedName == claim.deceasedName && it.dateLogged == claim.dateLogged)
            }
            updateStateAndSync(currentBackup.copy(claims = newClaims))
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    suspend fun insertNotification(notification: AppNotification) {
        try {
            waitUntilLoaded()

            val newNotifications = currentBackup.notifications + notification
            // Keep only last 100 notifications to prevent document getting too large
            val limitedNotifications = newNotifications.sortedByDescending { it.timestamp }.take(100)
            updateStateAndSync(currentBackup.copy(notifications = limitedNotifications))
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}

