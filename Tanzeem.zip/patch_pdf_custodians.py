with open('app/src/main/java/com/example/MainActivity.kt', 'r') as f:
    content = f.read()

content = content.replace('val title = if (isUrdu) "رپورٹ نگران" else "Custodian History"', 'val title = if (isUrdu) "نگران کی فہرست" else "Custodian History"')

with open('app/src/main/java/com/example/MainActivity.kt', 'w') as f:
    f.write(content)
