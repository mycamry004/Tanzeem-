import re

with open('app/src/main/java/com/example/MainActivity.kt', 'r') as f:
    content = f.read()

target = """                    LazyColumn(modifier = Modifier.fillMaxWidth().heightIn(max = 400.dp)) {
                        items(notifications.sortedByDescending { it.timestamp }) { notif ->"""

replacement = """                    LazyColumn(modifier = Modifier.fillMaxWidth().heightIn(max = 400.dp)) {
                        // Synthetic periodic status
                        item {
                            val totalMembers = members.size
                            val currentBal = poolBalance
                            Column(modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
                                Text(
                                    text = if (isUrdu) "موجودہ فنڈ اسٹیٹس" else "Current Fund Status",
                                    color = GoldAccent,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = if (isUrdu) "کل ممبرز: $totalMembers\nموجودہ بیلنس: $currentBal QAR" else "Total Members: $totalMembers\nAvailable Balance: $currentBal QAR",
                                    color = Color.White,
                                    fontSize = 14.sp
                                )
                                HorizontalDivider(color = Color.White.copy(alpha = 0.1f), modifier = Modifier.padding(top = 8.dp))
                            }
                        }
                        
                        items(notifications.sortedByDescending { it.timestamp }) { notif ->"""

content = content.replace(target, replacement)

with open('app/src/main/java/com/example/MainActivity.kt', 'w') as f:
    f.write(content)
