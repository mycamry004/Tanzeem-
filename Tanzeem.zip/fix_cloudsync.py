import re
with open('app/src/main/java/com/example/data/CloudSyncManager.kt', 'r') as f:
    content = f.read()

content = content.replace(
    'suspend fun syncToCloudMsg(',
    'suspend fun syncToCloud('
)

# And fix the return type
old_func = """    suspend fun syncToCloud(
        members: List<Member>,
        claims: List<Claim>,
        custodians: List<Custodian>
    ): Boolean {"""

new_func = """    suspend fun syncToCloud(
        members: List<Member>,
        claims: List<Claim>,
        custodians: List<Custodian>
    ): Pair<Boolean, String> {"""
content = content.replace(old_func, new_func)

content = content.replace('if (db == null) return false', 'if (db == null) return Pair(false, "Firebase database not initialized")')
content = content.replace('cleanupOldBackups()\n            return true', 'cleanupOldBackups()\n            return Pair(true, "Success")')
content = content.replace('return false', 'return Pair(false, e.message ?: "Unknown error")')

with open('app/src/main/java/com/example/data/CloudSyncManager.kt', 'w') as f:
    f.write(content)
