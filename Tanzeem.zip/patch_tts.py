import re

content = open("app/src/main/java/com/example/MainActivity.kt").read()

tts_old = """            val locale = when {
                hasPashto -> java.util.Locale("ps")
                hasUrdu || isUrduText -> java.util.Locale("ur", "PK")
                else -> java.util.Locale.US
            }
            ttsInstance.language = locale"""

tts_new = """            val locale = when {
                hasPashto -> java.util.Locale("ps")
                hasUrdu || isUrduText -> java.util.Locale("ur", "PK")
                else -> java.util.Locale.US
            }
            
            ttsInstance.language = locale
            
            // Try to force a male voice for Urdu if available
            if (locale.language == "ur") {
                val voices = ttsInstance.voices
                if (voices != null) {
                    // Try to find a male network voice or local male voice
                    val maleUrduVoice = voices.firstOrNull { 
                        it.locale.language == "ur" && 
                        (it.name.contains("male", ignoreCase = true) || 
                         it.name.contains("-local", ignoreCase = true) ||
                         it.name.contains("network", ignoreCase = true)) 
                    }
                    if (maleUrduVoice != null) {
                        ttsInstance.voice = maleUrduVoice
                    }
                }
                
                // Adjust pitch slightly lower to simulate male voice if only female is available
                ttsInstance.setPitch(0.75f)
                ttsInstance.setSpeechRate(0.85f)
            } else {
                ttsInstance.setPitch(1.0f)
                ttsInstance.setSpeechRate(1.0f)
            }"""

content = content.replace(tts_old, tts_new)
open("app/src/main/java/com/example/MainActivity.kt", "w").write(content)
