import re
with open('app/src/main/java/com/example/MainActivity.kt', 'r') as f:
    content = f.read()

# Define the start and end of the block to replace
start_marker = "val speakText: (String, Boolean) -> Unit = { text, isUrduText ->"
end_marker = "val stopSpeaking: () -> Unit = {"

# Find the indices
start_idx = content.find(start_marker)
end_idx = content.find(end_marker)

if start_idx != -1 and end_idx != -1:
    new_speak_text = """val speakText: (String, Boolean) -> Unit = { text, isUrduText ->
        val ttsInstance = tts
        if (ttsInstance != null && isTtsReady) {
            ttsInstance.stop()
            // Clean the text to avoid reading out punctuation and symbols
            var cleanText = text.replace(Regex(\"\"\"[*()/\\[\\]{}<>_~]\"\"\"), " ")
            
            val hasPashto = cleanText.any { it in listOf('ښ', 'ځ', 'څ', 'ډ', 'ړ', 'ږ', 'ټ', 'ګ', 'ڼ', 'ې', 'ۍ') }
            val hasUrdu = cleanText.any { it.code in 0x0600..0x06FF } && !hasPashto
            
            // Try to set locale appropriately.
            val locale = when {
                hasPashto -> java.util.Locale("ps")
                hasUrdu || isUrduText -> java.util.Locale("ur", "PK")
                else -> java.util.Locale.US
            }
            ttsInstance.language = locale

            // Use completely normal pitch and speech rate for a natural human conversation sound.
            ttsInstance.setPitch(1.0f)
            ttsInstance.setSpeechRate(1.0f)

            try {
                val voices = ttsInstance.voices
                if (voices != null) {
                    // Try to find a male voice explicitly. 
                    // Google TTS often uses -B or -D for male voices, or explicit "male" features/names.
                    val maleVoice = voices.firstOrNull { 
                        it.locale.language == locale.language && 
                        (it.name.contains("male", ignoreCase = true) || 
                         it.name.endsWith("-B", ignoreCase = true) || 
                         it.name.endsWith("-D", ignoreCase = true))
                    }
                    if (maleVoice != null) {
                        ttsInstance.voice = maleVoice
                    }
                }
            } catch (e: Exception) {}

            // Android TTS max length is usually 4000. To prevent abrupt stops and make it sound natural, chunk the text.
            val chunkLength = 800
            val chunks = mutableListOf<String>()
            
            var remaining = cleanText
            while (remaining.isNotEmpty()) {
                if (remaining.length <= chunkLength) {
                    chunks.add(remaining)
                    break
                }
                
                // Try to find a natural break point (comma, period, newline) within the chunk
                val breakPoint = remaining.substring(0, chunkLength).lastIndexOfAny(charArrayOf('.', '۔', ',', '،', '?', '!', '\\n'))
                
                if (breakPoint > 0) {
                    chunks.add(remaining.substring(0, breakPoint + 1))
                    remaining = remaining.substring(breakPoint + 1).trim()
                } else {
                    // Force a break at a space
                    val spaceBreak = remaining.substring(0, chunkLength).lastIndexOf(' ')
                    if (spaceBreak > 0) {
                        chunks.add(remaining.substring(0, spaceBreak))
                        remaining = remaining.substring(spaceBreak + 1).trim()
                    } else {
                        // Hard break
                        chunks.add(remaining.substring(0, chunkLength))
                        remaining = remaining.substring(chunkLength)
                    }
                }
            }
            
            for (i in chunks.indices) {
                val chunk = chunks[i].trim()
                if (chunk.isNotEmpty()) {
                    val queueMode = if (i == 0) android.speech.tts.TextToSpeech.QUEUE_FLUSH else android.speech.tts.TextToSpeech.QUEUE_ADD
                    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
                        ttsInstance.speak(chunk, queueMode, null, "UtteranceId_$i")
                    } else {
                        @Suppress("DEPRECATION")
                        val params = hashMapOf(android.speech.tts.TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID to "UtteranceId_$i")
                        ttsInstance.speak(chunk, queueMode, params)
                    }
                }
            }
        }
    }
    """
    # Replace the text
    content = content[:start_idx] + new_speak_text + content[end_idx:]
    with open('app/src/main/java/com/example/MainActivity.kt', 'w') as f:
        f.write(content)
    print("TTS logic updated successfully.")
else:
    print("Could not find start or end marker.")
