import re
with open('app/src/main/java/com/example/data/CloudSyncManager.kt', 'r') as f:
    content = f.read()

content = content.replace('// Cleanup old backups (keep only last 30)', '// Cleanup old backups (keep only last 180 (6 months))')
content = content.replace('if (snapshot != null && snapshot.size() > 30)', 'if (snapshot != null && snapshot.size() > 180)')
content = content.replace('// Delete everything older than the 30th document', '// Delete everything older than the 180th document')
content = content.replace('for (i in 30 until snapshot.size())', 'for (i in 180 until snapshot.size())')

with open('app/src/main/java/com/example/data/CloudSyncManager.kt', 'w') as f:
    f.write(content)
