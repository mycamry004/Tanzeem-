import re

content = open("app/src/main/java/com/example/MainActivity.kt").read()

sort_pattern = r"val sortedCustodians = custodians\.sortedWith\(compareBy\(\{ !it\.isCurrent \}, \{ it\.orderIndex \}\)\)"

new_sort = """val nowTime = System.currentTimeMillis()
        val sortedCustodians = custodians.filter { it.isCurrent || it.endDate >= nowTime }
            .sortedWith(compareBy({ !it.isCurrent }, { it.orderIndex }))"""

content = content.replace(sort_pattern, new_sort)
open("app/src/main/java/com/example/MainActivity.kt", "w").write(content)
