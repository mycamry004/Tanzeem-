def parse(text):
    lines = text.split("\n")
    out = ""
    for i in range(len(lines)):
        line = lines[i]
        trimmed = line.lstrip()
        indent = len(line) - len(trimmed)
        if trimmed.startswith("* "):
            out += " " * indent + "•  "
            line = trimmed[2:]
        
        parts = line.split("**")
        for j in range(len(parts)):
            if j % 2 != 0 and len(parts) > 1:
                out += f"<b>{parts[j]}</b>"
            else:
                italic_parts = parts[j].split("*")
                for k in range(len(italic_parts)):
                    if k % 2 != 0 and len(italic_parts) > 1:
                        out += f"<i>{italic_parts[k]}</i>"
                    else:
                        out += italic_parts[k]
        
        if i < len(lines) - 1:
            out += "\n"
    return out

s = """Respected Member,

According to the Constitution:
* **Scenario A:**
  * **Benefit:** Total Registered Members
  * **Cap:** **5,000 QAR**
*Note: Any surplus amount...*"""

print(parse(s))
