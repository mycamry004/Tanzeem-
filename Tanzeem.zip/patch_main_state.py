import re

with open('app/src/main/java/com/example/MainActivity.kt', 'r') as f:
    content = f.read()

target = """    var showLanguageDialog by remember { mutableStateOf(false) }"""
replacement = """    var showLanguageDialog by remember { mutableStateOf(false) }
    var showNotifications by remember { mutableStateOf(false) }"""

content = content.replace(target, replacement)

# Check missing imports for LazyColumn, items, Divider
if "import androidx.compose.foundation.lazy.LazyColumn" not in content:
    content = content.replace("import androidx.compose.foundation.layout.*", "import androidx.compose.foundation.layout.*\nimport androidx.compose.foundation.lazy.LazyColumn\nimport androidx.compose.foundation.lazy.items\nimport androidx.compose.material3.HorizontalDivider")

if "Divider(" in content:
    content = content.replace("Divider(", "HorizontalDivider(")

with open('app/src/main/java/com/example/MainActivity.kt', 'w') as f:
    f.write(content)

