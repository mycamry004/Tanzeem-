import re
content = open("app/src/main/java/com/example/data/TanzeemRepository.kt").read()

func = """
    suspend fun updateCustodiansList(newCustodians: List<Custodian>) {
        try {
            waitUntilLoaded()
            android.util.Log.d("TanzeemRepo", "updateCustodiansList called with ${newCustodians.size} items")
            newCustodians.forEach { c -> 
                android.util.Log.d("TanzeemRepo", "Custodian: ${c.name}, isCurrent=${c.isCurrent}, pass=${c.password}")
            }
            updateStateAndSync(currentBackup.copy(custodians = newCustodians))
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
"""

content = re.sub(r"suspend fun updateCustodiansList\(newCustodians: List<Custodian>\) \{.*?catch \(e: Exception\) \{\s*e\.printStackTrace\(\)\s*\}\s*\}", func, content, flags=re.DOTALL)

open("app/src/main/java/com/example/data/TanzeemRepository.kt", "w").write(content)
