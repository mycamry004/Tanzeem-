import sys
content = open("app/src/main/java/com/example/MainActivity.kt").read()
import re

card_pattern = r"Card\(\s*colors = CardDefaults\.cardColors\(\s*containerColor = if \(isCurrent\) DarkSlateSurfaceVariant else DarkSlateSurface\s*\),\s*shape = RoundedCornerShape\(10\.dp\),\s*border = BorderStroke\(1\.dp, if \(isCurrent\) GoldAccent else TextMuted\.copy\(alpha = 0\.1f\)\),\s*modifier = Modifier\.fillMaxWidth\(\)\s*\) \{\s*Row\(\s*modifier = Modifier\.padding\(14\.dp\)\.fillMaxWidth\(\),\s*verticalAlignment = Alignment\.CenterVertically,\s*horizontalArrangement = Arrangement\.SpaceBetween\s*\) \{\s*Row\(verticalAlignment = Alignment\.CenterVertically\) \{"

new_card = """Card(
                colors = CardDefaults.cardColors(
                    containerColor = if (isCurrent) DarkSlateSurfaceVariant else DarkSlateSurface
                ),
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(1.dp, if (isCurrent) GoldAccent else TextMuted.copy(alpha = 0.1f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .let { baseModifier ->
                        if (isAdminMode) {
                            baseModifier.pointerInput(Unit) {
                                detectTapGestures(
                                    onDoubleTap = {
                                        if (!isCurrent) {
                                            showAdminHandoverDialog = custodian
                                        }
                                    }
                                )
                            }
                        } else baseModifier
                    }
            ) {
                Row(
                    modifier = Modifier.padding(14.dp).fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {"""

content = re.sub(card_pattern, new_card, content, flags=re.DOTALL)

open("app/src/main/java/com/example/MainActivity.kt", "w").write(content)
