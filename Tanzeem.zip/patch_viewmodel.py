import re

with open('app/src/main/java/com/example/ui/TatViewModel.kt', 'r') as f:
    content = f.read()

target = """                // Automatically sync down from cloud to ensure source of truth is maintained
                val backup = com.example.data.CloudSyncManager.fetchCurrentState()
                if (backup != null && (backup.members.isNotEmpty() || backup.custodians.isNotEmpty())) {
                    dao.deleteAllMembers()
                    dao.deleteAllClaims()
                    dao.deleteAllCustodians()
                    backup.members.forEach { dao.insertMember(it) }
                    backup.claims.forEach { dao.insertClaim(it) }
                    backup.custodians.forEach { dao.insertCustodian(it) }
                }"""

if target in content:
    content = content.replace(target, "")
    with open('app/src/main/java/com/example/ui/TatViewModel.kt', 'w') as f:
        f.write(content)
    print("Patched init block successfully")
else:
    print("Target init block not found")

target_restore = """    fun restoreFromCloud() {
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            try {
                val backup = com.example.data.CloudSyncManager.fetchCurrentState()
                if (backup != null) {
                    val dao = database.tanzeemDao()
                    dao.deleteAllMembers()
                    dao.deleteAllClaims()
                    dao.deleteAllCustodians()
                    backup.members.forEach { dao.insertMember(it) }
                    backup.claims.forEach { dao.insertClaim(it) }
                    backup.custodians.forEach { dao.insertCustodian(it) }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }"""

if target_restore in content:
    content = content.replace(target_restore, """    fun restoreFromCloud() {
        // Obsolete in Cloud-Native architecture. 
        // Real-time listener already handles this automatically.
    }""")
    with open('app/src/main/java/com/example/ui/TatViewModel.kt', 'w') as f:
        f.write(content)
    print("Patched restoreFromCloud successfully")
else:
    print("Target restoreFromCloud not found")
