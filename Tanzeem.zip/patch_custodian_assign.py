import re

with open('app/src/main/java/com/example/MainActivity.kt', 'r') as f:
    content = f.read()

target_modal_button = """                    Button(
                        onClick = { showAssignModal = true },
                        colors = ButtonDefaults.buttonColors(containerColor = DarkSlateSurfaceVariant),
                        border = BorderStroke(1.dp, GoldAccent),
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .testTag("assign_future_custodian_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.PersonAdd,
                            contentDescription = "Assign",
                            tint = GoldAccent,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = Translations.getString("futureCustodian", isUrdu),
                            color = GoldAccent,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            lineHeight = 12.sp,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                    }"""

replacement_modal_button = """                    // Removed Assign Modal Button since list is shown below"""

content = content.replace(target_modal_button, replacement_modal_button)

target_assign_modal_block = """    // --- ASSIGN FUTURE CUSTODIAN DIALOG ---
    if (showAssignModal) {"""

# Replace from target_assign_modal_block up to the end of the dialog block.
# Actually it's easier to just append the member list to the LazyColumn in CustodiansTabScreen

target_lazy_end = """        // Handover Buttons (Only for Administrators)
        if (isAdminMode) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth().height(androidx.compose.foundation.layout.IntrinsicSize.Min),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = { showHandoverModal = true },
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .testTag("handover_pool_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "Handover",
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = Translations.getString("handoverPool", isUrdu).substringBefore(" "),
                            color = Color.White,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            lineHeight = 12.sp,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                    }
                    // Removed Assign Modal Button since list is shown below
                }
            }
        }
    }"""

replacement_lazy_end = """        // Handover Buttons (Only for Administrators)
        if (isAdminMode) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth().height(androidx.compose.foundation.layout.IntrinsicSize.Min),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = { showHandoverModal = true },
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .testTag("handover_pool_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "Handover",
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = Translations.getString("handoverPool", isUrdu).substringBefore(" "),
                            color = Color.White,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            lineHeight = 12.sp,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                    }
                }
            }
            
            item {
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = "Assign Next Custodian (Admin Only)",
                    color = GoldAccent,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            
            items(members) { member ->
                val isAlreadyCustodian = custodians.any { it.name == member.name }
                if (!isAlreadyCustodian) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = DarkSlateSurface),
                        shape = RoundedCornerShape(8.dp),
                        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.1f)),
                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(text = member.name, color = TextOffWhite, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Text(text = member.phone, color = TextMuted, fontSize = 11.sp)
                            }
                            IconButton(
                                onClick = {
                                    val newOrder = (custodians.maxOfOrNull { it.orderIndex } ?: -1) + 1
                                    val now = System.currentTimeMillis()
                                    val threeMonths = Calendar.getInstance().apply { 
                                        timeInMillis = now
                                        add(Calendar.MONTH, 3)
                                    }.timeInMillis
                                    viewModel.addCustodian(
                                        Custodian(
                                            name = member.name,
                                            phone = member.phone,
                                            startDate = now,
                                            endDate = threeMonths,
                                            isCurrent = false,
                                            orderIndex = newOrder,
                                            password = (1000..9999).random().toString(),
                                            tempPassword = ""
                                        )
                                    )
                                    android.widget.Toast.makeText(context, "Added to Custodian Queue", android.widget.Toast.LENGTH_SHORT).show()
                                },
                                modifier = Modifier.size(32.dp).background(EmeraldPrimary.copy(alpha = 0.2f), CircleShape).border(1.dp, EmeraldLight, CircleShape)
                            ) {
                                Icon(Icons.Default.Check, contentDescription = "Assign", tint = EmeraldLight, modifier = Modifier.size(16.dp))
                            }
                        }
                    }
                }
            }
        }
    }"""

content = content.replace(target_lazy_end, replacement_lazy_end)

with open('app/src/main/java/com/example/MainActivity.kt', 'w') as f:
    f.write(content)
