import re
content = open("app/src/main/java/com/example/ui/TatViewModel.kt").read()

pattern = r"(repository\.updateCustodiansList\(newCustodians\))"
replacement = r"""android.util.Log.d("TatViewModel", "Calling updateCustodiansList")
            \1"""

content = re.sub(pattern, replacement, content)
open("app/src/main/java/com/example/ui/TatViewModel.kt", "w").write(content)
