import re

with open('app/src/main/java/com/example/MainActivity.kt', 'r') as f:
    content = f.read()

# Replace WhatsApp Box
target_whatsapp = """                                // WhatsApp Group Quick Action Icon Button
                                Box(
                                    modifier = Modifier
                                        .size(32.dp)
                                        .clip(CircleShape)
                                        .background(Color(0xFF25D366))
                                        .clickable {
                                            uriHandler.openUri("https://chat.whatsapp.com/Dj1WTCHJ4A1JpEU5cgUNNV?s=cl&p=a&ilr=4")
                                        }
                                        .testTag("top_bar_whatsapp_button"),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "W",
                                        color = Color.White,
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Black,
                                        fontFamily = androidx.compose.ui.text.font.FontFamily.SansSerif
                                    )
                                }"""
                                
replacement_whatsapp = """                                // WhatsApp Group Quick Action Icon Button
                                Box(
                                    modifier = Modifier
                                        .size(32.dp)
                                        .clip(CircleShape)
                                        .background(Color.Black.copy(alpha = 0.2f))
                                        .border(BorderStroke(1.dp, Color.White.copy(alpha = 0.25f)), CircleShape)
                                        .clickable {
                                            uriHandler.openUri("https://chat.whatsapp.com/Dj1WTCHJ4A1JpEU5cgUNNV?s=cl&p=a&ilr=4")
                                        }
                                        .testTag("top_bar_whatsapp_button"),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "W",
                                        color = Color.White,
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Black,
                                        fontFamily = androidx.compose.ui.text.font.FontFamily.SansSerif
                                    )
                                }"""
content = content.replace(target_whatsapp, replacement_whatsapp)

# Replace Apple PWA Box
target_apple = """                                // Apple iOS PWA Sync Info Dialog Icon Button
                                var showApplePwaDialog by remember { mutableStateOf(false) }
                                Box(
                                    modifier = Modifier
                                        .size(32.dp)
                                        .clip(CircleShape)
                                        .background(Color.White.copy(alpha = 0.15f))
                                        .border(BorderStroke(1.dp, Color.White.copy(alpha = 0.3f)), CircleShape)
                                        .clickable {
                                            showApplePwaDialog = true
                                        }
                                        .testTag("top_bar_apple_button"),
                                    contentAlignment = Alignment.Center
                                ) {
                                    AppleLogoIcon(
                                        modifier = Modifier.size(16.dp),
                                        tint = Color.White
                                    )
                                }"""
                                
replacement_apple = """                                // Apple iOS PWA Sync Info Dialog Icon Button
                                var showApplePwaDialog by remember { mutableStateOf(false) }
                                Box(
                                    modifier = Modifier
                                        .size(32.dp)
                                        .clip(CircleShape)
                                        .background(Color.Black.copy(alpha = 0.2f))
                                        .border(BorderStroke(1.dp, Color.White.copy(alpha = 0.25f)), CircleShape)
                                        .clickable {
                                            showApplePwaDialog = true
                                        }
                                        .testTag("top_bar_apple_button"),
                                    contentAlignment = Alignment.Center
                                ) {
                                    AppleLogoIcon(
                                        modifier = Modifier.size(16.dp),
                                        tint = Color.White
                                    )
                                }"""
content = content.replace(target_apple, replacement_apple)

# Rearrange and fix spacing for Notifications and Language
target_bottom_icons = """                                // Theme Toggle Button
                                Box(
                                    modifier = Modifier
                                        .size(32.dp)
                                        .clip(CircleShape)
                                        .background(Color.Black.copy(alpha = 0.2f))
                                        .border(BorderStroke(1.dp, Color.White.copy(alpha = 0.25f)), CircleShape)
                                        .clickable { viewModel.toggleTheme() }
                                        .testTag("app_theme_toggle_button"),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = if (isSystemInDarkTheme) Icons.Default.WbSunny else Icons.Default.NightsStay,
                                        contentDescription = "Toggle Theme",
                                        tint = Color.White,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                                // Notifications
                                Box(
                                    modifier = Modifier
                                        .size(32.dp)
                                        .clip(CircleShape)
                                        .background(Color.Black.copy(alpha = 0.2f))
                                        .border(BorderStroke(1.dp, Color.White.copy(alpha = 0.25f)), CircleShape)
                                        .clickable { showNotifications = true },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Notifications,
                                        contentDescription = "Notifications",
                                        tint = Color.White,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                // Language Selector Globe Button
                                Box(
                                    modifier = Modifier
                                        .size(32.dp)
                                        .clip(CircleShape)
                                        .background(Color.Black.copy(alpha = 0.2f))
                                        .border(BorderStroke(1.dp, Color.White.copy(alpha = 0.25f)), CircleShape)
                                        .clickable { showLanguageDialog = true }
                                        .testTag("app_language_globe_button"),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = if (isUrdu) "E" else "U",
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White,
                                        fontSize = 14.sp
                                    )
                                }"""

replacement_bottom_icons = """                                // Theme Toggle Button
                                Box(
                                    modifier = Modifier
                                        .size(32.dp)
                                        .clip(CircleShape)
                                        .background(Color.Black.copy(alpha = 0.2f))
                                        .border(BorderStroke(1.dp, Color.White.copy(alpha = 0.25f)), CircleShape)
                                        .clickable { viewModel.toggleTheme() }
                                        .testTag("app_theme_toggle_button"),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = if (isSystemInDarkTheme) Icons.Default.WbSunny else Icons.Default.NightsStay,
                                        contentDescription = "Toggle Theme",
                                        tint = Color.White,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                                // Language Selector Globe Button
                                Box(
                                    modifier = Modifier
                                        .size(32.dp)
                                        .clip(CircleShape)
                                        .background(Color.Black.copy(alpha = 0.2f))
                                        .border(BorderStroke(1.dp, Color.White.copy(alpha = 0.25f)), CircleShape)
                                        .clickable { showLanguageDialog = true }
                                        .testTag("app_language_globe_button"),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = if (isUrdu) "E" else "U",
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White,
                                        fontSize = 14.sp
                                    )
                                }
                                // Notifications (Far Right)
                                Box(
                                    modifier = Modifier
                                        .size(32.dp)
                                        .clip(CircleShape)
                                        .background(Color.Black.copy(alpha = 0.2f))
                                        .border(BorderStroke(1.dp, Color.White.copy(alpha = 0.25f)), CircleShape)
                                        .clickable { showNotifications = true },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Notifications,
                                        contentDescription = "Notifications",
                                        tint = Color.White,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }"""

content = content.replace(target_bottom_icons, replacement_bottom_icons)

with open('app/src/main/java/com/example/MainActivity.kt', 'w') as f:
    f.write(content)
