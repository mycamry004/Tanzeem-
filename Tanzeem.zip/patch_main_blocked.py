import re

with open('app/src/main/java/com/example/MainActivity.kt', 'r') as f:
    content = f.read()

target = """    val claims by viewModel.claims.collectAsStateWithLifecycle()
    val poolBalance by viewModel.poolBalance.collectAsStateWithLifecycle()
    var showWelcomeScreen by remember { mutableStateOf(true) }"""

replacement = """    val claims by viewModel.claims.collectAsStateWithLifecycle()
    val poolBalance by viewModel.poolBalance.collectAsStateWithLifecycle()
    val devices by viewModel.devices.collectAsStateWithLifecycle()
    
    val myDevice = devices.find { it.deviceId == viewModel.currentDeviceId }
    if (myDevice?.isBlocked == true) {
        Box(modifier = Modifier.fillMaxSize().background(Color.Black), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(32.dp)) {
                Icon(Icons.Default.Block, contentDescription = "Blocked", tint = Color.Red, modifier = Modifier.size(64.dp))
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = if (isUrdu) "سیکیورٹی وجوہات کی بنا پر اس ڈیوائس کو بلاک کر دیا گیا ہے۔ ایڈمن سے رابطہ کریں۔" else "This device has been blocked for security reasons. Contact admin.",
                    color = Color.White,
                    fontSize = 16.sp,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                )
            }
        }
        return
    }

    var showWelcomeScreen by remember { mutableStateOf(true) }"""

content = content.replace(target, replacement)

with open('app/src/main/java/com/example/MainActivity.kt', 'w') as f:
    f.write(content)
