import re

with open('app/src/main/java/com/example/data/TanzeemRepository.kt', 'r') as f:
    content = f.read()

target = """    val allNotifications: Flow<List<AppNotification>> = callbackFlow {
        val listener = docRef.addSnapshotListener { snapshot, error ->
            if (snapshot != null && snapshot.exists()) {
                val backup = snapshot.toObject(CloudBackup::class.java)
                trySend(backup?.notifications ?: emptyList())
            } else {
                trySend(emptyList())
            }
        }
        awaitClose { listener.remove() }
    }"""

replacement = """    val allNotifications: Flow<List<AppNotification>> = callbackFlow {
        val listener = docRef.addSnapshotListener { snapshot, error ->
            if (snapshot != null && snapshot.exists()) {
                val backup = snapshot.toObject(CloudBackup::class.java)
                trySend(backup?.notifications ?: emptyList())
            } else {
                trySend(emptyList())
            }
        }
        awaitClose { listener.remove() }
    }

    val allDevices: Flow<List<AppDevice>> = callbackFlow {
        val listener = docRef.addSnapshotListener { snapshot, error ->
            if (snapshot != null && snapshot.exists()) {
                val backup = snapshot.toObject(CloudBackup::class.java)
                trySend(backup?.devices ?: emptyList())
            } else {
                trySend(emptyList())
            }
        }
        awaitClose { listener.remove() }
    }
    
    suspend fun registerOrUpdateDevice(device: AppDevice) {
        db.runTransaction { transaction ->
            val snapshot = transaction.get(docRef)
            val backup = if (snapshot.exists()) snapshot.toObject(CloudBackup::class.java) ?: CloudBackup() else CloudBackup()
            
            val mutableDevices = backup.devices.toMutableList()
            val existingIdx = mutableDevices.indexOfFirst { it.deviceId == device.deviceId }
            
            if (existingIdx >= 0) {
                // Preserve block status if exists, update lastActive
                val existing = mutableDevices[existingIdx]
                mutableDevices[existingIdx] = device.copy(isBlocked = existing.isBlocked)
            } else {
                mutableDevices.add(device)
            }
            
            transaction.set(docRef, backup.copy(devices = mutableDevices))
        }.await()
    }
    
    suspend fun toggleDeviceBlock(deviceId: String, block: Boolean) {
        db.runTransaction { transaction ->
            val snapshot = transaction.get(docRef)
            val backup = if (snapshot.exists()) snapshot.toObject(CloudBackup::class.java) ?: CloudBackup() else CloudBackup()
            
            val newDevices = backup.devices.map { 
                if (it.deviceId == deviceId) it.copy(isBlocked = block) else it 
            }
            transaction.set(docRef, backup.copy(devices = newDevices))
        }.await()
    }"""

content = content.replace(target, replacement)

with open('app/src/main/java/com/example/data/TanzeemRepository.kt', 'w') as f:
    f.write(content)
