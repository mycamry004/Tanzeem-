import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

# 1. Signature update
old_sig = """fun generatePdf(context: android.content.Context, filename: String, title: String, headers: List<String>, data: List<List<String>>, theme: String): java.io.File {"""
new_sig = """fun generatePdf(context: android.content.Context, filename: String, title: String, headers: List<String>, data: List<List<String>>, theme: String, colWeights: List<Float>? = null): java.io.File {"""
content = content.replace(old_sig, new_sig)

# 2. Remove Logo Logic
old_logo = """    // Logo
    var scaledLogo: android.graphics.Bitmap? = null
    try {
        val originalLogo = android.graphics.BitmapFactory.decodeResource(context.resources, R.drawable.tat_emblem)
        if (originalLogo != null) {
            scaledLogo = android.graphics.Bitmap.createScaledBitmap(originalLogo, 70, 70, true)
        }
    } catch (e: Exception) {
        e.printStackTrace()
    }"""
content = content.replace(old_logo, "")

# 3. Modify drawHeader
old_draw_header = """        var leftContentX = marginLeft
        if (!isOrange) { leftContentX = marginLeft + 60f } // Push right if blue shape is there
        
        if (scaledLogo != null) {
            c.drawBitmap(scaledLogo!!, leftContentX, currentY - 10f, null)
            leftContentX += 85f
        }"""
new_draw_header = """        var leftContentX = marginLeft
        if (!isOrange) { leftContentX = marginLeft + 60f } // Push right if blue shape is there
"""
content = content.replace(old_draw_header, new_draw_header)

# 4. Modify Table Drawing Logic
old_table_logic = """    val colWidths = FloatArray(headers.size)
    val columnWidth = contentWidth / headers.size.toFloat()
    for (i in headers.indices) colWidths[i] = columnWidth
    
    val headerRowHeight = 35f
    canvas.drawRect(marginLeft, currentY, pageWidth - marginRight, currentY + headerRowHeight, paintPrimary)
    for ((index, header) in headers.withIndex()) {
        val cellX = marginLeft + (index * columnWidth)
        canvas.drawText(header, cellX + 10f, currentY + 22f, paintHeaderText)
        if (index > 0) canvas.drawLine(cellX, currentY, cellX, currentY + headerRowHeight, paintBorder)
    }
    canvas.drawRect(marginLeft, currentY, pageWidth - marginRight, currentY + headerRowHeight, paintBorder)
    
    currentY += headerRowHeight
    
    val rowHeight = 30f
    for ((rowIndex, row) in data.withIndex()) {
        if (currentY + rowHeight > pageHeight - marginBottom) {
            pdfDocument.finishPage(page)
            page = pdfDocument.startPage(pageInfo)
            canvas = page.canvas
            currentY = drawHeader(canvas)
            
            canvas.drawRect(marginLeft, currentY, pageWidth - marginRight, currentY + headerRowHeight, paintPrimary)
            for ((index, header) in headers.withIndex()) {
                val cellX = marginLeft + (index * columnWidth)
                canvas.drawText(header, cellX + 10f, currentY + 22f, paintHeaderText)
                if (index > 0) canvas.drawLine(cellX, currentY, cellX, currentY + headerRowHeight, paintBorder)
            }
            canvas.drawRect(marginLeft, currentY, pageWidth - marginRight, currentY + headerRowHeight, paintBorder)
            currentY += headerRowHeight
        }
        
        if (rowIndex % 2 != 0) {
            canvas.drawRect(marginLeft, currentY, pageWidth - marginRight, currentY + rowHeight, paintRowBgAlt)
        }
        
        for ((colIndex, cell) in row.withIndex()) {
            var text = cell
            val maxTextWidth = columnWidth - 20f
            val measured = paintCellText.measureText(text)
            if (measured > maxTextWidth) {
                val charsToKeep = (maxTextWidth / (measured / text.length)).toInt()
                if (charsToKeep > 0 && charsToKeep < text.length) {
                    text = text.substring(0, charsToKeep - 2) + ".."
                }
            }
            
            val cellX = marginLeft + (colIndex * columnWidth)
            canvas.drawText(text, cellX + 10f, currentY + 20f, paintCellText)
            if (colIndex > 0) canvas.drawLine(cellX, currentY, cellX, currentY + rowHeight, paintBorder)
        }
        canvas.drawRect(marginLeft, currentY, pageWidth - marginRight, currentY + rowHeight, paintBorder)
        
        currentY += rowHeight
    }"""

new_table_logic = """    val colWidths = FloatArray(headers.size)
    if (colWeights != null && colWeights.size == headers.size) {
        val totalW = colWeights.sum()
        for (i in headers.indices) colWidths[i] = (colWeights[i] / totalW) * contentWidth
    } else {
        val cw = contentWidth / headers.size.toFloat()
        for (i in headers.indices) colWidths[i] = cw
    }
    
    val colStartX = FloatArray(headers.size)
    var curX = marginLeft
    for (i in headers.indices) {
        colStartX[i] = curX
        curX += colWidths[i]
    }
    
    val headerRowHeight = 35f
    canvas.drawRect(marginLeft, currentY, pageWidth - marginRight, currentY + headerRowHeight, paintPrimary)
    for ((index, header) in headers.withIndex()) {
        val cellX = colStartX[index]
        canvas.drawText(header, cellX + 5f, currentY + 22f, paintHeaderText)
        if (index > 0) canvas.drawLine(cellX, currentY, cellX, currentY + headerRowHeight, paintBorder)
    }
    canvas.drawRect(marginLeft, currentY, pageWidth - marginRight, currentY + headerRowHeight, paintBorder)
    
    currentY += headerRowHeight
    
    val baseRowHeight = 30f
    for ((rowIndex, row) in data.withIndex()) {
        // Calculate max lines for this row
        var maxLines = 1
        for (cell in row) {
            val lines = cell.split("\\n").size
            if (lines > maxLines) maxLines = lines
        }
        val rowHeight = baseRowHeight + (maxLines - 1) * 12f
        
        if (currentY + rowHeight > pageHeight - marginBottom) {
            pdfDocument.finishPage(page)
            page = pdfDocument.startPage(pageInfo)
            canvas = page.canvas
            currentY = drawHeader(canvas)
            
            canvas.drawRect(marginLeft, currentY, pageWidth - marginRight, currentY + headerRowHeight, paintPrimary)
            for ((index, header) in headers.withIndex()) {
                val cellX = colStartX[index]
                canvas.drawText(header, cellX + 5f, currentY + 22f, paintHeaderText)
                if (index > 0) canvas.drawLine(cellX, currentY, cellX, currentY + headerRowHeight, paintBorder)
            }
            canvas.drawRect(marginLeft, currentY, pageWidth - marginRight, currentY + headerRowHeight, paintBorder)
            currentY += headerRowHeight
        }
        
        if (rowIndex % 2 != 0) {
            canvas.drawRect(marginLeft, currentY, pageWidth - marginRight, currentY + rowHeight, paintRowBgAlt)
        }
        
        for ((colIndex, cell) in row.withIndex()) {
            val cellX = colStartX[colIndex]
            val cw = colWidths[colIndex]
            val lines = cell.split("\\n")
            
            for ((lineIdx, lineText) in lines.withIndex()) {
                var textToDraw = lineText
                val maxTextWidth = cw - 10f
                val measured = paintCellText.measureText(textToDraw)
                if (measured > maxTextWidth) {
                    val charsToKeep = (maxTextWidth / (measured / textToDraw.length)).toInt()
                    if (charsToKeep > 0 && charsToKeep < textToDraw.length) {
                        textToDraw = textToDraw.substring(0, charsToKeep - 2) + ".."
                    }
                }
                
                // For sub-lines (like the date under Yes), we can make text smaller or just draw it
                val yOffset = currentY + 20f + (lineIdx * 12f)
                val paintToUse = paintCellText
                canvas.drawText(textToDraw, cellX + 5f, yOffset, paintToUse)
            }
            if (colIndex > 0) canvas.drawLine(cellX, currentY, cellX, currentY + rowHeight, paintBorder)
        }
        canvas.drawRect(marginLeft, currentY, pageWidth - marginRight, currentY + rowHeight, paintBorder)
        
        currentY += rowHeight
    }"""

content = content.replace(old_table_logic, new_table_logic)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
print("generatePdf patched")
