import re

with open('app/src/main/java/com/example/MainActivity.kt', 'r') as f:
    content = f.read()

target1 = """                // Language Selector
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(Color.Black.copy(alpha = 0.2f))
                        .border(BorderStroke(1.dp, GoldAccent.copy(alpha = 0.8f)), CircleShape)
                        .clickable { showLanguageDialog = true }
                        .testTag("welcome_language_toggle"),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = if (isUrdu) "E" else "U",
                        fontWeight = FontWeight.Bold,
                        color = GoldAccent,
                        fontSize = 16.sp
                    )
                }"""
                
replacement1 = """                // Notifications
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(Color.Black.copy(alpha = 0.2f))
                        .border(BorderStroke(1.dp, GoldAccent.copy(alpha = 0.8f)), CircleShape)
                        .clickable { showNotifications = true },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Notifications,
                        contentDescription = "Notifications",
                        tint = GoldAccent,
                        modifier = Modifier.size(18.dp)
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
                // Language Selector
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(Color.Black.copy(alpha = 0.2f))
                        .border(BorderStroke(1.dp, GoldAccent.copy(alpha = 0.8f)), CircleShape)
                        .clickable { showLanguageDialog = true }
                        .testTag("welcome_language_toggle"),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = if (isUrdu) "E" else "U",
                        fontWeight = FontWeight.Bold,
                        color = GoldAccent,
                        fontSize = 16.sp
                    )
                }"""

content = content.replace(target1, replacement1)

target2 = """                                // Language Selector Globe Button
                                Box(
                                    modifier = Modifier
                                        .size(32.dp)
                                        .clip(CircleShape)
                                        .background(Color.Black.copy(alpha = 0.2f))
                                        .border(BorderStroke(1.dp, Color.White.copy(alpha = 0.25f)), CircleShape)
                                        .clickable { showLanguageDialog = true }
                                        .testTag("app_language_globe_button"),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = if (isUrdu) "E" else "U",
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White,
                                        fontSize = 14.sp
                                    )
                                }"""

replacement2 = """                                // Notifications
                                Box(
                                    modifier = Modifier
                                        .size(32.dp)
                                        .clip(CircleShape)
                                        .background(Color.Black.copy(alpha = 0.2f))
                                        .border(BorderStroke(1.dp, Color.White.copy(alpha = 0.25f)), CircleShape)
                                        .clickable { showNotifications = true },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Notifications,
                                        contentDescription = "Notifications",
                                        tint = Color.White,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                // Language Selector Globe Button
                                Box(
                                    modifier = Modifier
                                        .size(32.dp)
                                        .clip(CircleShape)
                                        .background(Color.Black.copy(alpha = 0.2f))
                                        .border(BorderStroke(1.dp, Color.White.copy(alpha = 0.25f)), CircleShape)
                                        .clickable { showLanguageDialog = true }
                                        .testTag("app_language_globe_button"),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = if (isUrdu) "E" else "U",
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White,
                                        fontSize = 14.sp
                                    )
                                }"""

content = content.replace(target2, replacement2)

with open('app/src/main/java/com/example/MainActivity.kt', 'w') as f:
    f.write(content)
