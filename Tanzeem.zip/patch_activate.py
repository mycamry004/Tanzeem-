import re
content = open("app/src/main/java/com/example/ui/TatViewModel.kt").read()

pattern = r"val newCustodians = list\.map \{ curr ->\s*val isTarget = if \(matchingCustodian\.id != 0L && curr\.id != 0L\) \{\s*curr\.id == matchingCustodian\.id\s*\} else \{\s*curr\.name == matchingCustodian\.name && curr\.startDate == matchingCustodian\.startDate\s*\}\s*if \(isTarget\) \{\s*// Promote this one\s*curr\.copy\(\s*isCurrent = true,\s*password = finalPassword,\s*tempPassword = \"\"\s*\)\s*\} else if \(curr\.isCurrent\) \{\s*// Demote old active custodian\(s\), but keep their password\s*curr\.copy\(\s*isCurrent = false\s*\)\s*\} else \{\s*curr\s*\}\s*\}"

replacement = """val newCustodians = list.map { curr ->
                // STRICT CHECK: Use name and startDate to identify the exact custodian securely.
                // Demote EVERYONE ELSE to guarantee there is only ONE active custodian.
                val isTarget = curr.name == matchingCustodian.name && curr.startDate == matchingCustodian.startDate
                
                if (isTarget) {
                    // Promote this one
                    curr.copy(
                        isCurrent = true,
                        password = finalPassword,
                        tempPassword = ""
                    )
                } else {
                    // Demote everyone else, but keep their passwords intact
                    curr.copy(
                        isCurrent = false
                    )
                }
            }"""

content = re.sub(pattern, replacement, content, flags=re.DOTALL)
open("app/src/main/java/com/example/ui/TatViewModel.kt", "w").write(content)
