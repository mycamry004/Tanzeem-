with open('app/src/main/java/com/example/MainActivity.kt', 'r') as f:
    content = f.read()

old_members = """fun exportMembersPdf(context: android.content.Context, members: List<Member>, isUrdu: Boolean): java.io.File {
    val title = if (isUrdu) "رپورٹ ممبران" else "Member Ledger"
    val headers = listOf("ID", "Name", "QID", "Phone", "Status", "Year 1", "Year 2", "Year 3")
    val colWeights = listOf(0.05f, 0.2f, 0.15f, 0.2f, 0.1f, 0.1f, 0.1f, 0.1f)
    val df = java.text.SimpleDateFormat("dd MMM yy", java.util.Locale.US)
    val data = members.map { m ->
        val y1Date = if (m.year1Paid && m.year1PaymentDate != null) m.year1PaymentDate else ""
        val y2Date = if (m.year2Paid && m.year2PaymentDate != null) m.year2PaymentDate else ""
        val y3Date = if (m.year3Paid && m.year3PaymentDate != null) m.year3PaymentDate else ""
        
        listOf(
            m.id.toString(),
            m.name,
            m.qid,
            m.phone,
            when(m.status) {
                "Active Qatar" -> "Active"
                "On Vacation" -> "Vacation"
                else -> "Left"
            },
            if (m.year1Paid) "Yes${if (y1Date.isNotEmpty()) "\\n$y1Date" else ""}" else "No",
            if (m.year2Paid) "Yes${if (y2Date.isNotEmpty()) "\\n$y2Date" else ""}" else "No",
            if (m.year3Paid) "Yes${if (y3Date.isNotEmpty()) "\\n$y3Date" else ""}" else "No"
        )
    }"""

new_members = """fun exportMembersPdf(context: android.content.Context, members: List<Member>, isUrdu: Boolean): java.io.File {
    val title = if (isUrdu) "ممبران کی فہرست" else "Member Ledger"
    val headers = listOf("ID", "Name", "QID", "Phone", "Status", "Year 1", "Year 2", "Year 3")
    val colWeights = listOf(0.04f, 0.18f, 0.14f, 0.22f, 0.09f, 0.11f, 0.11f, 0.11f)
    val df = java.text.SimpleDateFormat("dd MMM yy", java.util.Locale.US)
    val data = members.map { m ->
        val y1Date = if (m.year1Paid && m.year1PaymentDate != null) m.year1PaymentDate else ""
        val y2Date = if (m.year2Paid && m.year2PaymentDate != null) m.year2PaymentDate else ""
        val y3Date = if (m.year3Paid && m.year3PaymentDate != null) m.year3PaymentDate else ""
        
        listOf(
            m.id.toString(),
            m.name,
            m.qid,
            m.phone,
            when(m.status) {
                "Active Qatar" -> "Active"
                "On Vacation" -> "Vacation"
                else -> "Left"
            },
            if (m.year1Paid) (if (y1Date.isNotEmpty()) y1Date else "Paid") else "No",
            if (m.year2Paid) (if (y2Date.isNotEmpty()) y2Date else "Paid") else "No",
            if (m.year3Paid) (if (y3Date.isNotEmpty()) y3Date else "Paid") else "No"
        )
    }"""
content = content.replace(old_members, new_members)

with open('app/src/main/java/com/example/MainActivity.kt', 'w') as f:
    f.write(content)
