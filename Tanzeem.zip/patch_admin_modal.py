import re
content = open("app/src/main/java/com/example/MainActivity.kt").read()

admin_modal = """

    // --- ADMIN FORCED HANDOVER DIALOG ---
    showAdminHandoverDialog?.let { targetCustodian ->
        Dialog(onDismissRequest = { showAdminHandoverDialog = null; handoverCheckConfirmed = false }) {
            Card(
                colors = CardDefaults.cardColors(containerColor = DarkSlateSurface),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(2.dp, GoldAccent),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = "Handover",
                        tint = GoldAccent,
                        modifier = Modifier.size(36.dp)
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                    Text(
                        text = if (isUrdu) "ایڈمن ہینڈ اوور کی تصدیق" else "Admin Handover Confirmation",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextOffWhite
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = if (isUrdu) {
                            "آپ ${targetCustodian.name} کو نیا نگران بنانے جا رہے ہیں۔ عارضی پاس ورڈ تیار کیا جائے گا۔"
                        } else {
                            "You are about to initiate a handover to ${targetCustodian.name}. A temporary password will be generated."
                        },
                        fontSize = 12.sp,
                        color = TextOffWhite.copy(alpha = 0.9f),
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Card(
                        colors = CardDefaults.cardColors(containerColor = EmeraldDark),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = "${Translations.getString("totalPool", isUrdu)}: ${String.format(java.util.Locale.US, "%,.2f", poolBalance)} QAR",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = GoldAccent,
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { handoverCheckConfirmed = !handoverCheckConfirmed },
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(
                            checked = handoverCheckConfirmed,
                            onCheckedChange = { handoverCheckConfirmed = it },
                            colors = CheckboxDefaults.colors(checkedColor = EmeraldPrimary)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isUrdu) "میں تصدیق کرتا/کرتی ہوں کہ فنڈز اور ذمہ داریاں ${targetCustodian.name} کو دی جائیں گی" else "I confirm transferring custody to ${targetCustodian.name}",
                            fontSize = 10.sp,
                            color = TextOffWhite
                        )
                    }
                    Spacer(modifier = Modifier.height(24.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        TextButton(onClick = {
                            showAdminHandoverDialog = null
                            handoverCheckConfirmed = false
                        }) {
                            Text(Translations.getString("cancel", isUrdu), color = TextMuted)
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Button(
                            enabled = handoverCheckConfirmed,
                            onClick = {
                                viewModel.adminInitiateHandover(targetCustodian, poolBalance) { receipt, newPass, name, phone ->
                                    onHandoverTriggered(receipt, newPass, name, phone)
                                    showAdminHandoverDialog = null
                                    handoverCheckConfirmed = false
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
                        ) {
                            Text(Translations.getString("confirm", isUrdu), color = Color.White)
                        }
                    }
                }
            }
        }
    }
"""

if "ADMIN FORCED HANDOVER DIALOG" not in content:
    idx = content.find("    // --- ASSIGN FUTURE CUSTODIAN DIALOG ---")
    if idx != -1:
        content = content[:idx] + admin_modal + content[idx:]
        open("app/src/main/java/com/example/MainActivity.kt", "w").write(content)
