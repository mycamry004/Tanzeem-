import re

with open('app/src/main/java/com/example/MainActivity.kt', 'r') as f:
    content = f.read()

target = """fun MembersTabScreen(
    viewModel: TatViewModel,
    members: List<Member>,
    isAdminMode: Boolean,
    isUrdu: Boolean
) {"""

replacement = """fun MembersTabScreen(
    viewModel: TatViewModel,
    members: List<Member>,
    devices: List<AppDevice>,
    isAdminMode: Boolean,
    isUrdu: Boolean
) {"""

content = content.replace(target, replacement)

target2 = """                    1 -> MembersTabScreen(
                        viewModel = viewModel,
                        members = members,
                        isAdminMode = isAdminMode,
                        isUrdu = isUrdu
                    )"""
                    
replacement2 = """                    1 -> MembersTabScreen(
                        viewModel = viewModel,
                        members = members,
                        devices = devices,
                        isAdminMode = isAdminMode,
                        isUrdu = isUrdu
                    )"""

content = content.replace(target2, replacement2)

with open('app/src/main/java/com/example/MainActivity.kt', 'w') as f:
    f.write(content)
