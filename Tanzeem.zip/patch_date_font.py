import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

old_draw = """                // For sub-lines (like the date under Yes), we can make text smaller or just draw it
                val yOffset = currentY + 20f + (lineIdx * 12f)
                val paintToUse = paintCellText
                canvas.drawText(textToDraw, cellX + 5f, yOffset, paintToUse)"""

new_draw = """                // For sub-lines (like the date under Yes), we can make text smaller
                val isSubLine = lineIdx > 0
                val originalTextSize = paintCellText.textSize
                if (isSubLine) paintCellText.textSize = 8f
                
                // re-measure with new size
                var finalDrawText = textToDraw
                val mWidth = paintCellText.measureText(finalDrawText)
                if (mWidth > cw - 10f) {
                    val cKeep = ((cw - 10f) / (mWidth / finalDrawText.length)).toInt()
                    if (cKeep > 0 && cKeep < finalDrawText.length) {
                        finalDrawText = finalDrawText.substring(0, cKeep - 2) + ".."
                    }
                }
                
                val yOffset = currentY + 20f + (lineIdx * 12f)
                canvas.drawText(finalDrawText, cellX + 5f, yOffset, paintCellText)
                
                // restore
                paintCellText.textSize = originalTextSize"""

content = content.replace(old_draw, new_draw)

# And remove the first measureText logic that happens before drawing
old_measure = """                var textToDraw = lineText
                val maxTextWidth = cw - 10f
                val measured = paintCellText.measureText(textToDraw)
                if (measured > maxTextWidth) {
                    val charsToKeep = (maxTextWidth / (measured / textToDraw.length)).toInt()
                    if (charsToKeep > 0 && charsToKeep < textToDraw.length) {
                        textToDraw = textToDraw.substring(0, charsToKeep - 2) + ".."
                    }
                }
                
                // For sub-lines (like the date under Yes), we can make text smaller"""

new_measure = """                var textToDraw = lineText
                // For sub-lines (like the date under Yes), we can make text smaller"""

content = content.replace(old_measure, new_measure)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
print("Font size logic patched")
