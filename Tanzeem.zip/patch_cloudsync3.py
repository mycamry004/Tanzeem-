import re

with open('app/src/main/java/com/example/data/CloudSyncManager.kt', 'r') as f:
    content = f.read()

if 'kotlinx.coroutines.withTimeoutOrNull' not in content:
    content = content.replace('import kotlinx.coroutines.withTimeout', 'import kotlinx.coroutines.withTimeoutOrNull')

content = content.replace('kotlinx.coroutines.withTimeout(', 'kotlinx.coroutines.withTimeoutOrNull(')

with open('app/src/main/java/com/example/data/CloudSyncManager.kt', 'w') as f:
    f.write(content)
