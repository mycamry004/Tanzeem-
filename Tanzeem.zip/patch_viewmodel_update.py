import re

with open('app/src/main/java/com/example/ui/TatViewModel.kt', 'r') as f:
    content = f.read()

target = """    fun updateMember(member: Member) {
        viewModelScope.launch {
            repository.updateMember(member)
            // More granular notification could be added for payments vs edits
            logAction(
                "Updated member: ${member.name}",
                "ممبر کی معلومات اپ ڈیٹ کی گئیں: ${member.name}"
            )
        }
    }"""

replacement = """    fun updateMember(member: Member) {
        viewModelScope.launch {
            val oldMember = members.value.find { it.id == member.id }
            repository.updateMember(member)
            
            if (oldMember != null) {
                // Check if payment was made
                val paidNew = (member.year1Paid && !oldMember.year1Paid) || 
                              (member.year2Paid && !oldMember.year2Paid) || 
                              (member.year3Paid && !oldMember.year3Paid) ||
                              (member.surplusPaid && !oldMember.surplusPaid)
                              
                val statusChanged = member.status != oldMember.status
                
                if (paidNew) {
                    logAction(
                        "Payment received from: ${member.name}",
                        "${member.name} سے رقم وصول کی گئی"
                    )
                } else if (statusChanged) {
                    logAction(
                        "Status changed for ${member.name} to ${member.status}",
                        "${member.name} کا اسٹیٹس ${member.status} میں تبدیل ہو گیا"
                    )
                } else {
                    logAction(
                        "Updated member details: ${member.name}",
                        "ممبر کی معلومات اپ ڈیٹ کی گئیں: ${member.name}"
                    )
                }
            }
        }
    }"""

if target in content:
    content = content.replace(target, replacement)
    print("Patched updateMember successfully")

with open('app/src/main/java/com/example/ui/TatViewModel.kt', 'w') as f:
    f.write(content)
