import re
with open('app/src/main/java/com/example/MainActivity.kt', 'r') as f:
    content = f.read()

content = re.sub(
    r'androidx\.compose\.foundation\.layout\.Spacer\(modifier = androidx\.compose\.ui\.Modifier\.height\(8\.dp\)\)\n\s*androidx\.compose\.material3\.Text\(info\.releaseNotes, fontSize = 14\.sp\)',
    '',
    content
)

with open('app/src/main/java/com/example/MainActivity.kt', 'w') as f:
    f.write(content)
