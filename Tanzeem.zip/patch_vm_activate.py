import re
content = open("app/src/main/java/com/example/ui/TatViewModel.kt").read()

pattern = r"val newCustodians = list\.map \{ curr ->\s*if \(curr\.id == matchingCustodian\.id \|\| \(curr\.name == matchingCustodian\.name && curr\.startDate == matchingCustodian\.startDate\)\) \{"

replacement = """val newCustodians = list.map { curr ->
                val isTarget = if (matchingCustodian.id != 0L && curr.id != 0L) {
                    curr.id == matchingCustodian.id
                } else {
                    curr.name == matchingCustodian.name && curr.startDate == matchingCustodian.startDate
                }
                
                if (isTarget) {"""

content = re.sub(pattern, replacement, content, flags=re.DOTALL)
open("app/src/main/java/com/example/ui/TatViewModel.kt", "w").write(content)
