import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

replacement = """        val emerald = EmeraldPrimary
        val gold = GoldAccent

        // Abstract Background Elements
        androidx.compose.foundation.Canvas(modifier = Modifier.fillMaxSize()) {
            val canvasWidth = size.width
            val canvasHeight = size.height

            // Top abstract shape
            val path1 = androidx.compose.ui.graphics.Path().apply {
                moveTo(canvasWidth, 0f)
                lineTo(canvasWidth - 300f, 0f)
                quadraticBezierTo(canvasWidth - 100f, 150f, canvasWidth, 300f)
                close()
            }
            drawPath(path1, emerald.copy(alpha = 0.2f))
            
            val path2 = androidx.compose.ui.graphics.Path().apply {
                moveTo(canvasWidth, 0f)
                lineTo(canvasWidth - 150f, 0f)
                quadraticBezierTo(canvasWidth - 50f, 80f, canvasWidth, 150f)
                close()
            }
            drawPath(path2, gold.copy(alpha = 0.3f))

            // Bottom abstract shape
            val path3 = androidx.compose.ui.graphics.Path().apply {
                moveTo(0f, canvasHeight)
                lineTo(300f, canvasHeight)
                quadraticBezierTo(100f, canvasHeight - 150f, 0f, canvasHeight - 300f)
                close()
            }
            drawPath(path3, emerald.copy(alpha = 0.15f))
            
            val path4 = androidx.compose.ui.graphics.Path().apply {
                moveTo(0f, canvasHeight)
                lineTo(150f, canvasHeight)
                quadraticBezierTo(50f, canvasHeight - 80f, 0f, canvasHeight - 150f)
                close()
            }
            drawPath(path4, gold.copy(alpha = 0.25f))
        }"""

content = re.sub(r'// Abstract Background Elements\s*androidx\.compose\.foundation\.Canvas\(modifier = Modifier\.fillMaxSize\(\)\) \{.*?\n        \}\n', replacement + "\n", content, flags=re.DOTALL)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
print("Canvas Colors fixed")
